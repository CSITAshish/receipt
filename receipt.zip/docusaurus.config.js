// @ts-check
// Note: type annotations allow type checking and IDEs autocompletion

const lightCodeTheme = require('prism-react-renderer/themes/github');
const darkCodeTheme = require('prism-react-renderer/themes/dracula');

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: '@walmart/receipt-audit-miniapp',
  url: 'https://gecgithub01.walmart.com',
  baseUrl: '/pages/CustomerTransaction/receipt-audit-app/',
  tagline: 'Receipt Auditing for Stores',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  favicon: 'img/favicon.ico',
  githubHost: 'gecgithub01.walmart.com',
  organizationName: 'CustomerTransaction', // Usually your GitHub org/user name.
  projectName: 'receipt-audit-app', // Usually your repo name.
  staticDirectories: ['./docs/static'],
  trailingSlash: false,

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          routeBasePath: '/',
          sidebarPath: require.resolve('./docs/sidebars.js')
        },
        blog: false
      })
    ]
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      navbar: {
        title: '@walmart/receipt-audit-miniapp',
        logo: {
          alt: 'Receipt Audit',
          src: 'img/logo.svg'
        },
        items: [
          {
            type: 'doc',
            docId: 'getting-started',
            position: 'left',
            label: 'Getting Started'
          },
          {
            type: 'doc',
            docId: 'guides/contributing',
            position: 'left',
            label: 'Contributing'
          },
          {
            to: '/changelog',
            position: 'right',
            label: 'Changelog'
          },
          {
            href: 'https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app',
            label: 'GitHub',
            position: 'right'
          }
        ]
      },
      footer: {
        style: 'dark',
        // links: [
        //   {
        //     title: 'Docs',
        //     items: [
        //       {
        //         label: 'Tutorial',
        //         to: '/docs/intro'
        //       }
        //     ]
        //   },
        //   {
        //     title: 'Community',
        //     items: [
        //       {
        //         label: 'Stack Overflow',
        //         href: 'https://stackoverflow.com/questions/tagged/docusaurus'
        //       },
        //       {
        //         label: 'Discord',
        //         href: 'https://discordapp.com/invite/docusaurus'
        //       },
        //       {
        //         label: 'Twitter',
        //         href: 'https://twitter.com/docusaurus'
        //       }
        //     ]
        //   },
        //   {
        //     title: 'More',
        //     items: [
        //       {
        //         label: 'Blog',
        //         to: '/blog'
        //       },
        //       {
        //         label: 'GitHub',
        //         href: 'https://github.com/facebook/docusaurus'
        //       }
        //     ]
        //   }
        // ],
        copyright: `Copyright © ${new Date().getFullYear()} Walmart Labs, Inc. Built with Docusaurus.`
      },
      prism: {
        theme: lightCodeTheme,
        darkTheme: darkCodeTheme
      }
    })
};

module.exports = config;
