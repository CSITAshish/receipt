const babelConfig =
  process.env.USE_DOCUSAURUS == 1
    ? {
        presets: [require.resolve('@docusaurus/core/lib/babel/preset')]
      }
    : {
        presets: ['module:metro-react-native-babel-preset'],
        plugins: ['transform-inline-environment-variables']
      };

module.exports = babelConfig;
