module.exports = {
  preset: 'react-native',
  setupFiles: ['./mocks/jest.setup.js'],
  setupFilesAfterEnv: ['./mocks/http.middleware.ts'],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  testResultsProcessor: 'jest-sonar-reporter',
  collectCoverageFrom: [
    'src/**/*.{js,ts,jsx,tsx}',
    '!**/node_modules/**',
    '!src/**/index.{ts,js}',
    '!src/**/*.{styles,style}.{ts,js,jsx,tsx}',
    '!src/views/settings/*.tsx'
  ],
  moduleNameMapper: {
    '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      'jest-transform-stub'
  },
  transformIgnorePatterns: [
    '"/node_modules/(?!(@walmart/gtp-shared-components)/)"'
  ],
  coverageThreshold: {
    global: {
      //branches: 75,
      //functions: 75,
      //lines: 75,
      // statements: -50,
    },
  },
};
