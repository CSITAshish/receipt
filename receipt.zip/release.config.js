module.exports = {
  githubApiPathPrefix: '/api/v3',
  githubUrl: 'https://gecgithub01.walmart.com',
  branches: ['main'],
  plugins: [
    [
      '@semantic-release/commit-analyzer',
      {
        preset: 'angular',
        releaseRules: [
          { type: 'refactor', release: 'patch' },
          { type: 'style', release: 'patch' }
        ]
      }
    ],
    [
      '@semantic-release/exec',
      {
        verifyReleaseCmd:
          'VERSION=${nextRelease.version} yarn run android:release beta teflon prod'
      }
    ],
    '@semantic-release/release-notes-generator',
    [
      '@semantic-release/changelog',
      {
        changelogFile: 'docs/CHANGELOG.md'
      }
    ],
    '@semantic-release/npm',
    [
      '@semantic-release/github',
      {
        assets: [
          {
            path: './app.beta.apk',
            name: 'com.walmart.stores.receiptaudit.beta.${nextRelease.version}.apk'
          },
          {
            path: './app.teflon.apk',
            name: 'com.walmart.stores.receiptaudit.teflon.${nextRelease.version}.apk'
          },
          {
            path: './app.prod.apk',
            name: 'com.walmart.stores.receiptaudit.${nextRelease.version}.apk'
          }
        ]
      }
    ],
    [
      '@semantic-release/git',
      {
        assets: ['docs/CHANGELOG.md', 'package.json'],
        message:
          'chore(release): ${nextRelease.version} :package: :rocket: [skip ci]\n\n${nextRelease.notes}'
      }
    ]
  ]
};
