package com.walmart.stores.receiptaudit;

import android.util.Log;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import java.security.KeyFactory;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

public class CryptoModule extends ReactContextBaseJavaModule {
    CryptoModule(ReactApplicationContext context) {
        super(context);
    }

    @Override
    public String getName() {
        return "CryptoModule";
    }

    @ReactMethod
    public void withRsaSHA256(String message, String privateKey, Promise promise) throws Exception {
        String parsedKey = privateKey.replaceAll("-----END PRIVATE KEY-----", "")
            .replaceAll("-----BEGIN PRIVATE KEY-----", "")
            .replaceAll("\n", "")
            .replaceAll(" ", "")
            .replaceAll("\t", "");

        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] decodedKey = Base64.getDecoder().decode(parsedKey);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decodedKey);
    
            Signature privateSignature = Signature.getInstance("SHA256withRSA");
            privateSignature.initSign(keyFactory.generatePrivate(keySpec));
            privateSignature.update(message.getBytes("UTF-8"));
            byte[] signatureBytes = privateSignature.sign();
            promise.resolve(Base64.getEncoder().encodeToString(signatureBytes));
        } catch (Exception e) {
            Log.e("Crypto", e.getMessage());
            promise.reject(e.getMessage());
        }
    }
}
