import { AllsparkEnvConfig } from '@walmart/core-services-allspark';
import { AuthEnv } from '@walmart/core-services/Auth';
import { LogFormat, LogLevel } from '@walmart/core-services/Logger';
import { NotificationEnvironment } from '@walmart/core-services/Notification';

const config: AllsparkEnvConfig = {
  env: 'prod',
  deployment: 'prod',
  appConsumerId: '364a55bb-7f04-4a7c-a800-1d91c08fe5f2',
  pingFedEnv: AuthEnv.PROD,
  redirectUri: 'com.walmart.stores.receiptaudit://SSOLogin',
  sumoOptions: {
    appUUID: 'f0582cce-810e-4c6b-9280-77c4979e22ae',
    consumerId: '364a55bb-7f04-4a7c-a800-1d91c08fe5f2',
    environment: NotificationEnvironment.PROD
  },
  splunk: {
    url: 'https://analytics.mobile.walmart.com/analytics/allspark',
    index: 'allspark',
    format: LogFormat.JSON
  },
  logLevel: LogLevel.ERROR,
  internalUrl:
    'https://api-proxy-es2.prod-us-azure.soa-api-proxy.platform.prod.us.walmart.net',
  externalUrl: 'https://developer.api.us.walmart.com',
  internalBffUrl:
    'https://api-proxy-es2.prod-us-azure.soa-api-proxy.platform.prod.us.walmart.net',
  externalBffUrl: 'https://developer.api.us.walmart.com',
  bffService: '/api-proxy/service/store/systems-bff/v1',
  allsparkService:
    'https://developer.api.walmart.com/api-proxy/service/allspark/api/v1',
  rbacAppId: '55fa784a-f748-4fe3-91a8-4019e102772c'
};

// eslint-disable-next-line import/no-default-export
export default config;
