import { AllsparkEnvConfig } from '@walmart/core-services-allspark';
import { AuthEnv } from '@walmart/core-services/Auth';
import { LogFormat, LogLevel } from '@walmart/core-services/Logger';
import { NotificationEnvironment } from '@walmart/core-services/Notification';

const config: AllsparkEnvConfig = {
  env: 'teflon',
  deployment: 'teflon',
  appConsumerId: 'b5fc6fe0-5927-44a6-a693-6e922e830b04',
  pingFedEnv: AuthEnv.CERT,
  redirectUri: 'com.walmart.stores.receiptaudit.teflon://SSOLogin',
  sumoOptions: {
    appUUID: 'cb663e07-7bcc-4039-ae97-8fb8e8a9ff77',
    consumerId: 'b5fc6fe0-5927-44a6-a693-6e922e830b04',
    environment: NotificationEnvironment.STAGE
  },
  splunk: {
    url: 'https://analytics.mobile.walmart.com/analytics/allspark',
    index: 'allspark',
    format: LogFormat.JSON
  },
  logLevel: LogLevel.DEBUG,
  internalUrl:
    'https://api-proxy.stg.soa-api-proxy.platform.glb.prod.walmart.com',
  externalUrl: 'https://developer.api.us.stg.walmart.com',
  internalBffUrl:
    'https://api-proxy-es2.stg-us-azure.soa-api-proxy.platform.prod.us.walmart.net',
  externalBffUrl: 'https://developer.api.us.stg.walmart.com',
  bffService: '/api-proxy/service/store/systems-bff/v1',
  allsparkService:
    'https://developer.api.stg.walmart.com/api-proxy/service/allspark/api/v1',
  rbacAppId: 'ec9f5c40-88be-4e90-8807-a4f15f11e84c'
};

// eslint-disable-next-line import/no-default-export
export default config;
