import React from 'react';
import { StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NavigationContainer, ParamListBase } from '@react-navigation/native';
import {
  createStackNavigator,
  StackNavigationProp
} from '@react-navigation/stack';
import { PrimaryButton, SecondaryButton } from '@walmart/gtp-shared-components';

import { useAuth } from '@walmart/core-services/Auth';
import { AllsparkCoreServices } from '@walmart/core-services-allspark';

import { AuthenticatorView } from './auth/authenticator-view';
import { UserView } from './user-info';
import Config from './env';

import { App } from '../src/app';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 8
  }
});

interface LauncherViewProps {
  navigation: StackNavigationProp<ParamListBase>;
}

const LauncherView: React.FC<LauncherViewProps> = props => {
  const { navigation } = props;
  const { signOut } = useAuth();
  return (
    <SafeAreaView style={styles.container}>
      <UserView />
      <PrimaryButton onPress={() => navigation.navigate('receiptaudit')}>
        Start Audit
      </PrimaryButton>
      <SecondaryButton onPress={() => signOut('MainActivity', true)}>
        Sign Out
      </SecondaryButton>
    </SafeAreaView>
  );
};

const RootNav = createStackNavigator();

export const RootApp = (): JSX.Element => {
  return (
    <AllsparkCoreServices
      config={{
        env: Config
      }}
    >
      <AuthenticatorView>
        <NavigationContainer>
          <RootNav.Navigator>
            <RootNav.Screen component={LauncherView} name="main" />
            <RootNav.Screen
              name="receiptaudit"
              component={App}
              options={{ headerShown: false }}
            />
          </RootNav.Navigator>
        </NavigationContainer>
      </AuthenticatorView>
    </AllsparkCoreServices>
  );
};
