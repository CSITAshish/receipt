The purpose of the container folder is to simulate the behavior that the allspark-core app provides.

The core app handles sign in, setup of notifications, i18n, logging, etc. So when running your mini app standalone its helpful to have this functionality available and setup. However, that functionality does not need to be apart of your mini app.

So, again, the container folder is where we can add functionality that will already be part of the core app.