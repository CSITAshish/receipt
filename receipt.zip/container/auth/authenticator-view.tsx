import React from 'react';
import {
  ActivityIndicator,
  View,
  Text,
  ViewStyle,
  StyleProp
} from 'react-native';
import { useSelector } from 'react-redux';
import { UserSelectors } from '@walmart/redux-store';
import { PrimaryButton } from '@walmart/gtp-shared-components';
import { useAuth } from '@walmart/core-services/Auth';
import { useUser } from '@walmart/core-services/User';

const activityName = 'MainActivity';

const centerContainerStyle: StyleProp<ViewStyle> = {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center'
};
const centerRowStyle: StyleProp<ViewStyle> = {
  flexDirection: 'row',
  alignItems: 'center'
};
const leftMargin: StyleProp<ViewStyle> = { marginStart: 8 };

export const AuthenticatorView = (props: any): JSX.Element => {
  const user = useSelector(UserSelectors.getOriginalUser);

  const { signIn, signingOut } = useAuth();
  const { fetching: fetchingUser } = useUser();

  if (fetchingUser || signingOut) {
    const msg = signingOut ? 'Signing out' : 'Getting your user information';

    return (
      <View style={centerContainerStyle}>
        <View style={centerRowStyle}>
          <ActivityIndicator size="large" />
          <Text style={leftMargin}>{msg}</Text>
        </View>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={centerContainerStyle}>
        <PrimaryButton
          testID="retryButton"
          onPress={() => signIn(activityName)}
        >
          Sign In
        </PrimaryButton>
      </View>
    );
  }

  return props.children;
};
