import React from 'react';
import { StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import {
  Title,
  Body,
  SolidCard,
  Divider,
  Subheader
} from '@walmart/gtp-shared-components';
import { UserSelectors } from '@walmart/redux-store';

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    flex: 0
  }
});

export const UserView = (): JSX.Element | null => {
  const user = useSelector(UserSelectors.getOriginalUser);

  if (user) {
    return (
      <SolidCard style={styles.container} color="white" elevation={1}>
        <Title>User Info</Title>
        <Divider />
        <Subheader>{user.displayName}</Subheader>
        <Body>userId: {user.userId}</Body>
        <Body>siteId: {user.siteId}</Body>
      </SolidCard>
    );
  }

  return null;
};
