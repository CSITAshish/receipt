import { v4 } from 'uuid';

export const NOT_FOUND = 'NOT_FOUND';

export const DEFAULT_COUNTRY_CODE = 'US';

export const defaultCountryCode = (
  countryCode: string | null | undefined
): string => {
  if (!countryCode || countryCode === NOT_FOUND) {
    return DEFAULT_COUNTRY_CODE;
  }
  return countryCode;
};

export const SESSION_ID = v4();
