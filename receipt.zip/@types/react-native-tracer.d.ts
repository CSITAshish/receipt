declare module '@walmart/react-native-tracer' {
  export interface TracerParentConfig {
    version?: string;
    traceIdLowerBase16?: string;
    spanIdLowerBase16?: string;
    traceFlags?: string;
  }

  export interface Baggage {
    key: string;
    value?: string;
    baggageProperties: Array<Baggage>;
  }

  export class Tracer {
    public generateTraceparent(config: TracerParentConfig): Promise<string>;

    public generateBaggageContent(...baggages: Baggage[]): Promise<string>;
  }
  const t: Tracer;
  export default t;
}
