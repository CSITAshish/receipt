declare module "react-native-wm-barcode" {

    interface ScanData {
        barcode: string;
        type: string;
    }

    interface ScanEvent {
        value: string;
        type: string;
    }

    declare class Scanner {
        public getScannerList(): Promise<string[]>;
        public mockScan(data: ScanData): void;
        public setScanner(scanner: string): Promise<string | null>;
        public startScan(timeout: number): Promise<void>;
        public enableScanner(): Promise<void>;
        public disableScanner(): Promise<void>;
        public setUPCEValueToUnProcessed(isUnprocessed: boolean): Promise<void>;
        public setGS1BarcodeToUnprocessed(isUnprocessed: boolean): Promise<void>;
        public enable(): Promise<void>;
        public disable(): Promise<void>;
        public addListener: (eventType: string) => void;
        public removeListeners: (count: number) => void;
    }

    declare const scanner: Scanner;
    export = scanner;
}