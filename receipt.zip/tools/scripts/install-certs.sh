#!/bin/bash

mkdir $1
curl http://pki.wal-mart.com/pki/WalmartRootCA-SHA256.crt --output $1/wm_root.crt
curl http://pki.wal-mart.com/pki/WalmartIssuingCA-TLS-02-SHA256.crt --output $1/wm_issuing.crt
curl http://pki.wal-mart.com/pki/WalmartIntermediateCA01-SHA256.crt --output $1/wm_intermediate.crt