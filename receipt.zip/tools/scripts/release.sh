if [[ $should_release == false ]]
then
    yarn run semantic-release -d --no-ci --branches $1 && yarn run android:release beta teflon prod && yarn run docs:build
else
    yarn run semantic-release --branches $1 && yarn run docs:deploy
fi