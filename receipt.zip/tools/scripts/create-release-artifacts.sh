echo "Environments to compile - $@"
if [ -z ${VERSION+x} ]; then echo ""; else echo "Version $VERSION."; fi
echo "Change dir to android"
cd android

for ENV in "$@"
do
    echo "Compiling Release for $ENV."
    # TODO: add back once onbaording to allspark
    # yarn run env:${ENV} &&
    if yarn run "env:$ENV" && ./gradlew assemble${ENV}Release; then
        echo "Compilation success."
    else
        echo "Compilation failure."
        exit 1
    fi
    echo "Copying $ENV to working directory."
    cp ./app/build/outputs/apk/$ENV/release/app-$ENV-release.apk ../app.$ENV.apk
done

echo "Back to working directory"
cd ..

# echo "Bundling miniapp for Allspark."
# if yarn run bundle:miniapp; then
#     echo "Compilation success."
# else
#     echo "Compilation failure."
#     exit 1
# fi