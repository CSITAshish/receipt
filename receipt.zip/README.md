# @walmart/receipt-audit-miniapp

<p>
<a href="#badge"><img alt="semantic-release" src="https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg"></a>
<a href='https://ci.mobile.walmart.com/job/CustomerTransaction/job/receipt-audit-app/job/main/'><img src='https://ci.mobile.walmart.com/buildStatus/icon?job=CustomerTransaction%2Freceipt-audit-app%2Fmain'></a>
<a href="https://sonar.looper.prod.walmartlabs.com/dashboard?id=receipt-audit-app"><img src="https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?branch=main&project=receipt-audit-app&metric=alert_status" alt="Quality Gate Status"></a>
  <a href="https://sonar.looper.prod.walmartlabs.com/dashboard?id=receipt-audit-app"><img src="https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?branch=main&project=receipt-audit-app&metric=security_rating" alt="Security Rating"></a>
  <a href="https://sonar.looper.prod.walmartlabs.com/dashboard?id=receipt-audit-app"><img src="https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?branch=main&project=receipt-audit-app&metric=coverage" alt="Coverage"></a>
<a href="https://hygieia.walmart.com/#/dashboard/622ed5d12bea017fe87e495a"><img alt="hygieia" src="https://img.shields.io/badge/DevOps-Hygieia-blue"></a>
<a href="https://gecgithub01.walmart.com/pages/CustomerTransaction/receipt-audit-app"><img alt="Docs" src="https://img.shields.io/badge/Docs-Docusaurus-green"></a>
</p>

> Receipt Audit Application for Scan & Go - com.walmart.stores.receiptaudit.*

## [Getting Started :rocket:](https://gecgithub01.walmart.com/pages/CustomerTransaction/receipt-audit-app/)

## [Contributing Guidelines :moneybag:](https://gecgithub01.walmart.com/pages/CustomerTransaction/receipt-audit-app/guides/contributing)

## [Allspark / Me@ Integration](https://gecgithub01.walmart.com/pages/CustomerTransaction/receipt-audit-app/guides/allspark-inegration)
