---
slug: /
---

# Getting Started

> Below are a list of requirements to run the app.

## Environment Setup :cloud:

> Get started by reading [here](guides/environment-setup).

## Running locally :rocket:

### Environments

- dev
- beta
- teflon
- prod

### Package Installation :package:

```bash
yarn i
```

### Airwatch App

```bash
yarn run android --variant ${ENV}Debug # listed above
```

### Me@ App

```bash
yarn run android:miniapp --variant ${ENV}Debug # listed above
```

### Documentation Site

```bash
yarn docs:start
```

## Contributing Guidelines :rocket:

> Get started by reading [here](guides/contributing).
