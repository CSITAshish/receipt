## [1.23.14](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.13...v1.23.14) (2022-05-27)


### Bug Fixes

* **fetch:** track total time & request time ([#123](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/123)) ([2314651](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/231465122e061515bcf3d0c2bc70a12772e115bc))

## [1.23.13](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.12...v1.23.13) (2022-05-12)


### Bug Fixes

* **audit-service:** pass correct failure reason ([#120](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/120)) ([5753c2a](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/5753c2a15b541b8c02eb29ba00f273ae8be3130e))

## [1.23.12](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.11...v1.23.12) (2022-05-10)


### Bug Fixes

* **sso:** refresh token 5 minutes before exp ([#119](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/119)) ([0e90437](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/0e904373c8635bd83be7b1d2b1f366d5b52482e8))

## [1.23.11](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.10...v1.23.11) (2022-05-09)


### Bug Fixes

* **item-scan:** audit status bottom sheet timeout ([#113](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/113)) ([bd2cab7](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/bd2cab78f92f745f4b2e5e00d1b65308794f09f8))

## [1.23.10](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.9...v1.23.10) (2022-05-09)


### Bug Fixes

* **item-scan:** only allow receipt scans in error flow ([#117](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/117)) ([c5f7b6f](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/c5f7b6fce9fa04063a8f8d8478b42d06da883606))

## [1.23.9](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.8...v1.23.9) (2022-05-09)


### Bug Fixes

* **siro-response:** add null checks on siro response ([#118](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/118)) ([63ade48](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/63ade4875db33aa6f875b95d530ab52757af57ef))

## [1.23.8](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.7...v1.23.8) (2022-05-09)


### Bug Fixes

* **item-scan:** support conversion upce to upca ([#114](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/114)) ([543933b](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/543933bf8002b2fc9925368f30e5afaa5d316572))

## [1.23.7](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.6...v1.23.7) (2022-05-09)


### Bug Fixes

* **store-service:** persist value when app closes ([#116](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/116)) ([6ae3ec6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/6ae3ec6e074a9718dc3e352859d78bed11c76f58))

## [1.23.6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.5...v1.23.6) (2022-05-09)


### Bug Fixes

* **receipt-scan:** falsy check on audit time ([#115](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/115)) ([25634cb](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/25634cb26b1acacdc05801e1ee24fff1ccb0d09d))

## [1.23.5](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.4...v1.23.5) (2022-05-07)


### Bug Fixes

* **timezone:** display in local time ([#112](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/112)) ([e3d488c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e3d488c9a78b445e5150af000db52b9b58306d18))

## [1.23.4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.3...v1.23.4) (2022-05-06)


### Bug Fixes

* **scanner:** encode barcodes on pages instead of hook ([#109](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/109)) ([e94f960](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e94f9601f2e65fac4398c8431cff6d6044abee7b))

## [1.23.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.2...v1.23.3) (2022-05-06)


### Bug Fixes

* **error-flows:** work with scanner ([#104](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/104)) ([fa996da](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/fa996dafe979e342bccbe8760c0cb4d608e28abc))

## [1.23.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.1...v1.23.2) (2022-05-05)


### Bug Fixes

* **receipt-scan:** update already scanned text ([#107](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/107)) ([1d1d9b2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/1d1d9b2d4b6b8c0397a4c9ccd75065c04bfce9bc))
* **store-config:** dont append 0s ([#108](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/108)) ([d38b6cc](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/d38b6cc5ceda930b70880d45e4e199b558934891))

## [1.23.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.23.0...v1.23.1) (2022-05-05)


### Bug Fixes

* **item-service:** smarter item type queries ([#106](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/106)) ([5c3151d](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/5c3151d1e4829f192d380b79c18a969e15f07fee))

# [1.23.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.6...v1.23.0) (2022-05-05)


### Bug Fixes

* **item-service:** production endpoint ([#105](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/105)) ([2cde31f](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/2cde31fb9e7f6c859781183882f3e02391641330))


### Features

* add pilot airwatch deployment ([#101](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/101)) ([a383dfd](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/a383dfd6e90fe58ccea4685fcb532b0b622eed2e))

## [1.22.6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.5...v1.22.6) (2022-05-05)


### Bug Fixes

* **receipt-scan:** show correct time window error ([#103](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/103)) ([0cccb02](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/0cccb025c1db17989da4d2a549c83d0874fc1440))

## [1.22.5](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.4...v1.22.5) (2022-05-04)


### Bug Fixes

* **alert-message:** multi scan alert is not getting dismissed ([#102](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/102)) ([374cb7e](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/374cb7ee922f5911131baad57436bb1d774b0875))

## [1.22.4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.3...v1.22.4) (2022-05-04)


### Bug Fixes

* **error-flows:** match designs & show item info if exists ([#100](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/100)) ([66a844f](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/66a844fef5ec75d4718e1059857018c1f9ea5b98))

## [1.22.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.2...v1.22.3) (2022-05-04)


### Bug Fixes

* **scanner:** reset scan count to 1 ([#99](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/99)) ([0784fb6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/0784fb6a9753d436f91aa23df46cb01d0114de01))

## [1.22.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.1...v1.22.2) (2022-05-04)


### Bug Fixes

* **scanner:** count duplicate barcode scans ([#96](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/96)) ([417d276](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/417d2765d60002fa04e784514588bba20501849c))
* **scanner:** support different barcode types ([#98](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/98)) ([ea23ce1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/ea23ce1fe66dfc6bb7eb1e67a6ae63c1b6946f16))

## [1.22.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.22.0...v1.22.1) (2022-05-04)


### Bug Fixes

* **item-scan:** disable duplicate item scans ([#94](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/94)) ([e70b876](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e70b876c81ed68b6f2ecb58a41038f934a6d8b8e))

# [1.22.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.21.3...v1.22.0) (2022-05-04)


### Features

* audit failure steps ([#82](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/82)) ([d70d5ae](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/d70d5ae2db220d385fa05d47521f8ca0e79ef564))

## [1.21.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.21.2...v1.21.3) (2022-05-03)


### Bug Fixes

* **item-scan:** empty bottomsheet & don't support produce scan ([#93](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/93)) ([00666a8](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/00666a8b63e6296cc05883987437eefa92ad7284))

## [1.21.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.21.1...v1.21.2) (2022-05-03)


### Bug Fixes

* **barcode-form:** validate input on submit ([#92](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/92)) ([29fc40c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/29fc40cab5f8e30ea358f77b0ba64f06bed17cf1))

## [1.21.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.21.0...v1.21.1) (2022-05-03)


### Bug Fixes

* **navigation:** add transaction details ([#89](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/89)) ([9c556f6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/9c556f6bbc1eba51440883853595b1bf6f0418f3))
* **pingfed:** by app env ([#91](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/91)) ([2b51076](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/2b510763db0958a0e72ac4d31017415d07c2bb2d))

# [1.21.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.5...v1.21.0) (2022-05-03)


### Features

* **pingfed:** use prod env ([#90](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/90)) ([70612ef](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/70612ef235aed187a992a5e449dde28c19c4142e))

## [1.20.5](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.4...v1.20.5) (2022-05-02)


### Bug Fixes

* **audit-service:** bad response messaging ([#88](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/88)) ([ecd26dc](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/ecd26dc60fb34e75b74d9f2ccb06737301f83fae))

## [1.20.4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.3...v1.20.4) (2022-05-02)


### Bug Fixes

* **error-screen:** retry error state ([#87](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/87)) ([2419915](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/241991520174aa61f9f6d309221e7edb331d75c9))
* more support for upc barcode types ([#86](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/86)) ([65b52b5](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/65b52b5398b860c13586ede8b9ad45bdef51bbcf))

## [1.20.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.2...v1.20.3) (2022-05-02)


### Bug Fixes

* default store to 5542 ([#85](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/85)) ([764e6eb](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/764e6eb387b9be8c02dd05573e4761470ac8f880))

## [1.20.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.1...v1.20.2) (2022-05-02)


### Bug Fixes

* remove multi receipt flow ([#76](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/76)) ([a87d01c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/a87d01c5a36fb9aa94e6b059669e2bcb26e4cd55))

## [1.20.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.20.0...v1.20.1) (2022-05-02)


### Bug Fixes

* **receipt-scan:** comp client store to resp store ([#83](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/83)) ([72c024f](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/72c024fd49515f89d39bd28d191530ecd654be38))

# [1.20.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.8...v1.20.0) (2022-05-01)


### Features

* **error-screen:** catch network & general errors ui ([#80](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/80)) ([7576e4f](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/7576e4fc27ca36530b8642111289d46259bce1f4))
* store bottom sheet ([#81](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/81)) ([bbff23c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/bbff23cc1c7561b9905c72cfe4b05d217aae97e5))

## [1.19.8](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.7...v1.19.8) (2022-05-01)


### Bug Fixes

* **receipt-scan:** display snackbar on invalid receipt ([#78](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/78)) ([8834b61](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/8834b613095a88d55351a1e0beae75680351f40f))

## [1.19.7](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.6...v1.19.7) (2022-04-30)


### Bug Fixes

* **receipt-scan:** service desk bottom sheet & audit time format ([#77](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/77)) ([3fa1cce](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/3fa1cce5581a44d623f553b4ec7e534a7849a117))

## [1.19.6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.5...v1.19.6) (2022-04-29)

## [1.19.5](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.4...v1.19.5) (2022-04-29)


### Bug Fixes

* **audit-complete:** reset navigation stack on nav ([#73](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/73)) ([7977a0b](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/7977a0b388b9d3e4bd4554f043d73538fdaff115))
* **barcode-form:** numeric input only ([#72](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/72)) ([1d0d079](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/1d0d07960f5d95f598fce582f15e9c7bab1c7ed3))

## [1.19.4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.3...v1.19.4) (2022-04-29)


### Bug Fixes

* **item-scanner:** separate scan changes from reducer changes ([#71](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/71)) ([7a0d67d](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/7a0d67d854104aa4b8073fd80f089ee9052e498d))

## [1.19.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.2...v1.19.3) (2022-04-29)


### Bug Fixes

* **android:** portrait mode only ([#70](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/70)) ([8724a77](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/8724a770237239d6034d7347a59ab4cd38aa08a2))
* **spinner:** reset nav stack on receipt scan ([#69](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/69)) ([58daf62](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/58daf62ae3e90975204f786219b3470f73299b15))

## [1.19.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.1...v1.19.2) (2022-04-29)


### Bug Fixes

* **audit-service:** handle unauthorized requests ([#68](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/68)) ([cc27c03](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/cc27c03a7397400350e4a6e8ae13969bcf0a463a))

## [1.19.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.19.0...v1.19.1) (2022-04-28)


### Bug Fixes

* use shared airwatch signing key ([#67](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/67)) ([90eedc6](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/90eedc671949c25f1e81c3254a151be902440a59))

# [1.19.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.18.0...v1.19.0) (2022-04-28)


### Features

* **airwatch:** dev device deployments ([#66](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/66)) ([996b50c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/996b50c08886896ddd56554bd317425d256a89fa))

# [1.18.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.17.3...v1.18.0) (2022-04-28)


### Features

* **receipt-scan:** audit error screen ([#65](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/65)) ([ee8ab3a](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/ee8ab3a45b656cc8bac62956a0f86023da3e9c68))

## [1.17.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.17.2...v1.17.3) (2022-04-28)


### Bug Fixes

* **item-service:** remove hardcoded store id ([#64](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/64)) ([1b88f8d](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/1b88f8dd805bb337f8dc1a25c183f654c87bc32b))

## [1.17.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.17.1...v1.17.2) (2022-04-26)


### Bug Fixes

* **services:** auth token integration ([#63](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/63)) ([3b46409](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/3b46409e84337596885a191f5027487f7e57e903))

## [1.17.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.17.0...v1.17.1) (2022-04-25)


### Bug Fixes

* **service-registry:** add env api configs ([#61](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/61)) ([118e4d3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/118e4d3df97a1014698b15e7ecf3ecc76c481ccc))

# [1.17.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.16.1...v1.17.0) (2022-04-25)


### Features

* wire up receipt lookup api ([#58](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/58)) ([1e2b226](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/1e2b2261690619831e201256eac437ad76d54ecc))

## [1.16.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.16.0...v1.16.1) (2022-04-23)

# [1.16.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.15.1...v1.16.0) (2022-04-22)


### Bug Fixes

* not on receipt route ([#55](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/55)) ([c20cb08](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/c20cb08801366abb0fd7cc08a3f755148b594805))


### Features

* wire reciept api ([#53](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/53)) ([8cd5a7e](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/8cd5a7ea4aa5ba3116ad694072b8615aa873732b))

## [1.15.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.15.0...v1.15.1) (2022-04-21)

# [1.15.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.14.1...v1.15.0) (2022-04-20)


### Features

* wire up item page scanner ([#50](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/50)) ([43dad6e](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/43dad6e02cc956c62bbbba3923f7e3ad44962a52))

## [1.14.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.14.0...v1.14.1) (2022-04-19)


### Bug Fixes

* sign in hook loading ([#48](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/48)) ([0dd9970](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/0dd99701d1a5b089ce4472ceff2a9e0a8e1afe92))

# [1.14.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.13.1...v1.14.0) (2022-04-19)


### Features

* wire up siro & audit api ([#46](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/46)) ([3fe5293](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/3fe5293166b7bbb1269c16f62d4598e73100de9f))

## [1.13.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.13.0...v1.13.1) (2022-04-18)

# [1.13.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.12.0...v1.13.0) (2022-04-15)


### Features

* receipt audit api service ([#44](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/44)) ([5112684](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/51126848513d4afaf613851b9e905c3c6874ceef))

# [1.12.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.11.1...v1.12.0) (2022-04-14)


### Features

* item scan bottom sheet ([#39](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/39)) ([e86b81d](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e86b81dcbf80ecef796fc87da32b2461f5f9b4e1))

## [1.11.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.11.0...v1.11.1) (2022-04-14)


### Bug Fixes

* **scanner:** work on emulator ([#43](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/43)) ([e24bdd2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e24bdd2bcd78f4b9889cf9ce3df96e02b106c245))

# [1.11.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.10.2...v1.11.0) (2022-04-13)


### Features

* receipt scanner integration ([#37](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/37)) ([979c907](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/979c907d0789f0e637774cc4f14d2cc79f40d113))
* siro api contract ([#42](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/42)) ([b9d44a2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/b9d44a21b833c85fa388affa114156d9a009a006))

## [1.10.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.10.1...v1.10.2) (2022-04-13)


### Bug Fixes

* **service-registry:** private key secrets ([#40](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/40)) ([025c8f4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/025c8f4bc2d8cdc146c2b7f24a0d0a0e7453cb81))

## [1.10.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.10.0...v1.10.1) (2022-04-12)

# [1.10.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.9.2...v1.10.0) (2022-04-12)


### Features

* siro integration ([#38](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/38)) ([6eb3a81](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/6eb3a8134c96592ed4850fb391486e50f11e053b))

## [1.9.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.9.1...v1.9.2) (2022-04-11)

## [1.9.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.9.0...v1.9.1) (2022-04-08)

# [1.9.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.8.1...v1.9.0) (2022-04-07)


### Features

* item scan snackbar ([#36](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/36)) ([1a98b58](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/1a98b58c716d4f947ecf3364bdef2f1993f7b77e))

## [1.8.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.8.0...v1.8.1) (2022-04-06)

# [1.8.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.7.1...v1.8.0) (2022-04-05)


### Features

* global loading panel ([#26](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/26)) ([ea15ac8](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/ea15ac871b39769b8ae2ed7fe5594856bbe1429b))

## [1.7.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.7.0...v1.7.1) (2022-04-05)


### Bug Fixes

* disable drawer when not logged in ([#29](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/29)) ([dc2c590](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/dc2c59056da8f6eea18327119a89650e81dcead6))

# [1.7.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.6.4...v1.7.0) (2022-04-04)


### Features

* application logger ([#28](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/28)) ([2d9044e](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/2d9044e58bfa021d9536d73f4ac0c9a35027a9ac))

## [1.6.4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.6.3...v1.6.4) (2022-04-04)

## [1.6.3](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.6.2...v1.6.3) (2022-04-04)

## [1.6.2](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.6.1...v1.6.2) (2022-04-01)

## [1.6.1](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.6.0...v1.6.1) (2022-04-01)


### Bug Fixes

* **release:** first time crash ([#23](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/23)) ([6c7579b](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/6c7579bfad741c023e4c914f1904d5295a92399c))

# [1.6.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.5.0...v1.6.0) (2022-04-01)


### Features

* receipt scan page ([#14](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/14)) ([df0fb95](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/df0fb95dda532c271ff6bfa158580c3c0fed651c))

# [1.5.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.4.0...v1.5.0) (2022-03-31)


### Features

* item scan page ([#16](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/16)) ([a7504e4](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/a7504e4e43790910d36a6581b0beb5f372a26f79))

# [1.4.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.3.0...v1.4.0) (2022-03-31)


### Features

* upc input bottom sheet ([#19](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/19)) ([f01987b](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/f01987b249b0d311c25dea8cbab6297717c5455a))

# [1.3.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.2.0...v1.3.0) (2022-03-30)


### Features

* sign in page & sso ([#13](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/13)) ([6750d50](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/6750d503909e1cb9338a6f791a2966ad04435a3c))

# [1.2.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.1.0...v1.2.0) (2022-03-29)


### Features

* receipt number bottom sheet ([#15](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/15)) ([a359e01](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/a359e01562f0d148b1c3c649ef25227f147a2b6f))

# [1.1.0](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/compare/v1.0.0...v1.1.0) (2022-03-25)


### Features

* **drawer-content:** add stylings & sign out bottom sheet ([#9](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/9)) ([e34778c](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/e34778cb772aa250edf76c367edf9a9ff3a89f52))

# 1.0.0 (2022-03-22)


### Features

* **navigation:** add header & drawer ([#8](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/issues/8)) ([fb06fad](https://gecgithub01.walmart.com/CustomerTransaction/receipt-audit-app/commit/fb06fadac0ad52e67b9872f57fbf4dcfd1975873))
