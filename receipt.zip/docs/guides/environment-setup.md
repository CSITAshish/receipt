# Environment Setup

:::caution Prerequisites

- Please make sure your are on the **WeC Two Factor VPN**
- [Install NVM](https://github.com/nvm-sh/nvm#installing-and-updating)
- [VS Code](https://code.visualstudio.com/download)
  - [React Native Plugin](https://marketplace.visualstudio.com/items?itemName=msjsdiag.vscode-react-native)

:::

## Node

### NVM (Node Version Manager)
> Provides easy management of different versions of node

:::warning Alert

**Please add the below script to your ~/.zshrc file & run source ~/.zshrc in your terminal**

The script will automatically update to the node version described in the current directory's .nvmrc file or it will use the LTS (Long term support) version.

:::warning

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

autoload -U add-zsh-hook
load-nvmrc() {
  local node_version="$(nvm version)"
  local nvmrc_path="$(nvm_find_nvmrc)"
  if [ -n "$nvmrc_path" ]; then
    local nvmrc_node_version=$(nvm version "$(cat "${nvmrc_path}")")
    if [ "$nvmrc_node_version" = "N/A" ]; then
      nvm install
    elif [ "$nvmrc_node_version" != "$node_version" ]; then
      nvm use
    fi
  elif [ "$node_version" != "$(nvm version default)" ]; then
    echo "Reverting to nvm lts version"
    nvm install --lts
    nvm use --lts
  fi
}

add-zsh-hook chpwd load-nvmrc
load-nvmrc
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
```

### Yarn

:::info Official Docs

<https://classic.yarnpkg.com/en/docs/install/#mac-stable>

:::

:::caution

Make sure you aren't in **receipt-audit-app** directory!

:::

```sh
npm i -g yarn
yarn --version
```

### Homebrew (Mac Users)

:::caution

May require not being on VPN.

:::

:::info Installation

<https://brew.sh/>

:::

## React Native

:::info Setup Guide

<https://reactnative.dev/docs/environment-setup>

:::

### Watchman & OpenJDK 8

```sh
brew install watchman
brew install --cask adoptopenjdk/openjdk/adoptopenjdk8
```

### Android Studio

:::info Install the following
<https://developer.android.com/studio/index.html>

- Android SDK
- Android SDK Platform
- Android Virtual Device

:::

### Bash or ZSH Setup

#### Add to your `~/.bash_profile`, `~/.bashrc`, `~/.zprofile`, or `~/.zshrc`

```sh
vi ~/.zshrc # depends on shell type which file to edit. check header above.
```

Press `i`.

```sh
export ANDROID_HOME=$HOME/Library/Android/sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
export JAVA_HOME=$(/usr/libexec/java_home -v 1.8) # Sets java -version to OpenJDK 8.
```

Press `esc`, `:wq`.

```sh
source ~/.zshrc # depends on shell type which file to edit. check header above.
java -version # 1.8.0_242
sdkmanager --version # should output version
avdmanager list # should list current devices available for emulation
```

## Device Configuration

:::info [Instructions](device-configuration)
:::

## Run Application

:::info Basic Yarn Commands

<https://yarnpkg.com/getting-started/usage>

:::

Before you can build APKs, you need to install the NDK. In Android Studio, go to `Tools > SDK Manager > SDK Tools tab > NDK (Side by side) > 22.1.7171670`

:::important

If you do not see the versions, make sure you check `Show package details`

:::

For building APKs and starting the dev server, see TBD.

## Debugging

### React Native Debugger

:::info Installation Instructions

<https://github.com/jhen0409/react-native-debugger#installation>

:::

#### Shortcuts for enabling debugger mode

**Android** -> `cmd + M` <br />
**iOS** -> `cmd + D`

:::tip
Make sure React Native Debugger is open before starting the debugger mode on your emulator/device. Also, close any developer tool windows that are already open on your browser and reload the app.
:::

:::note
Network Inspect has to be enabled every single time the app is reopened.
:::

