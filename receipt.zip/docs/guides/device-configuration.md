# Device Configuration

:::warning Prerequisites

**Please make sure to read [environment setup](environment-setup) before proceeding.**

:::

:::info [TC70X Device Specs](https://www.zebra.com/content/dam/zebra_new_ia/en-us/solutions-verticals/product/Mobile_Computers/Hand-Held%20Computers/Symbol%20TC70%20Touch%20Computer/spec%20sheet/tc70series-product-specification-sheet-en-us.pdf)

:::

:::info [Create a hardware profile](https://developer.android.com/studio/run/managing-avds#createhp)
:::