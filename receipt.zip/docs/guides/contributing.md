# Contributing

## Commit Messages

> Please check out [angular's conventional changelog](https://github.com/angular/angular/blob/master/CONTRIBUTING.md#commit) for more details.

### Format

```code
<type>(<scope>): message
```

## Versioning

:::note Release Rules

Please check out [semantic release](https://github.com/semantic-release/semantic-release#how-does-it-work) for more details.

All commit message fields that have **[no release]** or **[skip ci]** _will be ignored_ in the current build & included in the next releasable commit.

**Pull Request Titles** are the commit message when **squashed** into main. All other commit messages in that branch **do not** impact versioning!

:::

| Release Type     | Usage                                                        | Release |
|----------|--------------------------------------------------------------|---------|
| fix(scope): message      | Bug fixes                                                    | 0.0.X   |
| style(scope): message    | Styling UX Changes                                           | 0.0.X   |
| refactor(scope): message | Same UX, different under the hood                            | 0.0.X   |
| feat(scope): message     | A new feature like a screen or platform                      | 0.X.0   |
| docs(scope): message     | Documentation changes; README, etc                           | None    |
| chore(scope): message    | Something that needs to be done, but doesnt impact the user. | None    |
| perf(scope): message     | Performance related changes                                  | 0.0.X   |
| ci(scope): message       | Changes to the CI / CD platform                              | None    |
| build(scope): message    | Changes to build process                                     | None    |
| test(scope): message     | Changes to tests                                             | None    |
| type(scope): **BREAKING CHANGES** (rest of message here) | Serious changes to application architecture that is NOT backwards compatible. | X.0.0 |