# Allspark / Me@ Integration

:::note TODOS

- Figure out why `@walmart/react-native-sumo-sdk` doesnt work in release artifacts.

:::

:::note [Miniapp template](https://gecgithub01.walmart.com/store-systems-associate-tech-platform/feature-app-template-typescript)
:::

## Allspark Documentation

- [UI Architecture](https://confluence.walmart.com/display/ALLSPARK/UI+Architecture)
- [Feature App / Miniapp integration](https://confluence.walmart.com/pages/viewpage.action?pageId=401266955)

## Design

The app currently supports a hybrid model where an artifact can be either:
- An Allspark miniapp
- A standalone Android application that can be deployed via Airwatch

There is an environment variable, USE_MINIAPP, that decides which app will be compiled based on whether the value is 0 or 1.
0 compiles the standalone app, and 1 compiles the miniapp that will eventually be integrated with Me@.

When code is merged into main, the pipeline will compile and publish artifacts for both the standalone app, as an APK, and an NPM package, @walmart/receipt-audit-miniapp.

This is to save time down the road when the application needs to be integrated with Me@.