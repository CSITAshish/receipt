# :pencil: Summary

Summary needs to be in present tense. Add your description in a list format preferably.

## Contributing Guidelines (PLEASE REMOVE)
> Can be found [here](https://gecgithub01.walmart.com/pages/CustomerTransaction/receipt-audit-app/guides/contributing)
## :books: JIRA and Other References

## :framed_picture: Screenshots

## :package: 3rd Party libraries

### <Library Name>

#### Why is it needed?

Brief description on why this package is needed.