//
//  RCTCryptoModule.m
//  ReceiptAudit
//
//  Created by Wesley Chappell on 6/13/22.
//
#import "RCTCryptoModule.h"

@implementation RCTCryptoModule

RCT_EXPORT_METHOD(withRsaSHA256: (NSString *)message privateKey:(NSString *)privateKey resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
  @try {
    PrivateKey* privKey = [[PrivateKey alloc] initWithPemEncoded:privateKey error: nil];
    ClearMessage* encodedMessage = [[ClearMessage alloc] initWithString: message using:NSUTF8StringEncoding error:nil];
    Signature* encrypted = [encodedMessage signedWith:privKey digestType:DigestTypeSha256 error:nil];
    NSString* b64String = [encrypted base64String];
    resolve(b64String);
  }
  @catch(id anException) {
    reject(@"crypto_failure", anException, nil);
  }
}

RCT_EXPORT_MODULE(RCTCryptoModule);

@end
