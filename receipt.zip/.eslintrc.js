module.exports = {
  root: true,
  extends: [
    '@react-native-community',
    'plugin:react-native-a11y/all',
    'airbnb-typescript',
    'plugin:@typescript-eslint/recommended',
    'plugin:eslint-comments/recommended',
    'plugin:promise/recommended',
    'plugin:prettier/recommended',
    'plugin:mdx/recommended',
    'plugin:import/recommended',
    "plugin:react-hooks/recommended",
  ],
  plugins: ['@typescript-eslint', 'eslint-comments', 'promise', 'prettier', 'unicorn'],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    project: './tsconfig.json'
  },
  settings: {
    'mdx/code-blocks': true,
    'import/ignore': ['node_modules'],
    // optional, if you want to disable language mapper, set it to `false`
    // if you want to override the default language mapper inside, you can provide your own
    'mdx/language-mapper': {}
  },
  rules: {
    "unicorn/filename-case": [
      "error",
      {
        "case": "kebabCase"
      }
    ],
    // webdriver cannot find element with hints for some reason
    'import/namespace': 'off',
    'react-native-a11y/has-accessibility-hint': 'off',
    'no-param-reassign': 'off',
    'no-console': 'error',
    '@typescript-eslint/ban-types': 'warn',
    '@typescript-eslint/no-unused-vars': 'error',
    'prettier/prettier': 'error',
    // Too restrictive, writing ugly code to defend against a very unlikely scenario: https://eslint.org/docs/rules/no-prototype-builtins
    'no-prototype-builtins': 'off',
    // https://basarat.gitbooks.io/typescript/docs/tips/defaultIsBad.html
    'import/prefer-default-export': 'off',
    'import/no-default-export': 'error',
    // Too restrictive: https://github.com/yannickcr/eslint-plugin-react/blob/master/docs/rules/destructuring-assignment.md
    'react/destructuring-assignment': 'off',
    'react/require-default-props': 'off',
    // Project doesn't use defaultProps: https://github.com/yannickcr/eslint-plugin-react/blob/master/docs/rules/require-default-props.md
    'import/no-extraneous-dependencies': 'off', // because allspark
    // No jsx extension: https://github.com/facebook/create-react-app/issues/87#issuecomment-234627904
    'react/jsx-filename-extension': 'off',
    'react/static-property-placement': 'off',
    'react/jsx-props-no-spreading': 'off',
    'promise/always-return': 'off',
    // Use function hoisting to improve code readability
    'no-use-before-define': 'off',
    // Makes no sense to allow type inferrence for expression parameters, but require typing the response
    '@typescript-eslint/explicit-function-return-type': [
      'error',
      { allowExpressions: true, allowTypedFunctionExpressions: true }
    ],
    '@typescript-eslint/no-use-before-define': [
      'error',
      { functions: false, classes: true, variables: true, typedefs: true }
    ],
    'no-plusplus': 'off'
  },
  overrides: [
    {
      files: ['src/**/*.spec.{js,ts,jsx,tsx}', 'mocks/**/*.{ts,js}'],
      extends: ['plugin:jest/recommended'],
      plugins: ['jest']
    }
  ]
};
