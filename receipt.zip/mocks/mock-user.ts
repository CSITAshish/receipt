import { SSOUser } from 'react-native-ssmp-sso-allspark';

export function mockUser(
  countryCode = 'US',
  displayName = 'NOT_FOUND'
): SSOUser {
  return {
    accessToken: 'NOT_FOUND',
    clockStatus: 'ON',
    countryCode,
    displayName,
    division: '5',
    domain: 'Homeoffice',
    emailId: 'Samuel.Neff@walmart.com',
    employeeType: 'S',
    fullTimePartTime: 'F',
    jobCode: '811067',
    regionNumber: '21',
    siteId: '100',
    title: 'NOT_FOUND',
    userId: 's0n0213',
    win: '226623813',
    workingSite: '100'
  };
}
