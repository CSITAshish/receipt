import { setupServer, SetupServerApi } from 'msw/node';
import {
  receiptAuditLookupApiHandler,
  receiptAuditMetricsApiHandler,
  receiptAuditValidateApiHandler
} from '../src/services/audit/mocks';
import { itemApiHandler } from '../src/services/item/mocks';

export const server: SetupServerApi = setupServer(
  itemApiHandler,
  receiptAuditLookupApiHandler(),
  receiptAuditMetricsApiHandler,
  receiptAuditValidateApiHandler
);
