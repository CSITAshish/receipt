import { cleanup } from '@testing-library/react-native';
import { server } from './http.mock';

beforeAll(() => {
  server.listen({
    onUnhandledRequest: 'error'
  });
});
afterEach(() => {
  server.resetHandlers();
  cleanup();
});
afterAll(() => {
  server.close();
});
