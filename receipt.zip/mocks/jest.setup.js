/* eslint-disable @typescript-eslint/no-var-requires,eslint-comments/disable-enable-pair */

import 'react-native-gesture-handler/jestSetup';
import MockDeviceInfo from './react-native-device-info.mock';
import { mockUser } from './mock-user';
import { NativeModules } from 'react-native';

jest.mock('react-native-localize', () => require('react-native-localize/mock'));
jest.mock('@react-native-community/async-storage', () =>
  require('@react-native-community/async-storage/jest/async-storage-mock')
);

jest.mock('@react-native-firebase/crashlytics', () => {
  return () => ({
    log: jest.fn(),
    recordError: jest.fn()
    // Any function you want to use or mock
  });
});

import fetch from 'node-fetch';
import https from 'https';

global.fetch = (input, opts) => {
  return fetch(input, {
    ...opts,
    agent: new https.Agent({
      rejectUnauthorized: false
    })
  });
};
global.Headers = fetch.Headers;

require('abortcontroller-polyfill');

NativeModules.CryptoModule = {
  withRsaSHA256: jest.fn(
    () => new Promise(resolve => resolve('420'.repeat(420)))
  )
};

jest.mock('react-native-config', () => ({
  FLAVOR: 'dev',
  APP_PRIVATE_KEY: '420'
}));

jest.mock('@walmart/react-native-tracer', () => ({
  generateTraceparent: jest.fn(() => new Promise(resolve => resolve('123'))),
  generateBaggageContent: jest.fn(() => new Promise(resolve => resolve('123')))
}));

jest.mock('react-native-device-info', () => MockDeviceInfo);
jest.mock('react-native/Libraries/EventEmitter/NativeEventEmitter');
jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');

  // The mock for `call` immediately calls the callback which is incorrect

  // So we override it with a no-op

  Reanimated.default.call = () => {};

  return Reanimated;
});

// Silence the warning: Animated: `useNativeDriver` is not supported because the native animated module is missing
jest.mock('react-native/Libraries/Animated/NativeAnimatedHelper');

jest.mock(
  'react-native-ssmp-sso-allspark',
  () =>
    new (class MockWMSingleSignOn {
      getFreshAccessToken = jest.fn(() =>
        Promise.resolve(
          'eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTY1MTE5OTk1NSwiaWF0IjoxNjUxMTk5OTU1fQ.MpjTjMl_-wxtTEZp_yvSCVQl8Yf3aiGodHcZOWmKXOs'
        )
      );

      getUser = jest.fn(() => {
        return Promise.resolve(mockUser());
      });

      promptUserForSite = jest.fn(() => Promise.resolve('101'));

      setEnv = jest.fn(() => {});

      setRedirectUri = jest.fn(() => {});

      signIn = jest.fn(() => Promise.resolve());

      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      signOut = jest.fn((_callback, _relogin) => Promise.resolve());

      ssoEventEmitter = {
        addListener: jest.fn((_name, listener) => {
          return listener({ ...mockUser(), action: 'ssoAuthSuccess' });
        }),
        removeAllListeners: jest.fn(() => () => {})
      };

      SSOEnv = {
        CERT: 'CERT',
        DEV: 'DEV',
        PROD: 'PROD'
      };

      SSOPingFedEvents = {
        types: {
          authSuccess: 'ssoAuthSuccess',
          clockStatusChange: 'clockStatusChange',
          error: 'error',
          signedOut: 'signedOut',
          userChanged: 'userChanged'
        }
      };
    })()
);

jest.mock('react-native-wm-barcode', () => ({
  setScanner: jest.fn(() => new Promise(resolve => resolve())),
  startScan: jest.fn(() => new Promise(resolve => resolve())),
  mockScan: jest.fn(() => new Promise(resolve => resolve())),
  getScannerList: jest.fn(
    () => new Promise(resolve => resolve(['2D Barcode Imager']))
  )
}));
