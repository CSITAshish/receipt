module.exports = {
  bracketSpacing: true,
  singleQuote: true,
  trailingComma: 'none',
  arrowParens: 'avoid',
};
