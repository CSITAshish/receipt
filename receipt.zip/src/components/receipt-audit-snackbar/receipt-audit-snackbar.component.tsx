import React, { FC, useState, useEffect } from 'react';
import Snackbar from '@walmart/gtp-shared-components/dist/messaging/snackbar';
import { StyleSheet, View } from 'react-native';

interface State {
  snackbarVisible: boolean;
}

interface Props {
  children: string;
  onDismiss?: () => void;
}

export const ReceiptAuditSnackbar: FC<Props> = (props: Props): JSX.Element => {
  const [state, setState] = useState<State>({
    snackbarVisible: true
  });

  useEffect(() => {
    const snackbarTimer = setTimeout(() => {
      setState({ snackbarVisible: false });
      if (props.onDismiss) {
        props.onDismiss();
      }
    }, 3500);
    return () => {
      clearTimeout(snackbarTimer);
    };
  }, []);

  const style = StyleSheet.create({
    snackbar: {
      bottom: 4,
      position: 'absolute',
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'flex-end'
    }
  });

  return (
    <>
      {state.snackbarVisible && (
        <View style={style.snackbar}>
          <Snackbar
            button={{
              testID: 'snackbar-close-icon',
              caption: 'dismiss',
              onPress: () => {
                setState({ snackbarVisible: false });
              }
            }}
          >
            {props.children}
          </Snackbar>
        </View>
      )}
    </>
  );
};
