import React from 'react';
import 'react-native';

import { ReceiptAuditSnackbar } from './receipt-audit-snackbar.component';

import { fireEvent, render } from '@testing-library/react-native';

describe('verify snackbar', () => {
  it('should display snackbar and verify fire close icon', async () => {
    const app = render(<ReceiptAuditSnackbar>test</ReceiptAuditSnackbar>);
    expect(app.queryByText(/test/)).toBeTruthy();
    expect(app.queryByTestId('snackbar-close-icon')).toBeTruthy();

    const closeIcon = app.getByTestId('snackbar-close-icon');

    fireEvent.press(closeIcon);

    expect(app.queryByText(/test/)).toBeFalsy();
  });

  it('should display snackbar and verify set timeout', async () => {
    jest.useFakeTimers('legacy');
    const app = render(<ReceiptAuditSnackbar>test</ReceiptAuditSnackbar>);
    expect(app.queryByText(/test/)).toBeTruthy();
    expect(app.queryByTestId('snackbar-close-icon')).toBeTruthy();

    expect(setTimeout).toHaveBeenCalledTimes(1);
    expect(setTimeout).toHaveBeenLastCalledWith(expect.any(Function), 3500);
    // Fast-forward until all timers have been executed
    jest.advanceTimersByTime(3500);

    expect(app.queryByText(/test/)).toBeFalsy();
    expect(app.queryByTestId('snackbar-close-icon')).toBeFalsy();
  });
});
