/* import {
  Caption,
  KeyboardIcon,
  TextField
} from '@walmart/gtp-shared-components';
import React, { FC, useState,Component  } from 'react';
import { Image, ImageSourcePropType, StyleSheet, View,Text,Alert,TouchableOpacity, } from 'react-native';
import Camera from 'react-native-camera';
interface Props {
  image?: ImageSourcePropType;
  onSubmit?: (input: State) => void;
  onInputValidation?: (input: State) => string | undefined;
}

interface State {
  value: string | undefined;
  errorMessage: string | undefined;
}

const style = StyleSheet.create({
  inputFormContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center'
  },
  image: {
    width: 170,
    height: 56
  },
  inputFieldContainer: {
    marginTop: 8,
    display: 'flex',
    flexDirection: 'row'
  },
  inputField: {
    flex: 1
  }
});

export const BarcodeSheetForm: FC<Props> = (props: Props): JSX.Element => {
  const [formInput, setFormInput] = useState<State>({
    value: undefined,
    errorMessage: undefined
  });

  return (
    <View style={style.inputFormContainer}>
      {!!props.image && (
        <>
          <Image
            style={style.image}
            accessibilityIgnoresInvertColors
            source={props.image}
          />
          <Caption>Example only</Caption>
        </>
      )}
      <View style={style.inputFieldContainer}>
        <TextField
          style={style.inputField}
          leadingIcon={<KeyboardIcon size={16} />}
          testID="barcode-number-input"
          value={formInput.value}
          onTextChange={input => {
            if (input && isNaN(input[input.length - 1] as any)) {
              return;
            }

            setFormInput(f => {
              return { ...f, value: input };
            });
          }}
          state={!formInput.errorMessage ? undefined : 'error'}
          errorMessage={formInput.errorMessage}
          onSubmitEditing={() => {
            const inputValidation =
              props.onInputValidation && props.onInputValidation(formInput);
            if (props.onSubmit && !inputValidation) {
              props.onSubmit(formInput);
            } else {
              setFormInput(f => {
                return {
                  ...f,
                  errorMessage: inputValidation
                };
              });
            }
          }}
          label="Type number"
          maxLength={24}
          keyboardType="number-pad"
        />
      </View>
    </View>
  );
};
 */


import React, { Component } from 'react';
import {
Text,
View,
StyleSheet,
Alert,
TouchableOpacity,
Image
} from 'react-native';
import Camera from 'react-native-camera';
export default class BarcodeScan extends Component {
constructor(props) {
super(props);
this.handleTourch = this.handleTourch.bind(this);
this.state = {
torchOn: false
}
}
onBarCodeRead = (e) => {
Alert.alert("Barcode value is" + e.data, "Barcode type is" + e.type);
}
render() {
return (
<View style={styles.container}>
<Camera
style={styles.preview}
torchMode={this.state.torchOn ? Camera.constants.TorchMode.on : Camera.constants.TorchMode.off}
onBarCodeRead={this.onBarCodeRead}
ref={cam => this.camera = cam}
aspect={Camera.constants.Aspect.fill}
>
<Text style={{
backgroundColor: 'white'
}}>BARCODE SCANNER</Text>
</Camera>
<View style={styles.bottomOverlay}>
<TouchableOpacity onPress={() => this.handleTourch(this.state.torchOn)}>
<Image style={styles.cameraIcon}
source={this.state.torchOn === true ? require('../../images/flasher_on.png') : require('../../images/flasher_off.png')} />
</TouchableOpacity>
</View>
</View>
)
}
handleTourch(value) {
if (value === true) {
this.setState({ torchOn: false });
} else {
this.setState({ torchOn: true });
}
}
}
const styles = StyleSheet.create({
container: {
flex: 1,
flexDirection: 'row',
},
preview: {
flex: 1,
justifyContent: 'flex-end',
alignItems: 'center'
},
cameraIcon: {
margin: 5,
height: 40,
width: 40
},
bottomOverlay: {
position: "absolute",
width: "100%",
flex: 20,
flexDirection: "row",
justifyContent: "space-between"
},
});