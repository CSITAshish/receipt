import {
  ExternalSizeProps,
  ExternalSmallProps,
  LoadingProps
} from '@walmart/gtp-shared-components/dist/buttons/base/themed-button';
import React, { FC } from 'react';
import { StyleSheet, View } from 'react-native';
import { PrimaryButton, SecondaryButton } from '@walmart/gtp-shared-components';

export declare type WideButtonProps = ExternalSizeProps &
  ExternalSmallProps &
  LoadingProps;

const style = StyleSheet.create({
  buttonContainer: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'stretch',
    width: '100%'
  },
  button: {
    marginTop: 8,
    alignItems: 'stretch'
  }
});

export const WidePrimaryButton: FC<WideButtonProps> = (
  props: WideButtonProps
): JSX.Element => {
  return (
    <View style={style.buttonContainer}>
      <PrimaryButton {...props} />
    </View>
  );
};

export const WideSecondaryButton: FC<WideButtonProps> = (
  props: WideButtonProps
): JSX.Element => {
  return (
    <View style={style.buttonContainer}>
      <SecondaryButton {...props} />
    </View>
  );
};
