import React from 'react';
import 'react-native';

import {
  WidePrimaryButton,
  WideSecondaryButton
} from './wide-button.component';

import { fireEvent, render } from '@testing-library/react-native';

describe('verify snackbar', () => {
  it('should display wide primary button', async () => {
    const app = render(
      <WidePrimaryButton
        testID="button"
        block={true}
        size="medium"
        onPress={() => jest.fn()}
      >
        Done
      </WidePrimaryButton>
    );
    expect(app.queryByText(/Done/)).toBeTruthy();
    expect(app.queryByTestId('button')).toBeTruthy();
    const doneButton = app.getByTestId('button');

    fireEvent.press(doneButton);
  });
  it('should display wide secondary button', async () => {
    const app = render(
      <WideSecondaryButton
        testID="button"
        block={true}
        size="medium"
        onPress={() => jest.fn()}
      >
        Done
      </WideSecondaryButton>
    );
    expect(app.queryByText(/Done/)).toBeTruthy();
    expect(app.queryByTestId('button')).toBeTruthy();
    const doneButton = app.getByTestId('button');

    fireEvent.press(doneButton);
  });
});
