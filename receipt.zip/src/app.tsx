import React from 'react';
import { ReceiptScan } from './views/receipt-scan/receipt-scan.component';
import { ItemScan } from './views/item-scan/item-scan.component';
import { LoadingPanel } from './views/loading-panel/loading-panel.component';
import { Routes } from './routes';
import { NotOnReceipt } from './views/not-on-receipt/not-on-receipt.component';
import { AuditFailure } from './views/audit-failure/audit-failure.component';
import { TransactionDetails } from './views/transaction-details/transaction-details.component';
import { LoggerCloneProvider } from '@walmart/core-services/Logger';
import { createStackNavigator } from '@react-navigation/stack';
import { Header } from '@walmart/ui-components';
import { AllsparkLogger } from './allspark.logger';
import { useEnvironment } from '@walmart/core-services/Environment';
import { ENVIRONMENT } from './services/environment';

const ReceiptAuditStack = createStackNavigator();

const RECEIPT_TITLE = 'Receipt Check';

export const App = (): JSX.Element => {
  const allSparkEnv = useEnvironment();
  ENVIRONMENT.useAllspark(allSparkEnv);
  return (
    <LoggerCloneProvider
      fields={{ id: 'receipt-audit-mini-app' }}
      ref={AllsparkLogger}
    >
      <LoadingPanel>
        <ReceiptAuditStack.Navigator
          initialRouteName={Routes.ReceiptScan}
          screenOptions={{
            header: Header
          }}
        >
          <ReceiptAuditStack.Screen
            name={Routes.ReceiptScan}
            options={{ title: RECEIPT_TITLE }}
            component={ReceiptScan}
          />
          <ReceiptAuditStack.Screen
            name={Routes.ItemScan}
            component={ItemScan}
            options={{ title: RECEIPT_TITLE }}
          />
          <ReceiptAuditStack.Screen
            name={Routes.NotOnReceipt}
            options={{ title: RECEIPT_TITLE }}
            component={NotOnReceipt}
          />
          <ReceiptAuditStack.Screen
            name={Routes.AuditFailure}
            options={{ title: RECEIPT_TITLE }}
            component={AuditFailure}
          />
          <ReceiptAuditStack.Screen
            name={Routes.TransactionDetails}
            options={{ title: '' }}
            component={TransactionDetails}
          />
        </ReceiptAuditStack.Navigator>
      </LoadingPanel>
    </LoggerCloneProvider>
  );
};
