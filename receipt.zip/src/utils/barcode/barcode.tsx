export type BarcodeType =
  | 'receipt_barcode'
  | 'item_barcode'
  | 'produce_not_supported'
  | 'unknown'
  | 'qr_code';

export const barcodeType = (type: string): BarcodeType => {
  let typeOfBarcode: BarcodeType = 'unknown';
  switch (type) {
    case 'LABEL-TYPE-CODE39':
    case 'LABEL-TYPE-CODE128':
      typeOfBarcode = 'receipt_barcode';
      break;
    case 'LABEL-TYPE-UPCA':
    case 'LABEL-TYPE-UPCE0':
    case 'LABEL-TYPE-EAN8':
    case 'LABEL-TYPE-EAN13':
      typeOfBarcode = 'item_barcode';
      break;
    case 'LABEL-TYPE-GS1-DATABAR':
    case 'LABEL-TYPE-GS1-DATABAR-EXPANDED':
      typeOfBarcode = 'produce_not_supported';
      break;
    case 'LABEL-TYPE-QRCODE':
      typeOfBarcode = 'qr_code';
      break;
  }
  return typeOfBarcode;
};
