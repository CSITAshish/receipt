import 'react-native';
import { barcodeType } from './barcode';

describe('test barcodeType', () => {
  it('barcodeType function', () => {
    expect(barcodeType('LABEL-TYPE-UPCA')).toEqual('item_barcode');
    expect(barcodeType('LABEL-TYPE-UPCE0')).toEqual('item_barcode');
    expect(barcodeType('LABEL-TYPE-EAN8')).toEqual('item_barcode');
    expect(barcodeType('LABEL-TYPE-EAN13')).toEqual('item_barcode');
    expect(barcodeType('LABEL-TYPE-GS1-DATABAR-EXPANDED')).toEqual(
      'produce_not_supported'
    );
    expect(barcodeType('LABEL-TYPE-GS1-DATABAR')).toEqual(
      'produce_not_supported'
    );
    expect(barcodeType('LABEL-TYPE-QRCODE')).toEqual('qr_code');
    expect(barcodeType('LABEL-TYPE-UPCE0')).toEqual('item_barcode');
    expect(barcodeType('LABEL-TYPE-CODE39')).toEqual('receipt_barcode');
    expect(barcodeType('LABEL-TYPE-CODE128')).toEqual('receipt_barcode');
  });
});
