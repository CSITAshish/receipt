import { appFetch } from './fetch';
import { server } from '../../../mocks/http.mock';
import 'react-native';
import { rest } from 'msw';

const fetchSuccessHandler = rest.get('https://marc.lore', (req, res, ctx) => {
  return res(ctx.delay(500), ctx.status(200), ctx.json({ marc: 'smart city' }));
});

const fetchErrorHandler = rest.get('https://fetchtest.com', (_, res, ctx) => {
  return res(ctx.status(500));
});

describe('appFetch', () => {
  it('should return successfully', async () => {
    server.use(fetchSuccessHandler);
    const response = await appFetch('https://marc.lore');
    const json = await response.json();

    expect(json).toStrictEqual({ marc: 'smart city' });
  });

  it('should throw fetch timeout', async () => {
    server.use(fetchSuccessHandler);
    await expect(
      appFetch('https://marc.lore', { timeout: 100 })
    ).rejects.toThrow();
  });

  it('should throw an error when throwError is set to true', async () => {
    server.use(fetchErrorHandler);
    const resp = appFetch('https://fetchtest.com', {
      timeout: 8000,
      retry: 2,
      throwError: true
    });

    await expect(resp).rejects.toThrow();
  });

  it('should throw network errors', async () => {
    await expect(appFetch('https://bad')).rejects.toThrow();
  });

  it('should return a response when throwError is false', async () => {
    server.use(fetchErrorHandler);
    const resp = appFetch('https://fetchtest.com', {
      throwError: false
    });

    await expect(resp).resolves.toBeDefined();
  });
});
