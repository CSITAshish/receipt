import Tracer from '@walmart/react-native-tracer';
import {
  catchError,
  from,
  lastValueFrom,
  mergeMap,
  of,
  retry,
  throwError,
  timeout,
  timer
} from 'rxjs';
import { LOGGER } from '../../app.logger';
import { LogMessageObject } from '../logger';

export interface FetchOptions {
  timeout?: number;
  retry?: number;
  tags?: string[];
  metadata?: Record<string, any>;
  throwError?: boolean;
}

export type RequestOptions = RequestInit & FetchOptions;

const elapsedMilliseconds = (
  totalStartTime: number,
  startTime: number,
  endTime: number
): { elapsedMilliseconds: number; totalElapsedMilliseconds: number } => {
  return {
    elapsedMilliseconds: endTime - startTime,
    totalElapsedMilliseconds: endTime - totalStartTime
  };
};

export const appFetch = async (
  input: RequestInfo,
  options?: RequestOptions
): Promise<Response> => {
  let abortController = new AbortController();
  options = !options ? ({} as RequestOptions) : options;

  if (!options.timeout || options.timeout < 0) {
    options.timeout = 30000;
  }
  if (!options.tags) {
    options.tags = [];
  }
  if (!options.metadata) {
    options.metadata = {};
  }
  if (!options.throwError) {
    options.throwError = false;
  }

  options.signal = !options.signal ? abortController.signal : options.signal;

  const traceparent = await Tracer.generateTraceparent({});
  const requestEnd = 'REQUEST-END';
  const logProps = {
    traceparent,
    ...options.metadata
  } as LogMessageObject;
  const endProps = {
    ...logProps,
    tags: [requestEnd, ...options.tags]
  } as LogMessageObject;
  const requestMessage = `${options?.method || 'GET'} - ${input}`;
  LOGGER.info({
    msg: requestMessage,
    ...logProps,
    tags: ['REQUEST-START', ...options.tags]
  });

  options.headers = new Headers({
    ...options.headers,
    traceparent
  });

  let aborted = false;
  let retryAttempt = 0;
  let startTime = Date.now();
  const totalStartTime = Date.now();

  return lastValueFrom(
    from(fetch(input, options)).pipe(
      catchError(e => {
        let msg = e;
        const possibleError = e as { name?: string };
        if (possibleError.name && possibleError.name.indexOf('Error') > -1) {
          const err = e as Error;
          msg = { stack: err.stack, message: err.message, name: err.name };
        }
        LOGGER.error({
          msg,
          ...elapsedMilliseconds(totalStartTime, startTime, Date.now())
        });
        return throwError(() => e);
      }),
      timeout({
        each: options.timeout,
        with: () => {
          if (abortController && options?.timeout) {
            abortController.abort();
            abortController = new AbortController();
            options.signal = abortController.signal;
            aborted = true;
          }

          return throwError(() => new Error('Timeout occured!'));
        }
      }),
      mergeMap(val => {
        if (!val.ok) {
          return from(val.clone().text()).pipe(
            mergeMap(r => {
              LOGGER.error({
                msg: r,
                status: val.status,
                ...elapsedMilliseconds(totalStartTime, startTime, Date.now()),
                ...endProps
              });
              return (!options?.retry ||
                options.retry <= 0 ||
                retryAttempt === options.retry) &&
                !options?.throwError
                ? of(val)
                : throwError(() => new Error(r));
            })
          );
        }

        LOGGER.info({
          msg: requestMessage,
          status: val.status,
          ...elapsedMilliseconds(totalStartTime, startTime, Date.now()),
          ...endProps
        });

        return of(val);
      }),
      retry({
        count: options.retry,
        delay: (err, count) => {
          retryAttempt = count + 1;

          const { tags = [] } = endProps;

          // if maximum number of retries have been met
          if (
            !options ||
            !options.retry ||
            options.retry < 0 ||
            retryAttempt > options.retry
          ) {
            if (aborted) {
              tags.push('REQUEST-ABORTED');
            }
            return throwError(() => err);
          }

          const retryTimer = Math.min(
            1000 * 2 ** (count + 1),
            options.timeout || 60000
          );

          LOGGER.info({
            msg: `${
              aborted ? 'Request aborted. ' : ''
            }Retrying ${requestMessage} after ${
              retryTimer / 1000
            }s. Attempt ${retryAttempt} of ${options.retry}`,
            ...elapsedMilliseconds(totalStartTime, startTime, Date.now()),
            ...endProps
          });
          aborted = false;

          startTime = Date.now() + retryTimer;

          // retry after 1s, 2s, etc...
          return timer(retryTimer);
        },
        resetOnSuccess: true
      })
    )
  );
};
