export type ErrorType =
  | 'rescan-item'
  | 'scan-another-receipt'
  | 'send-to-register'
  | 'send-to-service-desk'
  | 'take-item-back'
  | 'unknown';
