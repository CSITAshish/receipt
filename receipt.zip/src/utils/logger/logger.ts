import { LogEvent, LogLevel, LogLevelStrings, LogMessage } from './log.event';
import { LoggerOptionBuilder } from './logger.option.builder';
import { LoggerOptions } from './logger.options';

export class Logger {
  private _opt: LoggerOptions;

  constructor(opt: LoggerOptions) {
    this._opt = opt;
  }

  public level(logLevel: LogLevelStrings): Logger {
    this._opt.level = logLevel;
    return this;
  }

  private append(event: LogEvent): LogEvent {
    this._opt.appenders.forEach(app => {
      event = app.append(event);
    });
    return event;
  }

  private shouldLog(level: LogLevelStrings): boolean {
    const logLevelNum = LogLevel[level];
    const optLevelNum = LogLevel[this._opt.level];

    return logLevelNum <= optLevelNum ? true : false;
  }

  private transport(event: LogEvent): Logger {
    this._opt.transporters.forEach(tr => tr.transport(event));
    return this;
  }

  private send(
    level: LogLevelStrings,
    event: LogMessage | undefined = {},
    tags: string[] = []
  ): Logger {
    const tagData = tags.length > 0 ? tags : (event as any).tags;
    const timestamp = new Date().toISOString();
    if (this.isEventAString(event)) {
      event = { msg: event as string };
    } else if (this.isEventAnError(event)) {
      const err = event as Error;
      event = { stack: err.stack, msg: err.message, name: err.name };
    }

    let logEvent = {
      ...(event as LogEvent),
      tags: tagData,
      timestamp
    } as LogEvent;

    if (this.shouldLog(level)) {
      logEvent.level = level;
      logEvent = this.append(logEvent);
      this.transport(logEvent);
    }

    return this;
  }

  private isEventAString(event?: LogMessage): boolean {
    return !!event && (typeof event === 'string' || event instanceof String);
  }

  private isEventAnError(event?: LogMessage): boolean {
    const possibleError = event as { name?: string };
    return !!possibleError.name && possibleError.name.indexOf('Error') > -1;
  }

  public info(event?: LogMessage, ...tags: string[]): Logger {
    return this.send('INFO', event, tags);
  }

  public warn(event?: LogMessage, ...tags: string[]): Logger {
    return this.send('WARN', event, tags);
  }

  public debug(event?: LogMessage, ...tags: string[]): Logger {
    return this.send('DEBUG', event, tags);
  }

  public error(event?: LogMessage, ...tags: string[]): Logger {
    return this.send('ERROR', event, tags);
  }

  public static create(
    optBuilder: (opt: LoggerOptionBuilder) => LoggerOptionBuilder
  ): Logger {
    const opts = optBuilder(new LoggerOptionBuilder()).build();

    return new Logger(opts);
  }
}
