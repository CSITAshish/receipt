import { ConsoleTransporter } from './console.transporter';
import { LogAppender } from './log.appender';
import { LogLevelStrings } from './log.event';
import { LogTransporter } from './log.transporter';
import { LoggerOptions } from './logger.options';
import { SplunkTransporter } from './splunk.transporter';

export class LoggerOptionBuilder {
  private _opts: LoggerOptions;

  constructor(opts?: LoggerOptions) {
    this._opts =
      opts ||
      ({ level: 'ERROR', appenders: [], transporters: [] } as LoggerOptions);
  }

  public addAppender(appender: LogAppender): LoggerOptionBuilder {
    this._opts.appenders.push(appender);
    return this;
  }

  public addTransport(transport: LogTransporter): LoggerOptionBuilder {
    this._opts.transporters.push(transport);
    return this;
  }

  public useConsole(): LoggerOptionBuilder {
    return this.addTransport(new ConsoleTransporter());
  }

  public useSplunk(
    url: string,
    index: string,
    token: string
  ): LoggerOptionBuilder {
    return this.addTransport(new SplunkTransporter(url, token, index));
  }

  public logLevel(level: LogLevelStrings): LoggerOptionBuilder {
    this._opts.level = level;
    return this;
  }

  public build(): LoggerOptions {
    return this._opts;
  }
}
