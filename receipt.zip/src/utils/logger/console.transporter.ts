import { LogEvent } from './log.event';
import { LogTransporter } from './log.transporter';

export class ConsoleTransporter implements LogTransporter {
  transport(event: LogEvent): void {
    const msg = JSON.stringify(event, null, 2);
    switch (event.level) {
      case 'DEBUG':
        // eslint-disable-next-line no-console
        console.debug(msg);
        break;
      case 'WARN':
        // eslint-disable-next-line no-console
        console.warn(msg);
        break;
      case 'INFO':
        // eslint-disable-next-line no-console
        console.info(msg);
        break;
      case 'ERROR':
        // eslint-disable-next-line no-console
        console.error(msg);
        break;
    }
  }
}
