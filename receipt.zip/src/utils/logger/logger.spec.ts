import { Logger } from './logger';

describe('Logger', () => {
  let logger!: Logger;
  const debugSpy = jest.spyOn(console, 'debug').mockImplementation();
  const warnSpy = jest.spyOn(console, 'warn').mockImplementation();
  const errSpy = jest.spyOn(console, 'error').mockImplementation();
  const infoSpy = jest.spyOn(console, 'info').mockImplementation();

  beforeAll(() => {
    logger = Logger.create(opt => opt.useConsole().logLevel('INFO'));
  });

  afterEach(() => {
    logger.level('INFO');
    debugSpy.mockClear();
    warnSpy.mockClear();
    errSpy.mockClear();
    infoSpy.mockClear();
  });

  it('should send logs to console', () => {
    logger.error('yo');

    expect(errSpy).toBeCalledTimes(1);
  });

  it('should accept string messages', () => {
    logger.info('yo');

    expect(infoSpy).toBeCalledTimes(1);
    const call = JSON.stringify(infoSpy.mock.calls[0][0]);
    expect(call.includes('yo') && call.includes('timestamp')).toBeTruthy();
  });

  it('should accept object messages', () => {
    logger.info({ egg: true });

    expect(infoSpy).toBeCalledTimes(1);
    const call = JSON.stringify(infoSpy.mock.calls[0][0]);
    expect(call.includes('egg') && call.includes('timestamp')).toBeTruthy();
  });

  it('should accept tags', () => {
    logger.info('dfdfg', 'tag1', 'tag2');

    expect(infoSpy).toBeCalledTimes(1);
    const call = JSON.stringify(infoSpy.mock.calls[0][0]);
    expect(
      call.includes('tag1') &&
        call.includes('tag2') &&
        call.includes('timestamp')
    ).toBeTruthy();
  });

  it('should ignore logs of incorrect level', () => {
    logger.level('ERROR');

    logger.debug('fgfg').info('dfgd').warn('23423');

    expect(debugSpy).not.toHaveBeenCalled();
    expect(infoSpy).not.toHaveBeenCalled();
    expect(warnSpy).not.toHaveBeenCalled();
  });

  it('should call correct console method based on log level', () => {
    logger.level('DEBUG').debug('123').error('123').info('123').warn('123');

    expect(debugSpy).toHaveBeenCalledTimes(1);
    expect(warnSpy).toHaveBeenCalledTimes(1);
    expect(errSpy).toHaveBeenCalledTimes(1);
    expect(infoSpy).toHaveBeenCalledTimes(1);
  });
});
