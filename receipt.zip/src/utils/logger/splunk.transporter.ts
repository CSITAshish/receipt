import { LogEvent } from './log.event';
import { LogTransporter } from './log.transporter';

export class SplunkTransporter implements LogTransporter {
  constructor(
    public endpoint: string,
    public token: string,
    public index: string
  ) {}

  public transport(event: LogEvent): void {
    fetch(this.endpoint, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Splunk ${this.token}`
      },
      body: JSON.stringify({
        sourcetype: 'json',
        index: this.index,
        event
      })
    });
  }
}
