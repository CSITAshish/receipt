import { LogEvent } from './log.event';

export interface LogTransporter {
  transport(event: LogEvent): void;
}
