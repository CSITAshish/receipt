import { LogAppender } from './log.appender';
import { LogLevelStrings } from './log.event';
import { LogTransporter } from './log.transporter';

export interface LoggerOptions {
  level: LogLevelStrings;
  transporters: LogTransporter[];
  appenders: LogAppender[];
}
