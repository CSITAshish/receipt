import { LogEvent } from './log.event';

export interface LogAppender {
  append(log: LogEvent): LogEvent;
}
