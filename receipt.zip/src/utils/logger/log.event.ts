export interface LogEvent extends Record<string, any> {
  tags: Array<string>;
  msg: string;
  timestamp: string;
  level: LogLevelStrings;
}

export type LogMessageObject = Omit<
  LogEvent,
  'timestamp' | 'msg' | 'tags' | 'level'
>;
export type LogMessage = LogMessageObject | string;

export enum LogLevel {
  ERROR,
  WARN,
  INFO,
  DEBUG
}

export type LogLevelStrings = keyof typeof LogLevel;
