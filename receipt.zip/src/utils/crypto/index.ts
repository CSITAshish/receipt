import { NativeModules } from 'react-native';

interface ICrypto {
  withRsaSHA256: (message: string, privateKey: string) => Promise<string>;
}
const { CryptoModule } = NativeModules;
export const Crypto: ICrypto = CryptoModule;
