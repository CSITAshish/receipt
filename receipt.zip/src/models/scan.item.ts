export type ScanItemState = 'valid' | 'error' | 'pending' | 'failed';

export type ActionTaken =
  | 'SENT_CUSTOMER_TO_CHECKOUT'
  | 'RECOVERED_ITEM_AT_DOOR'
  | null;
export interface ScanItem {
  title?: string;
  upc?: string;
  scanned: boolean;
  state: ScanItemState;
  skipped: boolean;
  actionTaken: ActionTaken;
}
