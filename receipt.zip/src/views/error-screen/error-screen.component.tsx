import React, { FC, useEffect } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import Truck from '../../assets/images/truck.png';
import Cat from '../../assets/images/cat.png';
import { Body, LinkButton } from '@walmart/gtp-shared-components';
import { ErrorType, ERROR_SERVICE } from '../../services/error/error.service';
import { useErrorState } from '../../hooks/error-state.hook';
import { useLoading } from '../loading-panel/loading-panel.component';

const styles = StyleSheet.create({
  errorContainer: {
    display: 'flex',
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    padding: 16,
    marginBottom: 48
  },
  imageContainer: {
    width: 148,
    height: 148,
    display: 'flex',
    flexDirection: 'row',
    alignSelf: 'center'
  },
  textContainer: {
    textAlign: 'center',
    margin: 8
  }
});

export type ErrorState = [
  ErrorType | undefined,
  React.Dispatch<React.SetStateAction<ErrorType | undefined>>
];

export const ErrorProvider: FC = ({ children }): JSX.Element => {
  const errorType = useErrorState();
  const { loading, setLoading } = useLoading();

  useEffect(() => {
    if (errorType && loading) {
      setLoading(false);
    }
  }, [errorType, loading, setLoading]);

  return (
    <>
      {!errorType && children}
      {!!errorType && (
        <View style={styles.errorContainer}>
          <Image
            style={styles.imageContainer}
            source={errorType === 'error' ? Truck : Cat}
            accessibilityIgnoresInvertColors
          />
          <Body style={styles.textContainer}>
            {errorType === 'error'
              ? "Sorry! We're having technical issue. Give us a few minutes to fix it. If the issue persists, please open a ticket in Fixit."
              : "Uh oh! It looks like you've lost connection. Please check tunnel and try again."}
          </Body>
          <LinkButton
            onPress={() => {
              ERROR_SERVICE.next(undefined);
            }}
          >
            Try again
          </LinkButton>
        </View>
      )}
    </>
  );
};
