import React from 'react';
import 'react-native';

import { ItemScanBottomSheet } from './item-scan-bottom-sheet.component';

import { fireEvent, render, cleanup } from '@testing-library/react-native';
import { ScanItem } from '../../models/scan.item';
const items = [
  {
    title: 'temp',
    upc: '1234',
    scanned: true,
    state: 'pending',
    skipped: false
  },
  {
    title: 'Scan barcode',
    upc: 'UPC #',
    scanned: false,
    state: 'pending',
    skipped: false
  },
  {
    title: 'Scan barcode',
    upc: 'UPC #',
    scanned: false,
    state: 'pending',
    skipped: false
  }
] as ScanItem[];
const props = {
  onSkip: jest.fn(),
  item: items
};
describe('Item Scan Screen', () => {
  afterEach(() => {
    cleanup();
  });
  it('should render', () => {
    const app = render(<ItemScanBottomSheet {...props} />);
    expect(app).toBeTruthy();
  });

  it('should call onSkip from the first onSkip event', async () => {
    const app = render(<ItemScanBottomSheet {...props} />);

    const skipButton = app.getByTestId('on-skip-1');

    fireEvent.press(skipButton);

    expect(props.onSkip).toHaveBeenCalledTimes(1);
  });

  it('should call onSkip from the second onSkip event', async () => {
    const app = render(<ItemScanBottomSheet {...props} />);

    const skipButton = app.getByTestId('on-skip-2');

    fireEvent.press(skipButton);

    expect(props.onSkip).toHaveBeenCalledTimes(2);
  });
});
