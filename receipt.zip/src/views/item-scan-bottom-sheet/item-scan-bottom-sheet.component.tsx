import React, { FC } from 'react';
import { StyleSheet, View } from 'react-native';
import colors from '@walmart/gtp-shared-components/dist/theme/colors.json';
import {
  LinkButton,
  List,
  BarcodeIcon,
  CheckCircleFillIcon,
  Caption2,
  Subheader,
  Body2,
  Body,
  Divider,
  CheckIcon,
  CloseCircleFillIcon
} from '@walmart/gtp-shared-components';
import { ScanItem, ScanItemState } from '../../models/scan.item';

interface Props {
  onSkip: (idx: number) => void;
  item: ScanItem[];
  alert: boolean;
}

export const styles = StyleSheet.create({
  contentContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start'
  },

  itemScanImage: {
    width: 360,
    height: 198
  },
  scanBarcodeText: {
    marginTop: 8
  },
  typeUpc: {
    marginTop: 24,
    alignSelf: 'flex-start'
  },
  userCircle: {
    justifyContent: 'center',
    width: 24,
    height: 24,
    borderRadius: 24 / 2,
    borderColor: colors.black,
    borderWidth: 2
  },
  userCircleText: {
    color: colors.black,
    textAlign: 'center'
  },
  amount: {
    color: '#74767C'
  },
  divider: {
    paddingTop: 0,
    paddingBottom: 20
  },
  divider2: {
    padding: 80,
    margin: 10
  },
  body: {
    color: '#1D5F02'
  },
  container: {
    display: 'flex',
    flexDirection: 'row'
  },
  checkIcon: {
    marginTop: 3
  }
});
const CircleComponent: FC<{ children: number }> = (props: {
  children: number;
}): JSX.Element => {
  return (
    <View style={styles.userCircle}>
      <Body2 style={styles.userCircleText}>{props.children}</Body2>
    </View>
  );
};

const leadingIcon = (state: ScanItemState, idx: number): JSX.Element => {
  let component: JSX.Element;
  switch (state) {
    case 'valid':
      component = <CheckCircleFillIcon size={24} color={'#2A8703'} />;
      break;
    case 'pending':
      component = <CircleComponent>{idx + 1}</CircleComponent>;
      break;
    case 'error':
    case 'failed':
      component = <CloseCircleFillIcon size={24} color={colors.red[100]} />;
      break;
  }

  return component;
};

export const ItemScanBottomSheet: FC<Props> = (props: Props): JSX.Element => {
  return (
    <View
      style={props.alert ? [styles.contentContainer] : styles.contentContainer}
    >
      <Divider style={styles.divider} color="#E3E4E5" />
      <List
        separator={true}
        items={
          props.item.map((item, idx) => {
            return {
              title: <Caption2>{item.title}</Caption2>,
              content: (
                <>
                  <Subheader>{item.upc}</Subheader>
                  <Subheader style={styles.amount}>{idx + 1} of 3</Subheader>
                </>
              ),
              leading: item.scanned ? (
                leadingIcon(item.state, idx)
              ) : (
                <BarcodeIcon size={24} />
              ),
              trailing:
                idx > 0 &&
                !item.scanned &&
                (item.skipped && item.state !== 'failed' ? (
                  <View style={styles.container}>
                    <CheckIcon
                      style={styles.checkIcon}
                      color="#1D5F02"
                      size={16}
                    />
                    <Body style={styles.body}> Skipped</Body>
                  </View>
                ) : (
                  <LinkButton
                    testID={'on-skip-' + idx}
                    onPress={() => {
                      props.onSkip(idx);
                    }}
                  >
                    Skip
                  </LinkButton>
                ))
            };
          }) as any
        }
      />
      {props.alert && <Divider style={styles.divider2} color="#FFFFFF" />}
    </View>
  );
};
