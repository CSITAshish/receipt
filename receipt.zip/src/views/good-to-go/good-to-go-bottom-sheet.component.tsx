import { Subheader, Display } from '@walmart/gtp-shared-components';
import React, { FC } from 'react';
import { StyleSheet, View, Image } from 'react-native';
import GoodToGoImage from '../../assets/images/Good-to-go-illustration.png';
import { WidePrimaryButton } from '../../components/wide-button/wide-button.component';

interface Props {
  onAction?: (action: 'done') => void;
}

const style = StyleSheet.create({
  goodToGoContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  goodToGoImage: {
    marginTop: 16,
    height: 166,
    width: 210,
    justifyContent: 'center'
  },
  doneButton: {
    marginTop: 16,
    alignItems: 'stretch'
  },
  subHeading: {
    color: '#002D58',
    marginTop: 16,
    textAlign: 'center'
  },
  display: {
    marginTop: 16,
    textAlign: 'center'
  }
});

export const GoodToGoBottomSheet: FC<Props> = (props: Props): JSX.Element => {
  return (
    <View style={style.goodToGoContainer} testID="good-to-go-bottom-sheet">
      <Image
        accessibilityIgnoresInvertColors={true}
        testID="good-to-go-image"
        style={style.goodToGoImage}
        source={GoodToGoImage}
      />
      <Display style={style.display}>Customer is good to go!</Display>
      <Subheader style={style.subHeading}>
        Thank them for being an important part of the Walmart family.
      </Subheader>
      <WidePrimaryButton
        testID="done-button"
        block={true}
        style={style.doneButton}
        size="medium"
        onPress={() => props.onAction && props.onAction('done')}
      >
        Done
      </WidePrimaryButton>
    </View>
  );
};
