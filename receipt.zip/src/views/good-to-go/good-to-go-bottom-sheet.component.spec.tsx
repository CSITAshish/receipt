import React from 'react';
import 'react-native';

import { fireEvent, render } from '@testing-library/react-native';
import { GoodToGoBottomSheet } from './good-to-go-bottom-sheet.component';

describe('Sign out bottom sheet', () => {
  it('should render', () => {
    expect(render(<GoodToGoBottomSheet />)).toBeTruthy();
  });

  it('should fire sign out when sign out button pressed', () => {
    const onAction = jest.fn();
    const signOut = render(<GoodToGoBottomSheet onAction={onAction} />);

    const signOutButton = signOut.getByTestId('done-button');

    fireEvent.press(signOutButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('done');
  });
});
