import React from 'react';
import 'react-native';
import { fireEvent, render } from '@testing-library/react-native';
import { UpcForm } from './upc-form.component';

describe('Upc Form', () => {
  it('should render', () => {
    const app = render(<UpcForm onUpc={() => {}} />);
    expect(app).toBeTruthy();
  });

  it('should return a valid upc', () => {
    const onUpc = jest.fn();
    const app = render(<UpcForm onUpc={onUpc} />);

    const upcNumberInput = app.getByTestId('barcode-number-input');

    fireEvent.changeText(upcNumberInput, '2343asda');

    fireEvent(upcNumberInput, 'submitEditing');

    expect(onUpc).not.toHaveBeenCalled();

    fireEvent.changeText(upcNumberInput, '04227201024');

    fireEvent(upcNumberInput, 'submitEditing');

    expect(onUpc).toHaveBeenCalledTimes(1);
  });
});
