import React, { FC } from 'react';
import { BarcodeSheetForm } from '../../components/barcode-sheet-form/barcode-sheet-form.component';
import UpcNumberBarcode from '../../assets/images/upc-number-barcode.png';
import UPC from 'cpc-input';

interface Props {
  onUpc: (input: string) => void;
}

const validUpc = (input: string | undefined): string | undefined => {
  const upc = new UPC(input || '');
  return upc.parsed && !upc.error
    ? upc.isPLU
      ? 'Produce items are not supported, please scan another item.'
      : undefined
    : 'Invalid UPC';
};

export const UpcForm: FC<Props> = (props: Props): JSX.Element => {
  return (
    <BarcodeSheetForm
      image={UpcNumberBarcode}
      onInputValidation={state => validUpc(state.value)}
      onSubmit={state => props.onUpc(state.value || '')}
    />
  );
};
