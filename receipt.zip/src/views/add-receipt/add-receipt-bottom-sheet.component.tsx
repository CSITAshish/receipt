import { Display } from '@walmart/gtp-shared-components';
import React, { FC } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import ReciptImage from '../../assets/images/receipt-illustration.png';
import {
  WidePrimaryButton,
  WideSecondaryButton
} from '../../components/wide-button/wide-button.component';

interface Props {
  onAction?: (action: 'add-to-current-receipt' | 'start-new-receipt') => void;
}

const style = StyleSheet.create({
  addReceiptContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'
  },
  display: {
    textAlign: 'center'
  },
  button: {
    margin: 8,
    alignItems: 'stretch'
  },
  reciptImage: {
    marginTop: 8,
    marginBottom: 32,
    width: 128,
    height: 141
  }
});

export const AddReceiptBottomSheet: FC<Props> = (props: Props): JSX.Element => {
  return (
    <View style={style.addReceiptContainer} testID="add-receipt-bottom-sheet">
      <Image
        accessibilityIgnoresInvertColors={true}
        testID="add-reciept-image"
        style={style.reciptImage}
        source={ReciptImage}
      />
      <Display style={style.display}>
        Is this receipt for a new customer?
      </Display>
      <WidePrimaryButton
        testID="yes-start-new-button"
        style={style.button}
        block
        size="medium"
        onPress={() => props.onAction && props.onAction('start-new-receipt')}
      >
        No, add to existing
      </WidePrimaryButton>
      <WideSecondaryButton
        style={style.button}
        block
        size="medium"
        testID="no-add-existing-button"
        onPress={() =>
          props.onAction && props.onAction('add-to-current-receipt')
        }
      >
        Yes, start a new check
      </WideSecondaryButton>
    </View>
  );
};
