import React from 'react';
import 'react-native';

import { fireEvent, render } from '@testing-library/react-native';
import { AddReceiptBottomSheet } from './add-receipt-bottom-sheet.component';

describe('Add receipt bottom sheet', () => {
  it('should render', () => {
    expect(render(<AddReceiptBottomSheet />)).toBeTruthy();
  });
  it('test UI component presence', async () => {
    const app = render(<AddReceiptBottomSheet />);

    expect(app.queryByText(/Is this receipt for a new customer?/)).toBeTruthy();

    expect(app.queryByText(/No, add to existing/)).toBeTruthy();

    expect(app.queryByText(/Yes, start a new check/)).toBeTruthy();
  });
  it("should display 'receipt-illustration.png'", () => {
    const addReceiptScreen = render(<AddReceiptBottomSheet />);
    expect(addReceiptScreen.getByTestId('add-reciept-image')).toBeTruthy();
  });
  it('should display Yes button', () => {
    const addReceiptScreen = render(<AddReceiptBottomSheet />);
    expect(addReceiptScreen.getByTestId('yes-start-new-button')).toBeTruthy();
  });
  it('should display No button', () => {
    const addReceiptScreen = render(<AddReceiptBottomSheet />);
    expect(addReceiptScreen.getByTestId('no-add-existing-button')).toBeTruthy();
  });
  it('should fire cancel when Yes button pressed', () => {
    const onAction = jest.fn();
    const signOut = render(<AddReceiptBottomSheet onAction={onAction} />);

    const cancelSignOutButton = signOut.getByTestId('yes-start-new-button');

    fireEvent.press(cancelSignOutButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('start-new-receipt');
  });
  it('should fire cancel when No button pressed', () => {
    const onAction = jest.fn();
    const signOut = render(<AddReceiptBottomSheet onAction={onAction} />);

    const cancelSignOutButton = signOut.getByTestId('no-add-existing-button');

    fireEvent.press(cancelSignOutButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('add-to-current-receipt');
  });
});
