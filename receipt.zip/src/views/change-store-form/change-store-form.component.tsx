import React, { FC } from 'react';
import { BarcodeSheetForm } from '../../components/barcode-sheet-form/barcode-sheet-form.component';

interface Props {
  onStore: (input: string) => void;
}

const validStore = (input: string | undefined): string | undefined => {
  return isNaN(input as any) || (input && input.length > 4)
    ? 'Not a valid store number.'
    : undefined;
};

export const StoreForm: FC<Props> = (props: Props): JSX.Element => {
  return (
    <BarcodeSheetForm
      onInputValidation={state => validStore(state.value)}
      onSubmit={state => props.onStore(state.value || '')}
    />
  );
};
