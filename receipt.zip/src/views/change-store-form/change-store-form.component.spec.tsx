import React from 'react';
import 'react-native';
import { render } from '@testing-library/react-native';
import { StoreForm } from './change-store-form.component';

describe('Store Form', () => {
  it('should render', () => {
    const app = render(<StoreForm onStore={() => {}} />);
    expect(app).toBeTruthy();
  });
});
