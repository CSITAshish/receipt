import React, { FC, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import colors from '@walmart/gtp-shared-components/dist/theme/colors.json';
import {
  BottomSheet,
  Caption,
  CloseIcon
} from '@walmart/gtp-shared-components';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import { TransparentIconButton } from '@walmart/gtp-shared-components/dist/buttons';
import { ENVIRONMENT } from '../../services/environment';

interface UserActions {
  name: string;
  title?: string;
  icon: JSX.Element;
  route?: string;
  bottomSheet?: (
    bottomSheetState: React.Dispatch<
      React.SetStateAction<JSX.Element | undefined>
    >
  ) => JSX.Element;
}
interface Props {
  actions: UserActions[];
  onRoute: (name: string) => void;
  userName: string | undefined;
}

const style = StyleSheet.create({
  itemContainer: {
    padding: 8,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center'
  },
  item: {
    margin: 8
  },
  grayBottomBorder: {
    borderBottomColor: colors.gray[10],
    borderBottomWidth: 1
  },
  userCircle: {
    justifyContent: 'center',
    width: 40,
    height: 40,
    borderRadius: 40 / 2,
    backgroundColor: colors.blue[100]
  },
  userCircleText: {
    color: colors.white,
    textAlign: 'center'
  },
  occupySpace: {
    flex: 1
  },
  closeButton: {
    justifyContent: 'flex-end'
  },
  footer: {
    justifyContent: 'center',
    height: 50,
    flexDirection: 'row'
  }
});

function initials(value: string): string {
  let result = '';
  const tokens = value.split(/\s/);
  for (let i = 0; i < tokens.length; i++) {
    result += tokens[i].substring(0, 1).toUpperCase();
  }
  return result;
}

export const AppDrawer: FC<Props> = (props: Props): JSX.Element => {
  const [bottomSheet, setBottomSheet] = useState<JSX.Element>();
  const [title, setTitle] = useState<string>();

  return (
    <>
      <View testID="drawer-content" style={style.occupySpace}>
        <View style={style.occupySpace}>
          <View
            style={{
              ...style.grayBottomBorder,
              ...style.itemContainer
            }}
          >
            <View style={style.userCircle}>
              <Caption style={style.userCircleText}>
                {!!props.userName && initials(props.userName)}
              </Caption>
            </View>
            <Caption style={style.item}>{props.userName}</Caption>
            <TransparentIconButton
              testID="close-drawer-icon-button"
              style={{ ...style.closeButton, ...style.occupySpace }}
              onPress={() => props.onRoute('close')}
              icon={<CloseIcon size={16} />}
            />
          </View>
          <ScrollView style={style.occupySpace}>
            {props.actions.map((action, idx) => (
              <TouchableOpacity
                key={action.name}
                testID={action.name}
                accessibilityRole="button"
                onPress={() => {
                  if (action.route) {
                    props.onRoute(action.route);
                  }

                  if (action.bottomSheet) {
                    setTitle(action.title);
                    setBottomSheet(action.bottomSheet(setBottomSheet));
                  }
                }}
                style={
                  idx !== props.actions.length - 1
                    ? { ...style.grayBottomBorder, ...style.itemContainer }
                    : style.itemContainer
                }
              >
                {action.icon}
                <Caption style={style.item}>{action.name}</Caption>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        <View style={style.footer}>
          <Caption>Version {ENVIRONMENT.versionWithEnv}</Caption>
        </View>
      </View>
      <BottomSheet
        dismissable={false}
        visible={!!bottomSheet}
        title={title}
        minimumContentHeight={0}
        resizable={false}
        onDismiss={() => setBottomSheet(undefined)}
      >
        {bottomSheet}
      </BottomSheet>
    </>
  );
};
