import React from 'react';
import { Button, Text } from 'react-native';

import {
  fireEvent,
  render,
  waitForElementToBeRemoved
} from '@testing-library/react-native';
import { AppDrawer } from './app-drawer.component';

describe('App Drawer', () => {
  it('should render', () => {
    const drawer = render(
      <AppDrawer actions={[]} onRoute={jest.fn()} userName={'Test'} />
    );

    expect(drawer).toBeTruthy();
  });

  it('should navigate on press of drawer action', () => {
    const onRoute = jest.fn();
    const drawer = render(
      <AppDrawer
        actions={[
          { name: 'test-1', icon: <Text>Yo</Text>, route: 'test-1' },
          { name: 'test-2', icon: <Text>Yo</Text>, route: 'test-2' }
        ]}
        onRoute={onRoute}
        userName={'Test'}
      />
    );

    const test1 = drawer.getByTestId('test-1');
    const test2 = drawer.getByTestId('test-2');

    fireEvent.press(test1);

    expect(onRoute).toHaveBeenCalledWith('test-1');

    fireEvent.press(test2);

    expect(onRoute).toHaveBeenCalledWith('test-2');
    expect(onRoute).toHaveBeenCalledTimes(2);
  });

  it('should close drawer via icon', () => {
    const onRoute = jest.fn();
    const drawer = render(
      <AppDrawer actions={[]} onRoute={onRoute} userName={'Test'} />
    );

    const closeIconButton = drawer.getByTestId('close-drawer-icon-button');

    fireEvent.press(closeIconButton);

    expect(onRoute).toBeCalledWith('close');
    expect(onRoute).toBeCalledTimes(1);
  });

  it('should display bottom sheet on press of drawer action', async () => {
    const onRoute = jest.fn();
    const drawer = render(
      <AppDrawer
        actions={[
          {
            name: 'test-1',
            icon: <Text>Yo</Text>,
            bottomSheet: sheetState => (
              <Button
                title="test-1-button"
                testID="test-1-button"
                onPress={() => {
                  sheetState(undefined);
                }}
              >
                Test1
              </Button>
            )
          }
        ]}
        onRoute={onRoute}
        userName={'Test'}
      />
    );

    const test1 = drawer.getByTestId('test-1');

    fireEvent.press(test1);

    const drawerButton = drawer.getByTestId('test-1-button');

    expect(drawerButton).toBeTruthy();

    fireEvent.press(drawerButton);

    await waitForElementToBeRemoved(() =>
      drawer.queryByTestId('test-1-button')
    );
  });
});
