import React, { FC, useState } from 'react';
import { Image, View, StyleSheet } from 'react-native';
import {
  RadioItemGroup,
  Display2,
  Subheader
} from '@walmart/gtp-shared-components';
import BarcodeImage from '../../assets/images/Barcode-illustration.png';
import { WidePrimaryButton } from '../../components/wide-button/wide-button.component';

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  centerImage: {
    marginTop: 8,
    height: 102,
    width: 102,
    justifyContent: 'center'
  },
  heading: {
    marginTop: 0,
    marginBottom: 8,
    maxWidth: 328,
    textAlign: 'center',
    justifyContent: 'center'
  },
  body: {
    marginTop: 8,
    textAlign: 'center'
  },
  radioButtons: {
    marginTop: 8,
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  item: {
    marginLeft: 64,
    marginTop: 8
  },
  doneButton: {
    marginTop: 8,
    marginHorizontal: 16,
    alignItems: 'stretch',
    height: 40
  },
  subheader: {
    paddingHorizontal: 16
  },
  divider: {
    paddingTop: 8,
    paddingBottom: 0
  },
  footer: {
    marginBottom: 16
  }
});

const Items = [
  { label: 'Scan another receipt', id: '1', testId: 'first-radio' },
  { label: 'Send customer to a register', id: '2', testId: 'second-radio' },
  {
    label: 'Take back item and let customer exit',
    id: '3',
    testId: 'third-radio'
  }
];

export const AuditFailure: FC = (): JSX.Element => {
  const [selectItem, setSelectItem] = useState('1');
  const onTypeSelect = (id: string): void => {
    setSelectItem(id);
  };
  return (
    <>
      <View style={styles.container}>
        <Image
          accessibilityIgnoresInvertColors={true}
          testID="barcode-image"
          style={styles.centerImage}
          source={BarcodeImage}
        />
        <Display2 style={styles.heading} testID="sorry-display">
          Select what you would like to do next
        </Display2>
      </View>
      <View style={styles.radioButtons}>
        <Subheader style={styles.subheader}>Choose your next step</Subheader>
        <RadioItemGroup
          items={Items}
          onSelect={onTypeSelect}
          selectedId={selectItem}
        />
      </View>
      <View style={styles.footer}>
        <WidePrimaryButton
          testID="continue-button"
          block={true}
          style={styles.doneButton}
          size="medium"
          onPress={() => {}}
        >
          Continue
        </WidePrimaryButton>
      </View>
    </>
  );
};
