import 'react-native';
import React from 'react';
import { AuditFailure } from './audit-failure.component';
import { render, fireEvent } from '@testing-library/react-native';

describe('Sign in Screen', () => {
  it('should render correctly', () => {
    expect(render(<AuditFailure />)).toBeTruthy();
  });
  it("should display 'SignInPageImage.png'", () => {
    const auditFailure = render(<AuditFailure />);
    expect(auditFailure.getByTestId('barcode-image')).toBeTruthy();
  });
  it("should display 'Select what you would like to do next'", () => {
    const auditFailure = render(<AuditFailure />);
    expect(
      auditFailure.getByText('Select what you would like to do next')
    ).toBeTruthy();
    expect(auditFailure.getByText('Choose your next step')).toBeTruthy();
  });
  it('radio buttons should have text and clickable', () => {
    const auditFailure = render(<AuditFailure />);

    expect(auditFailure.getByText('Scan another receipt')).toBeTruthy();
    expect(auditFailure.getByText('Send customer to a register')).toBeTruthy();
    expect(
      auditFailure.getByText('Take back item and let customer exit')
    ).toBeTruthy();

    const radioSecond = auditFailure.getByText('Scan another receipt');

    fireEvent.press(radioSecond);
  });
});
