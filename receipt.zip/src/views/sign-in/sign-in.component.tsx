import React, { FC } from 'react';
import { Image, View, StyleSheet } from 'react-native';
import {
  PrimaryButton,
  Display,
  Title2,
  Caption
} from '@walmart/gtp-shared-components';
import SignInPageImage from '../../assets/images/sign-in-page.png';
import { ENVIRONMENT } from '../../services/environment';
import { useSSOLogin } from '../../hooks/sso.hook';
import { ErrorProvider } from '../error-screen/error-screen.component';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    zIndex: 5,
    paddingTop: 20,
    alignItems: 'center'
  },
  centerImage: {
    paddingTop: 20,
    height: 220,
    width: 220,
    justifyContent: 'center'
  },
  heading: {
    paddingTop: 20,
    color: '#002D58'
  },
  body: {
    paddingTop: 20,
    textAlign: 'center',
    color: '#002D58'
  },
  button: {
    paddingTop: 20
  },
  footer: {
    justifyContent: 'center',
    height: 50
  }
});

export const SignIn: FC = (): JSX.Element => {
  const sso = useSSOLogin();
  return (
    <ErrorProvider>
      <View style={styles.container}>
        <View style={styles.container}>
          <Image
            accessibilityIgnoresInvertColors={true}
            testID="sign-in-image"
            style={styles.centerImage}
            source={SignInPageImage}
          />
          <Display style={styles.heading} testID="sign-in-heading">
            Receipt Check
          </Display>
          <Title2 style={styles.body} testID="sign-in-body">
            Sign in to start scanning receipts and products.
          </Title2>
          <PrimaryButton
            style={styles.button}
            testID="sign-in-button"
            onPress={() => {
              sso.signIn();
            }}
          >
            Sign In
          </PrimaryButton>
        </View>
        <View style={styles.footer}>
          <Caption>Version {ENVIRONMENT.versionWithEnv}</Caption>
        </View>
      </View>
    </ErrorProvider>
  );
};
