import 'react-native';
import React from 'react';
import { SignIn } from './sign-in.component';
import WMSingleSignOn from 'react-native-ssmp-sso-allspark';
import { fireEvent, render } from '@testing-library/react-native';
import { Header } from '../header/header.component';
let onMenuPress: jest.Mock<any, any>;

describe('Sign in Screen', () => {
  it('should render correctly', () => {
    expect(render(<SignIn />)).toBeTruthy();
  });
  it("should display 'SignInPageImage.png'", () => {
    const signInScreen = render(<SignIn />);
    expect(signInScreen.getByTestId('sign-in-image')).toBeTruthy();
  });
  it("should display 'Receipt Check'", () => {
    const signInScreen = render(<SignIn />);
    expect(signInScreen.getByText('Receipt Check')).toBeTruthy();
  });
  it("should display 'Sign in to start scanning receipts and products.'", () => {
    const signInScreen = render(<SignIn />);
    expect(
      signInScreen.getByText('Sign in to start scanning receipts and products.')
    ).toBeTruthy();
  });
  it("'Sign In' Button", () => {
    const signInScreen = render(<SignIn />);
    const signInAction = signInScreen.getByTestId('sign-in-button');
    fireEvent.press(signInAction);
    expect(WMSingleSignOn.signIn).toHaveBeenCalledTimes(1);
  });
  it('should show left chevron when can go back', () => {
    onMenuPress = jest.fn();

    const header = render(
      <Header title={'Test'} menuPress={onMenuPress} signedIn={false} />
    );

    fireEvent.press(header.getByTestId('drawer-menu-button'));

    expect(onMenuPress).toHaveBeenCalledTimes(0);
  });
});
