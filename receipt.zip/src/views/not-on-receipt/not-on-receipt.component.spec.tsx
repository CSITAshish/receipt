import 'react-native';
import React from 'react';
import { NotOnReceipt } from './not-on-receipt.component';
import { render, fireEvent } from '@testing-library/react-native';

describe('Sign in Screen', () => {
  it('should render correctly', () => {
    const onContinue = jest.fn();
    expect(
      render(
        <NotOnReceipt title={'one'} upc={'1234'} onContinue={onContinue()} />
      )
    ).toBeTruthy();
  });
  it("should display 'SignInPageImage.png'", () => {
    const onContinue = jest.fn();
    const notOnReceiptScreen = render(
      <NotOnReceipt title={'one'} upc={'1234'} onContinue={onContinue()} />
    );
    expect(notOnReceiptScreen.getByTestId('barcode-image')).toBeTruthy();
  });
  it.skip("should display 'Sorry...' and 'Unfortunately, this item isn’t on the receipt.'", () => {
    const onContinue = jest.fn();
    const notOnReceiptScreen = render(
      <NotOnReceipt title={'one'} upc={'1234'} onContinue={onContinue()} />
    );
    expect(notOnReceiptScreen.getByText('Sorry...')).toBeTruthy();
    expect(
      notOnReceiptScreen.getByText(
        'Unfortunately, this item isn’t on the receipt.'
      )
    ).toBeTruthy();
  });
  it('should display the correct item that is passed into the component', () => {
    const onContinue = jest.fn();
    const notOnReceiptScreen = render(
      <NotOnReceipt
        title={'Tide Original He, 25 Loads Liquid...'}
        upc={'1234567890989'}
        onContinue={onContinue()}
      />
    );
    expect(
      notOnReceiptScreen.getByText('Tide Original He, 25 Loads Liquid...')
    ).toBeTruthy();
    expect(notOnReceiptScreen.getByText('1234567890989')).toBeTruthy();
  });
  it.skip('radio buttons should have text and clickable', () => {
    const onContinue = jest.fn();
    const notOnReceiptScreen = render(
      <NotOnReceipt title={''} upc={''} onContinue={onContinue()} />
    );
    expect(
      notOnReceiptScreen.getByText('Try scanning the item again')
    ).toBeTruthy();
    expect(notOnReceiptScreen.getByText('Scan another receipt')).toBeTruthy();
    expect(
      notOnReceiptScreen.getByText('Send customer to a register')
    ).toBeTruthy();
    expect(
      notOnReceiptScreen.getByText('Take back item and let customer exit')
    ).toBeTruthy();

    const radioSecond = notOnReceiptScreen.getByText('Scan another receipt');

    fireEvent.press(radioSecond);
  });
});
