import React, { FC, useState } from 'react';
import { Image, View, StyleSheet } from 'react-native';
import {
  RadioItemGroup,
  Display,
  Title2,
  Divider,
  Subheader2,
  Subheader
} from '@walmart/gtp-shared-components';
import BarcodeImage from '../../assets/images/Barcode-illustration.png';
import { WidePrimaryButton } from '../../components/wide-button/wide-button.component';

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  centerImage: {
    marginTop: 8,
    height: 102,
    width: 102,
    justifyContent: 'center'
  },
  heading: {
    marginTop: 0,
    marginBottom: 8
  },
  body: {
    marginTop: 8,
    textAlign: 'center'
  },
  radioButtons: {
    marginTop: 8,
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  item: {
    marginLeft: 32,
    marginTop: 8
  },
  doneButton: {
    marginTop: 8,
    marginHorizontal: 16,
    alignItems: 'stretch',
    height: 40
  },
  subheader: {
    paddingHorizontal: 16
  },
  divider: {
    paddingTop: 8,
    paddingBottom: 0
  },
  footer: {
    marginTop: 'auto',
    marginBottom: 16,
    height: 50
  }
});
interface Props {
  errorAmount: number;
  ofErrorCount: number;
  onContinue: (errorType: string) => void;
  title: string;
  upc: string;
}

const Items = [
  { label: 'Try scanning the item again', id: '1', errorType: 'rescan-item' },
  { label: 'Scan another receipt', id: '2', errorType: 'scan-another-receipt' },
  {
    label: 'Send customer to a register',
    id: '3',
    errorType: 'send-to-register'
  },
  {
    label: 'Take back item and let customer exit',
    id: '4',
    errorType: 'take-item-back'
  }
];

export const NotOnReceipt: FC<Props> = (props: Props): JSX.Element => {
  const [selectItem, setSelectItem] = useState('1');
  const onTypeSelect = (id: string): void => {
    setSelectItem(id);
  };
  return (
    <>
      <View style={styles.container}>
        <Image
          accessibilityIgnoresInvertColors={true}
          testID="barcode-image"
          style={styles.centerImage}
          source={BarcodeImage}
        />
        <Display style={styles.heading} testID="sorry-display">
          Sorry...
        </Display>
        <Title2 style={styles.body} testID="title-text">
          Unfortunately,{' '}
          {props.errorAmount === 1
            ? 'this item isn’t '
            : props.errorAmount + ' items aren’t '}
          on the receipt.
        </Title2>
      </View>

      <Divider style={styles.divider} color="#E3E4E5" />
      <View style={styles.item} testID="item-missing">
        <Subheader2>{props.title}</Subheader2>
        <Subheader>{props.upc}</Subheader>
      </View>
      <Divider style={styles.divider} color="#E3E4E5" />
      <View style={styles.radioButtons}>
        <Subheader style={styles.subheader}>
          Choose your next step{' '}
          {props.errorAmount > 1 &&
            'for item ' +
              props.ofErrorCount +
              ' (of ' +
              props.errorAmount +
              ')'}
        </Subheader>
        <RadioItemGroup
          items={Items}
          onSelect={onTypeSelect}
          selectedId={selectItem}
        />
      </View>
      <View style={styles.footer}>
        <WidePrimaryButton
          testID="continue-button"
          block={true}
          style={styles.doneButton}
          size="medium"
          onPress={() => {
            props.onContinue(Items[Number(selectItem) - 1].errorType);
          }}
        >
          Continue
        </WidePrimaryButton>
      </View>
    </>
  );
};
