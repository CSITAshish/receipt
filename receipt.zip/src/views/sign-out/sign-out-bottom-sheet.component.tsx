import React, { FC } from 'react';
import { StyleSheet, View } from 'react-native';
import {
  WidePrimaryButton,
  WideSecondaryButton
} from '../../components/wide-button/wide-button.component';
interface Props {
  onAction?: (action: 'sign-out' | 'cancel') => void;
}

const style = StyleSheet.create({
  signOutContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  signOutButtonContainer: {
    marginTop: 8,
    marginBottom: 16,
    display: 'flex',
    flexDirection: 'row',
    width: '100%'
  },
  signOutButton: {
    marginLeft: 16,
    marginRight: 16
  }
});

export const SignOutBottomSheet: FC<Props> = (props: Props): JSX.Element => {
  return (
    <View style={style.signOutContainer} testID="sign-out-bottom-sheet">
      <View style={style.signOutButtonContainer}>
        <WideSecondaryButton
          style={style.signOutButton}
          size="medium"
          block={true}
          testID="cancel-sign-out-button"
          onPress={() => props.onAction && props.onAction('cancel')}
        >
          Cancel
        </WideSecondaryButton>
        <WidePrimaryButton
          testID="sign-out-button"
          style={style.signOutButton}
          block={true}
          size="medium"
          onPress={() => props.onAction && props.onAction('sign-out')}
        >
          Sign out
        </WidePrimaryButton>
      </View>
    </View>
  );
};
