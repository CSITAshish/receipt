import React from 'react';
import 'react-native';

import { fireEvent, render } from '@testing-library/react-native';
import { SignOutBottomSheet } from './sign-out-bottom-sheet.component';

describe('Sign out bottom sheet', () => {
  it('should render', () => {
    expect(render(<SignOutBottomSheet />)).toBeTruthy();
  });

  it('should fire sign out when sign out button pressed', () => {
    const onAction = jest.fn();
    const signOut = render(<SignOutBottomSheet onAction={onAction} />);

    const signOutButton = signOut.getByTestId('sign-out-button');

    fireEvent.press(signOutButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('sign-out');
  });

  it('should fire cancel when cancel button pressed', () => {
    const onAction = jest.fn();
    const signOut = render(<SignOutBottomSheet onAction={onAction} />);

    const cancelSignOutButton = signOut.getByTestId('cancel-sign-out-button');

    fireEvent.press(cancelSignOutButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('cancel');
  });
});
