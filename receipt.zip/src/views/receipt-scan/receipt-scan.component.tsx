import {
  BottomSheet,
  LinkButton,
  Title,
  Body
} from '@walmart/gtp-shared-components';
import React, { FC, useContext, useEffect, useReducer } from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { ReceiptForm } from '../receipt-form/receipt-form.component';
import ReceiptScanImage from '../../assets/images/receipt-scan.png';
import { NavigationContext } from '@react-navigation/native';
import { Routes } from '../../routes';
import { useScanner } from '../../hooks/receipt-audit-scanner.hook';
import {
  AuditErrorStatus,
  AuditLookupResponse,
  AuditResponse,
  AUDIT_SERVICE
} from '../../services/audit';
import { useAsync } from '../../hooks';
import { useLoading } from '../loading-panel/loading-panel.component';
import { ReceiptAuditSnackbar } from '../../components/receipt-audit-snackbar/receipt-audit-snackbar.component';
import { ReceiptCheckFailure } from '../receipt-check-failure/receipt-check-failure.component';
import { TCNumber } from '@walmart/tcnumber';
import { TransactionItemData } from '../transaction-details/transaction-details.component';
import { useSSOLogin } from '../../hooks/sso.hook';
import { STORE_SERVICE } from '../../services/store/store.service';
import { ErrorProvider } from '../error-screen/error-screen.component';
import { useErrorState } from '../../hooks/error-state.hook';
import { LOGGER } from '../../app.logger';

interface State {
  receiptNumber?: TCNumber;
  auditStore: string;
  displayBottomSheet: boolean;
  action: ActionType;
  orderTime?: number;
  auditTime?: number;
  auditErrStatus: AuditErrorStatus;
  auditItems: TransactionItemData[];
  showSnackbar?: boolean;
  response: AuditResponse<AuditLookupResponse>;
}

type ActionType =
  | 'enter-receipt'
  | 'submit-receipt'
  | 'dismiss-bottom-sheet'
  | 'receipt-not-found'
  | 'barcode-scan'
  | 'receipt-req-fail'
  | 'idle'
  | 'reset'
  | 'toggle-snackbar'
  | 'customer-service-desk'
  | 'receipt-not-valid'
  | 'qr-not-supported';

interface Action {
  type: ActionType;
  value?: any;
}

export const styles = StyleSheet.create({
  contentContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    marginVertical: 24,
    marginHorizontal: 16
  },
  scanImageContaner: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginTop: 32
  },
  scanImage: {
    height: 272,
    width: 360
  },
  scanBarcodeText: {
    marginTop: 8
  },
  typeTC: {
    marginTop: 24,
    alignSelf: 'flex-start'
  }
});

const initialState = (): State => {
  return JSON.parse(
    JSON.stringify({
      displayBottomSheet: false,
      action: 'idle'
    })
  ) as State;
};

const reducer = (state: State, action: Action): State => {
  state.action = action.type;
  switch (action.type) {
    case 'qr-not-supported':
    case 'receipt-not-found':
    case 'customer-service-desk':
    case 'receipt-not-valid':
    case 'toggle-snackbar':
      state.showSnackbar = !state.showSnackbar;
      break;
    case 'enter-receipt':
      state.displayBottomSheet = true;
      break;
    case 'submit-receipt':
      state.receiptNumber = new TCNumber(action.value);
      state.displayBottomSheet = false;
      break;
    case 'dismiss-bottom-sheet':
      state.displayBottomSheet = false;
      break;
    case 'barcode-scan':
      state.receiptNumber = new TCNumber(action.value);
      state.action = 'submit-receipt';
      break;
    case 'receipt-req-fail':
      const response = action.value as AuditResponse<AuditLookupResponse>;
      const receipt = response.transStatusPayload.receiptData[0];
      state.auditTime = receipt.receiptPreviousAuditDateTimeUtc
        ? new Date(receipt.receiptPreviousAuditDateTimeUtc).getTime()
        : undefined;
      state.auditStore = receipt.storeId;
      state.auditErrStatus = response.transStatusPayload.errCode;
      state.orderTime = new Date(
        response.transStatusPayload.receiptData[0].orderDateTimeUtc
      ).getTime();
      state.auditItems = receipt.orderLineItems.map(i => {
        return {
          product: i.productName,
          quantity: i.measurementValue,
          price: i.unitPrice.currencyAmount,
          unitOfMeasure: i.unitOfMeasure
        } as TransactionItemData;
      });
      break;
    case 'reset':
      state = initialState();
      break;
  }
  return { ...state };
};

const snackbarMessage = (state: State): string | undefined => {
  switch (state.action) {
    case 'qr-not-supported':
      return 'QR codes are not supported at this time, please scan another barcode.';
    case 'receipt-not-found':
      return 'Receipt not found.';
    case 'customer-service-desk':
      return 'Receipt check complete.';
    case 'receipt-not-valid':
      return 'Please scan or manually enter a valid receipt barcode.';
    default:
      return undefined;
  }
};

export const ReceiptScan: FC = (): JSX.Element => {
  const errorState = useErrorState();
  const { signOut } = useSSOLogin();
  const [state, dispatch] = useReducer(reducer, initialState());
  const navigation = useContext(NavigationContext);
  const scanner = useScanner();

  useEffect(() => {
    if (
      scanner.barcodeType === 'receipt_barcode' &&
      scanner.value &&
      scanner.valid
    ) {
      dispatch({ type: 'barcode-scan', value: scanner.value });
    } else if (scanner.value && scanner.barcodeType === 'qr_code') {
      dispatch({ type: 'qr-not-supported' });
    } else if (
      scanner.value &&
      (!scanner.valid || scanner.barcodeType !== 'receipt_barcode')
    ) {
      dispatch({ type: 'receipt-not-valid' });
    }
  }, [scanner.value, scanner.valid, scanner.barcodeType, scanner.count]);

  const { loading, setLoading } = useLoading();

  const lookupReceipt = useAsync(async () => {
    if (state.receiptNumber && !errorState) {
      setLoading(true);
      /* istanbul ignore next */
      const response = await AUDIT_SERVICE.findReceipt({
        tcNumber: state.receiptNumber.encoded || '',
        storeId: STORE_SERVICE.value
      });
      state.response = response;
      if (response.status === 401 || response.status === 403) {
        signOut();
        return;
      }

      if (response.status === 400) {
        dispatch({ type: 'receipt-not-valid' });
        setLoading(false);
        return;
      }

      if (response.status === 404) {
        dispatch({ type: 'receipt-not-found' });
        setLoading(false);
        return;
      }

      /* istanbul ignore next */
      if (response.transStatus === 'Success') {
        navigation?.reset({
          index: 0,
          routes: [{ name: Routes.ItemScan, params: { response: response } }]
        });
      } else {
        dispatch({ type: 'receipt-req-fail', value: response });
      }
      setLoading(false);
    }
  });

  const auditStatus = useAsync(async () => {
    try {
      await AUDIT_SERVICE.receiptStatus({
        auditStatus: state.response.transStatus || 'Failure',
        auditFailureReason: state.response.transStatusPayload.errCode,
        auditDateTimeUtc:
          state.response.transStatusPayload.receiptData[0]
            .receiptPreviousAuditDateTimeUtc ||
          new Date(Date.now()).toISOString(),
        receiptData: state.response.transStatusPayload.receiptData,
        scannedItemStatus: [],
        storeId: STORE_SERVICE.value
      });
      navigation?.reset({
        index: 0,
        routes: [{ name: Routes.ReceiptScan }]
      });
    } catch (error) {
      LOGGER.error(error as any);
    }
  });

  useEffect(() => {
    if (state.action === 'submit-receipt' && !loading && !errorState) {
      setLoading(true);
      lookupReceipt.execute();
    }
  }, [state.action, lookupReceipt, setLoading, loading, errorState]);

  return (
    <ErrorProvider>
      {state.action === 'receipt-req-fail' && state.receiptNumber && (
        <ReceiptCheckFailure
          onAction={(
            action: 'done' | 'another-receipt' | 'review-manually'
          ) => {
            switch (action) {
              case 'another-receipt':
                dispatch({ type: 'idle' });
                break;
              case 'done':
                auditStatus.execute();
                dispatch({ type: 'customer-service-desk' });
                break;
              case 'review-manually':
                navigation?.navigate(Routes.TransactionDetails, {
                  items: state.auditItems,
                  receipt: state.receiptNumber?.encoded
                });
                break;
            }
          }}
          store={state.auditStore}
          storeMismatch={
            state.auditErrStatus === 'STORE_MISMATCH' ||
            STORE_SERVICE.value !== state.auditStore
          }
          orderTime={state.orderTime}
          alreadyScanned={state.auditTime}
          hasItems={!!state.auditItems && state.auditItems.length > 0}
        />
      )}
      {state.action !== 'receipt-req-fail' && (
        <>
          <View
            testID="receipt-check-content-container"
            style={styles.contentContainer}
          >
            <Title testID="scan-receipt">Scan a receipt barcode to start</Title>
            <Body
              weight="light"
              testID="scan-barcode"
              style={styles.scanBarcodeText}
            >
              Please scan the barcode on the customer’s receipt, eReceipt or
              Exit Pass to get started.
            </Body>
            {__DEV__ && (
              <LinkButton
                style={styles.typeTC}
                testID="mock-scan-button"
                onPress={() => {
                  scanner.mock({
                    type: 'LABEL-TYPE-CODE39',
                    value: '50155137352554717838'
                  });
                }}
              >
                Mock Scan
              </LinkButton>
            )}
            <LinkButton
              testID="type-tc-number"
              style={styles.typeTC}
              onPress={() => {
                dispatch({ type: 'enter-receipt' });
              }}
            >
              Type receipt number instead
            </LinkButton>
          </View>

          <View style={styles.scanImageContaner}>
            <Image
              accessibilityIgnoresInvertColors={true}
              testID="receipt-scan-image"
              style={styles.scanImage}
              source={ReceiptScanImage}
            />
          </View>

          <BottomSheet
            visible={state.displayBottomSheet}
            title={'Enter TC#'}
            resizable={false}
            avoidKeyboard={false}
            onDismiss={() => {
              dispatch({ type: 'dismiss-bottom-sheet' });
            }}
          >
            <ReceiptForm
              onReceipt={val => {
                dispatch({ type: 'submit-receipt', value: val });
              }}
            />
          </BottomSheet>
          {state.showSnackbar && !!snackbarMessage(state) && (
            <ReceiptAuditSnackbar
              onDismiss={() => {
                if (state.action === 'customer-service-desk') {
                  dispatch({ type: 'reset' });
                } else {
                  dispatch({ type: 'toggle-snackbar' });
                }
              }}
            >
              {snackbarMessage(state) || ''}
            </ReceiptAuditSnackbar>
          )}
        </>
      )}
    </ErrorProvider>
  );
};
