import { Text } from 'react-native';
import React from 'react';

import { ReceiptScan } from './receipt-scan.component';

import {
  render,
  fireEvent,
  waitFor,
  waitForElementToBeRemoved,
  RenderAPI
} from '@testing-library/react-native';
import { receiptAuditLookupApiHandler } from '../../services/audit/mocks';
import { server } from '../../../mocks/http.mock';
import {
  createDrawerNavigator,
  DrawerNavigationProp
} from '@react-navigation/drawer';
import { NavigationContainer, ParamListBase } from '@react-navigation/native';
import { Routes } from '../../routes';
import { LoadingPanel } from '../loading-panel/loading-panel.component';
import { TransactionDetails } from '../transaction-details/transaction-details.component';

const createNavStack = (
  navCallback: (nav: DrawerNavigationProp<ParamListBase, string>) => void
): RenderAPI => {
  const Drawer = createDrawerNavigator();
  return render(
    <NavigationContainer>
      <LoadingPanel>
        <Drawer.Navigator
          screenOptions={{
            header: navProps => {
              navCallback(navProps.navigation);
              return <Text>Mock</Text>;
            }
          }}
        >
          <Drawer.Screen
            name={Routes.ReceiptScan}
            component={ReceiptScan}
            options={{ title: 'Receipt Check' }}
          />
          <Drawer.Screen
            name={Routes.TransactionDetails}
            component={TransactionDetails}
          />
        </Drawer.Navigator>
      </LoadingPanel>
    </NavigationContainer>
  );
};

describe('Receipt Scan Screen', () => {
  it('should have correct text', async () => {
    const app = render(<ReceiptScan />);

    expect(app.queryByText(/Scan a receipt barcode to start/)).toBeTruthy();

    expect(
      app.queryByText(
        /Please scan the barcode on the customer’s receipt, eReceipt or Exit Pass to get started./
      )
    ).toBeTruthy();

    expect(app.queryByText(/Type receipt number instead/)).toBeTruthy();
  });

  it('should display tc-number bottom sheet', async () => {
    const app = render(<ReceiptScan />);
    const tcNumberButton = app.getByTestId('type-tc-number');

    fireEvent.press(tcNumberButton);

    await waitFor(() => expect(app.queryByText(/Enter TC#/)).toBeTruthy());

    expect(app.queryByText(/Enter TC#/)).toBeTruthy();

    const receiptNumberInput = app.getByTestId('barcode-number-input');

    fireEvent.changeText(receiptNumberInput, '8161370228668852923');

    fireEvent(receiptNumberInput, 'submitEditing');

    await waitForElementToBeRemoved(() => app.getByText(/Enter TC#/));

    expect(app.queryByText(/Enter TC#/)).toBeFalsy();
  });

  describe('when there are receipt check issues', () => {
    it.skip('should show transaction details', async () => {
      server.use(receiptAuditLookupApiHandler(false, true, 'STORE_MISMATCH'));

      let nav!: DrawerNavigationProp<ParamListBase, string>;
      const app = createNavStack(n => (nav = n));

      await waitFor(() => expect(nav).toBeTruthy());

      const tcNumberButton = app.getByTestId('type-tc-number');

      fireEvent.press(tcNumberButton);

      await waitFor(() => expect(app.queryByText(/Enter TC#/)).toBeTruthy());

      expect(app.queryByText(/Enter TC#/)).toBeTruthy();

      const receiptNumberInput = app.getByTestId('barcode-number-input');

      fireEvent.changeText(receiptNumberInput, '8161370228668852923');

      fireEvent(receiptNumberInput, 'submitEditing');

      await waitForElementToBeRemoved(() => app.getByText(/Enter TC#/));

      await waitFor(() => {
        app.debug();
        return expect(app.queryByText(/Wrong store/)).toBeTruthy();
      });

      fireEvent.press(app.getByTestId('review-receipt-button'));

      await waitFor(() => expect(app.queryByText(/TC#/)).toBeTruthy());
    });
  });
});
