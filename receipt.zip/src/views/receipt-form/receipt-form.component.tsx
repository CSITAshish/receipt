import { TCNumber } from '@walmart/tcnumber';
import React, { FC } from 'react';
import BarcodeImage from '../../assets/images/tc-number-barcode.png';
import { BarcodeSheetForm } from '../../components/barcode-sheet-form/barcode-sheet-form.component';

interface Props {
  onReceipt: (receiptId: string) => void;
}

const isValidReceipt = (input: string | undefined): string | undefined => {
  let tcNumber;
  try {
    tcNumber = new TCNumber(input || '');
  } catch (e) {
    // Handle error here
  }
  return !tcNumber ? 'Invalid TC number' : undefined;
};

export const ReceiptForm: FC<Props> = (props: Props): JSX.Element => {
  return (
    <BarcodeSheetForm
      image={BarcodeImage}
      onInputValidation={state => isValidReceipt(state.value)}
      onSubmit={state => props.onReceipt(state.value || '')}
    />
  );
};
