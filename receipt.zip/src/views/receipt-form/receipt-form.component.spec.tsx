import React from 'react';
import 'react-native';

import { fireEvent, render } from '@testing-library/react-native';
import { ReceiptForm } from './receipt-form.component';

describe('Receipt Form', () => {
  it('should only accept only numeric input', () => {
    const onReceipt = jest.fn();
    const app = render(<ReceiptForm onReceipt={onReceipt} />);

    const tcNumberInput = app.getByTestId('barcode-number-input');

    fireEvent.changeText(tcNumberInput, '123123absdfsd');

    fireEvent(tcNumberInput, 'submitEditing');

    expect(onReceipt).not.toHaveBeenCalled();

    fireEvent.changeText(tcNumberInput, '8161370228668852923');

    fireEvent(tcNumberInput, 'submitEditing');

    expect(onReceipt).toHaveBeenCalledTimes(1);
  });
});
