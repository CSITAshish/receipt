import { fireEvent, render, waitFor } from '@testing-library/react-native';
import React from 'react';
import 'react-native';
import { ReceiptCheckFailure } from './receipt-check-failure.component';

describe('Receipt Check Failure', () => {
  const onAction = jest.fn();

  afterEach(() => {
    onAction.mockReset();
  });

  it('should show correct store', () => {
    const app = render(<ReceiptCheckFailure onAction={onAction} store="123" />);

    expect(app.getByText(/Receipt not scanned./)).toBeTruthy();
    expect(app.getByText(/123/)).toBeTruthy();
  });

  it('should show wrong store', () => {
    const app = render(
      <ReceiptCheckFailure onAction={onAction} store="123" storeMismatch />
    );

    expect(app.getByText(/Receipt not scanned./)).toBeTruthy();
    expect(app.getByText(/Purchased store/)).toBeTruthy();
  });

  it('should show already audited', () => {
    const app = render(
      <ReceiptCheckFailure onAction={onAction} store="123" storeMismatch />
    );

    expect(app.getByText(/Receipt not scanned./)).toBeTruthy();
  });

  it('should show never been audited', () => {
    const date = Date.now();
    const app = render(
      <ReceiptCheckFailure
        onAction={onAction}
        store="123"
        alreadyScanned={date}
      />
    );

    expect(app.getByText(/Receipt already scanned at/)).toBeTruthy();
    expect(app.getByText(/123/)).toBeTruthy();
  });

  it('should fire im done action', async () => {
    const app = render(<ReceiptCheckFailure onAction={onAction} store="123" />);

    fireEvent.press(app.getByTestId('im-done-button'));

    await waitFor(() => expect(app.getByTestId('got-it-button')).toBeTruthy());

    fireEvent.press(app.getByTestId('got-it-button'));

    await waitFor(() => expect(onAction).toBeCalledTimes(1));

    expect(onAction).toBeCalledWith('done');
  });

  it('should fire another-receipt action', () => {
    const app = render(<ReceiptCheckFailure onAction={onAction} store="123" />);

    fireEvent.press(app.getByTestId('another-receipt-button'));

    expect(onAction).toBeCalledTimes(1);
    expect(onAction).toBeCalledWith('another-receipt');
  });
});
