import {
  Body,
  Body2,
  BottomSheet,
  CheckIcon,
  CloseIcon,
  Divider,
  Headline,
  LinkButton
} from '@walmart/gtp-shared-components';
import React, { useState } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import ReceiptCheckFailureImg from '../../assets/images/receipt-check-failure.png';
import {
  WidePrimaryButton,
  WideSecondaryButton
} from '../../components/wide-button/wide-button.component';
import DayJs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ErrorPathBottomSheet } from '../error-path-bottom-sheet/error-path-bottom-sheet.component';
import Localize from 'react-native-localize';
import { LOGGER } from '../../app.logger';

interface Props {
  orderTime?: number;
  alreadyScanned?: number;
  storeMismatch?: boolean;
  hasItems?: boolean;
  store: string;
  onAction: (action: 'done' | 'another-receipt' | 'review-manually') => void;
}

interface AuditStatusProps {
  primaryText: string;
  value: string;
  status: 'success' | 'failure';
}

const styles = StyleSheet.create({
  scanFailureImg: {
    width: 132,
    height: 148,
    margin: 16
  },
  receiptCheckFailureContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  receiptCheckHeadline: {
    textAlign: 'center'
  },
  auditStatusSection: {
    justifyContent: 'space-around',
    flexDirection: 'column',
    alignSelf: 'stretch',
    marginLeft: 16
  },
  auditStatusContainer: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    alignContent: 'flex-start'
  },
  occupySpace: {
    flex: 1
  },
  footer: {
    justifyContent: 'center',
    flexDirection: 'column',
    height: 100,
    marginHorizontal: 8
  },
  button: {
    margin: 0,
    alignItems: 'stretch',
    display: 'flex',
    flexDirection: 'column'
  }
});

const AuditStatus = (props: AuditStatusProps): JSX.Element => {
  return (
    <View style={styles.auditStatusContainer}>
      {props.status === 'success' && <CheckIcon color="green" size={24} />}
      {props.status === 'failure' && <CloseIcon color="red" size={24} />}
      <Body2>{props.primaryText}</Body2>
      <Body>{props.value ? ' ' + props.value : props.value}</Body>
    </View>
  );
};

const convertToTimezone = (date: string | number): string => {
  DayJs.extend(utc);
  DayJs.extend(timezone);

  const utcTime = DayJs.utc(date).format('h:mmA on MM/DD/YYYY');
  const currentTimezone = Localize.getTimeZone();

  const result = DayJs(date).tz(currentTimezone).format('h:mmA on MM/DD/YYYY');

  LOGGER.info({
    utcTime: utcTime,
    localTime: result,
    timeZone: currentTimezone
  });

  return result;
};

export const ReceiptCheckFailure = (props: Props): JSX.Element => {
  const [bottomSheet, setBottomSheet] = useState(false);
  return (
    <>
      <View style={{ ...styles.occupySpace, ...styles.occupySpace }}>
        <View
          style={{
            ...styles.receiptCheckFailureContainer,
            ...styles.occupySpace
          }}
        >
          <Image
            style={styles.scanFailureImg}
            source={ReceiptCheckFailureImg}
            accessibilityIgnoresInvertColors
          />
          <Headline style={styles.receiptCheckHeadline}>
            Unfortunately, this receipt couldn't be verified.
          </Headline>
          <View style={{ ...styles.auditStatusSection, ...styles.occupySpace }}>
            <AuditStatus
              status={!props.alreadyScanned ? 'success' : 'failure'}
              value={
                !props.alreadyScanned
                  ? ''
                  : convertToTimezone(props.alreadyScanned)
              }
              primaryText={
                !props.alreadyScanned
                  ? 'Receipt not scanned.'
                  : 'Receipt already scanned at'
              }
            />
            <AuditStatus
              status={props.storeMismatch ? 'failure' : 'success'}
              value={props.store}
              primaryText="Purchased store"
            />
            <AuditStatus
              status={
                DayJs(Date.now()).isAfter(
                  DayJs(props.orderTime).add(4, 'hours')
                )
                  ? 'failure'
                  : 'success'
              }
              value={!props.orderTime ? '' : convertToTimezone(props.orderTime)}
              primaryText="Purchased date and time at"
            />
          </View>
          {props.hasItems && (
            <LinkButton
              testID="review-receipt-button"
              onPress={() => props.onAction('review-manually')}
            >
              Review receipt manually
            </LinkButton>
          )}
        </View>
        <Divider />
        <View style={styles.footer}>
          <WidePrimaryButton
            testID="another-receipt-button"
            style={styles.button}
            onPress={() => props.onAction('another-receipt')}
            size="medium"
          >
            Scan another receipt
          </WidePrimaryButton>
          <WideSecondaryButton
            testID="im-done-button"
            style={styles.button}
            onPress={() => setBottomSheet(true)}
            size="medium"
          >
            I'm done
          </WideSecondaryButton>
        </View>
      </View>
      <BottomSheet
        visible={bottomSheet}
        resizable={false}
        avoidKeyboard={false}
        dismissable={false}
      >
        <ErrorPathBottomSheet
          canGoBack
          typeOfError="send-to-service-desk"
          onAction={(
            action: 'got-it' | 'go-back' | 'enter-upc' | 'enter-receipt'
          ) => {
            switch (action) {
              case 'got-it':
                props.onAction('done');
                break;
              case 'go-back':
                setBottomSheet(false);
                break;
            }
          }}
        />
      </BottomSheet>
    </>
  );
};
