import { NavigationContext, useRoute } from '@react-navigation/native';
import {
  Body,
  Body2,
  Divider,
  Headline,
  LinkButton,
  SolidCard
} from '@walmart/gtp-shared-components';
import React, { useContext } from 'react';
import { StyleSheet, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import {
  WidePrimaryButton,
  WideSecondaryButton
} from '../../components/wide-button/wide-button.component';

export type TransactionItemData = Omit<TransactionProps, 'divider'>;

type ActionButton = {
  text: string;
  type: 'link' | 'secondary' | 'primary';
  route: string;
};

interface Props {
  primaryButton: Omit<ActionButton, 'type'>;
  secondaryButton: ActionButton;
  receipt: string;
  items: TransactionItemData[];
}

interface TransactionProps {
  product: string;
  divider?: boolean;
  quantity: number;
  price: number;
  unitOfMeasure?: 'POUND' | 'EACH';
}

const style = StyleSheet.create({
  transactionDetailsContainer: {
    margin: 8,
    height: '100%',
    padding: 8
  },
  transactionItemContainer: {
    flexDirection: 'column'
  },
  transactionItemPriceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  transactionCard: {
    marginVertical: 8
  },
  noBarcodeButtonContainer: {
    justifyContent: 'flex-end',
    marginVertical: 16,
    height: 75
  }
});

export const TransactionItem = (props: TransactionProps): JSX.Element => {
  return (
    <View style={style.transactionItemContainer}>
      <View style={style.transactionItemPriceContainer}>
        <Body weight="regular">{props.product}</Body>
        <Body2>
          $
          {(props.quantity > 1
            ? props.price * props.quantity
            : props.price
          ).toPrecision(3)}
        </Body2>
      </View>
      {props.quantity > 1 && (
        <Body weight="light">
          Qty {props.quantity} @ ${props.price}/
          {props.unitOfMeasure?.toLowerCase() || 'each'}
        </Body>
      )}
      {props.divider && <Divider />}
    </View>
  );
};

export const TransactionDetails = (props: Props): JSX.Element => {
  const route = useRoute();
  const navigation = useContext(NavigationContext);
  const params = (route.params || {}) as Record<string, any>;

  const items = props.items || ((params.items || []) as TransactionItemData[]);
  const receipt = props.receipt || params.receipt;
  const primaryButton = props.primaryButton || params.primaryButton;
  const secondaryButton = props.secondaryButton || params.secondaryButton;

  navigation?.setOptions({ title: `TC# ${receipt}` });

  const navigateTo = (button: Omit<ActionButton, 'type'>): void => {
    navigation?.navigate(button.route, { action: button.text });
  };

  return (
    <View style={style.transactionDetailsContainer}>
      <Headline>Transaction details</Headline>
      <SolidCard color="white" elevation={2} style={style.transactionCard}>
        <ScrollView>
          {items.map((item, idx) => (
            <TransactionItem
              quantity={item.quantity}
              price={item.price}
              product={item.product}
              unitOfMeasure={item.unitOfMeasure}
              divider={idx + 1 !== items.length}
            />
          ))}
        </ScrollView>
      </SolidCard>
      {secondaryButton && primaryButton && (
        <View style={style.noBarcodeButtonContainer}>
          <WidePrimaryButton
            testID="trans-details-primary-button"
            onPress={() => {
              navigateTo(primaryButton);
            }}
            block
            size="medium"
          >
            {primaryButton.text}
          </WidePrimaryButton>
          {secondaryButton.type === 'link' && (
            <LinkButton
              testID="trans-details-link-button"
              onPress={() => {
                navigateTo(secondaryButton);
              }}
              block
            >
              {secondaryButton.text}
            </LinkButton>
          )}
          {secondaryButton.type === 'secondary' && (
            <WideSecondaryButton
              block
              testID="trans-details-secondary-button"
              size="medium"
              onPress={() => {
                navigateTo(secondaryButton);
              }}
            >
              {secondaryButton.text}
            </WideSecondaryButton>
          )}
        </View>
      )}
    </View>
  );
};
