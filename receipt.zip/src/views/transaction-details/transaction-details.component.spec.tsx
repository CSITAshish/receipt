import {
  createDrawerNavigator,
  DrawerNavigationProp
} from '@react-navigation/drawer';
import { NavigationContainer, ParamListBase } from '@react-navigation/native';
import {
  fireEvent,
  render,
  RenderAPI,
  waitFor
} from '@testing-library/react-native';
import React from 'react';
import { Text } from 'react-native';
import { Routes } from '../../routes';
import { TransactionDetails } from './transaction-details.component';

const createNavStack = (
  navCallback: (nav: DrawerNavigationProp<ParamListBase, string>) => void,
  secondaryButtonType: 'link' | 'secondary' = 'link'
): RenderAPI => {
  const Drawer = createDrawerNavigator();
  return render(
    <NavigationContainer>
      <Drawer.Navigator
        screenOptions={{
          header: navProps => {
            navCallback(navProps.navigation);
            return <Text>Mock</Text>;
          }
        }}
      >
        <Drawer.Screen
          name={Routes.TransactionDetails}
          component={() => (
            <TransactionDetails
              items={[{ quantity: 1, product: '123', price: 123 }]}
              receipt={'123'}
              primaryButton={{
                text: 'EGG',
                route: 'TEST'
              }}
              secondaryButton={{
                text: 'EGG 2',
                route: 'TEST',
                type: secondaryButtonType
              }}
            />
          )}
          options={{ title: 'Receipt Check' }}
        />
        <Drawer.Screen name="TEST" component={() => <Text>123</Text>} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};

describe('Transaction Details', () => {
  it('should fire primary button action & route', async () => {
    let nav!: DrawerNavigationProp<ParamListBase, string>;
    const app = createNavStack(n => (nav = n));
    await waitFor(() => expect(nav).toBeTruthy());

    const navMock = jest.spyOn(nav, 'navigate');
    fireEvent.press(app.getByTestId('trans-details-primary-button'));

    await waitFor(() => expect(navMock).toHaveBeenCalledTimes(1));
  });

  it('should fire link button action & navigate', async () => {
    let nav!: DrawerNavigationProp<ParamListBase, string>;
    const app = createNavStack(n => (nav = n));
    await waitFor(() => expect(nav).toBeTruthy());

    const navMock = jest.spyOn(nav, 'navigate');
    fireEvent.press(app.getByTestId('trans-details-link-button'));

    await waitFor(() => expect(navMock).toHaveBeenCalledTimes(1));
  });

  it('should fire secondary button action & navigate', async () => {
    let nav!: DrawerNavigationProp<ParamListBase, string>;
    const app = createNavStack(n => (nav = n), 'secondary');
    await waitFor(() => expect(nav).toBeTruthy());

    const navMock = jest.spyOn(nav, 'navigate');
    fireEvent.press(app.getByTestId('trans-details-secondary-button'));

    await waitFor(() => expect(navMock).toHaveBeenCalledTimes(1));
  });
});
