import React, {
  FC,
  createContext,
  useContext,
  useState,
  Dispatch,
  SetStateAction
} from 'react';
import { View, StyleSheet } from 'react-native';
import { Spinner } from '@walmart/gtp-shared-components';

const styles = StyleSheet.create({
  modalBackground: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0, 0.4)'
  }
});

interface LoadingState {
  loading: boolean;
  setLoading: Dispatch<SetStateAction<boolean>>;
}

const LoadingContext = createContext<LoadingState>({
  loading: true,
  setLoading: () => {
    return true;
  }
});

export const LoadingPanel: FC = ({ children }): JSX.Element => {
  const [loading, setLoading] = useState(false);
  const value = { loading, setLoading };
  return (
    <LoadingContext.Provider value={value}>
      {children}
      {loading && (
        <View style={styles.modalBackground}>
          <Spinner />
        </View>
      )}
    </LoadingContext.Provider>
  );
};

export function useLoading(): LoadingState {
  return useContext(LoadingContext);
}
