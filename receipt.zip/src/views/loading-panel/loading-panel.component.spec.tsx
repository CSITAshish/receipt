import 'react-native';
import React from 'react';
import { useLoading, LoadingPanel } from './loading-panel.component';
import { renderHook, act } from '@testing-library/react-hooks';
import { render } from '@testing-library/react-native';

describe('Loading Screen', () => {
  it('should render correctly', () => {
    const { result } = renderHook(() => useLoading(), {
      initialProps: { loading: true }
    });
    act(() => {
      result.current.setLoading(true);
    });
    expect(render(<LoadingPanel />)).toBeTruthy();
  });
});
