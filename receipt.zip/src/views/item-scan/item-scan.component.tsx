import React, {
  FC,
  useCallback,
  useContext,
  useEffect,
  useReducer
} from 'react';
import { View, StyleSheet, Image } from 'react-native';
import ItemScanImage from '../../assets/images/item-scan-barcode.png';

import {
  LinkButton,
  Body,
  Title,
  BottomSheet,
  MessageError
} from '@walmart/gtp-shared-components';
import { UpcForm } from '../upc-form/upc-form.component';
import { ReceiptAuditSnackbar } from '../../components/receipt-audit-snackbar/receipt-audit-snackbar.component';
import { ItemScanBottomSheet } from '../item-scan-bottom-sheet/item-scan-bottom-sheet.component';
import { ScanItem } from '../../models/scan.item';
import { Item, ITEM_SERVICE } from '../../services/item';
import { useAsync } from '../../hooks';
import {
  AuditResponse,
  AuditValidationResponse,
  AUDIT_SERVICE,
  TransactionStatus,
  AuditReceiptData,
  AuditMetricsItem,
  AuditLookupResponse,
  AuditErrorStatus
} from '../../services/audit';
import { GoodToGoBottomSheet } from '../good-to-go/good-to-go-bottom-sheet.component';
import {
  NavigationContext,
  useFocusEffect,
  useRoute
} from '@react-navigation/native';
import { Routes } from '../../routes';
import { useLoading } from '../loading-panel/loading-panel.component';
import { TCNumber } from '@walmart/tcnumber';
import { AddReceiptBottomSheet } from '../../views/add-receipt/add-receipt-bottom-sheet.component';
import { useScanner } from '../../hooks/receipt-audit-scanner.hook';
import { NotOnReceipt } from '../not-on-receipt/not-on-receipt.component';
import { ErrorPathBottomSheet } from '../error-path-bottom-sheet/error-path-bottom-sheet.component';
import { ErrorType } from '../../utils/error-type';
import { ReceiptForm } from '../receipt-form/receipt-form.component';
import { LOGGER } from '../../app.logger';
import { STORE_SERVICE } from '../../services/store/store.service';
import { useSSOLogin } from '../../hooks/sso.hook';
import { ErrorProvider } from '../error-screen/error-screen.component';
import { useErrorState } from '../../hooks/error-state.hook';
import UPC from 'cpc-input';

type ActionType =
  | 'enter-upc'
  | 'barcode-scan'
  | 'item-skip'
  | 'item-details'
  | 'submit-upc'
  | 'dismiss-bottom-sheet'
  | 'audit-validation'
  | 'audit-success'
  | 'audit-details'
  | 'add-receipt'
  | 'item-scan'
  | 'receipt-scan'
  | 'error-type'
  | 'enter-receipt'
  | 'submit-receipt'
  | 'enter-type'
  | 'fix-errors'
  | 'return-to-register'
  | 'receipt-req-fail'
  | 'receipt-not-found'
  | 'receipt-not-valid'
  | 'produce-not-supported'
  | 'qr-not-supported'
  | 'toggle-snackbar'
  | 'set-alert-message'
  | 'receipt-lookup-failure'
  | 'display-items-bottom-sheet'
  | 'siro-issue'
  | 'exit-flow';

interface State {
  action?: ActionType;
  upcInput?: string;
  scannedItems: ScanItem[];
  scanCount: number;
  auditStatus?: TransactionStatus;
  onReceipt: boolean;
  itemErrored: number;
  retryAudit: boolean;
  errorType?: string;
  receipts: AuditReceiptData[];
  receiptToAdd?: string;
  showSnackbar: boolean;
  errorCount: number;
  fixingErrorCount: number;
  alertMessage: string | undefined;
  failureReason?: AuditErrorStatus;
}

export const styles = StyleSheet.create({
  contentContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    marginVertical: 24,
    marginHorizontal: 16
  },
  itemScanImage: {
    width: 360,
    height: 198
  },
  scanBarcodeText: {
    marginTop: 8
  },
  typeUpc: {
    marginTop: 24,
    alignSelf: 'flex-start'
  },
  titleComponent: {
    alignSelf: 'flex-start'
  }
});
interface Action {
  type: ActionType;
  value?: any;
}

const scanItems = (): Array<ScanItem> => {
  const items = [];
  for (let i = 0; i < 3; i++) {
    items.push({
      title: 'Scan Barcode',
      upc: 'UPC #',
      scanned: false,
      state: 'pending',
      skipped: false,
      actionTaken: null
    } as ScanItem);
  }

  return items;
};

const initialState = (): State => {
  return {
    scanCount: 0,
    itemErrored: 0,
    fixingErrorCount: 0,
    errorCount: 0,
    onReceipt: true,
    retryAudit: false,
    scannedItems: scanItems(),
    receipts: []
  } as any;
};

const receiptAlreadyScanned = (
  receipts: AuditReceiptData[],
  receipt: string | undefined
): boolean => {
  let exists = false;

  receipts.forEach(r => {
    if (r.tcNumber === receipt) {
      exists = true;
    }
  });

  return exists;
};

const snackbarMessage = (state: State): string | undefined => {
  switch (state.action) {
    case 'receipt-not-found':
      return 'Receipt not found.';
    case 'siro-issue':
      return 'There was an issue finding the item.';
    case 'produce-not-supported':
      return 'Produce items are not supported, please scan another item.';
    case 'qr-not-supported':
      return 'QR codes are not supported at this time, please scan another barcode.';
    case 'receipt-not-valid':
      return 'Please scan or manually enter a valid receipt barcode.';
    case 'receipt-lookup-failure':
      return 'Receipt cannot be used for audit.';
    default:
      return undefined;
  }
};

const reducer = (state: State, action: Action): State => {
  state.action = action.type;
  LOGGER.info({ state });
  switch (action.type) {
    case 'add-receipt':
      state.alertMessage = '';
      state.receiptToAdd = action.value;
      break;
    case 'receipt-not-found':
      state.receiptToAdd = undefined;
      state.showSnackbar = true;
      break;
    case 'submit-receipt':
      state.alertMessage = undefined;
      const newReceiptResponse =
        action.value as AuditResponse<AuditLookupResponse>;
      const receipt = newReceiptResponse.transStatusPayload.receiptData[0];
      const tcNumber = new TCNumber(receipt.tcNumber);

      if (!receiptAlreadyScanned(state.receipts, state.receiptToAdd)) {
        state.receipts.push({
          tcNumber: tcNumber.encoded,
          receiptAuditStatus: receipt.receiptAuditStatus,
          receiptPreviouslyAudited: receipt.receiptPreviouslyAudited,
          receiptPreviousAuditDateTimeUtc:
            receipt.receiptPreviousAuditDateTimeUtc
        });
      }

      state.receiptToAdd = undefined;
      state.action = 'audit-validation';
      break;
    /* istanbul ignore next */
    case 'audit-details':
      /* istanbul ignore next */
      state.scanCount = 0;
      state.errorCount = 0;
      state.retryAudit = false;
      /* istanbul ignore next */
      const auditResult =
        action.value as AuditResponse<AuditValidationResponse>;
      /* istanbul ignore next */
      state.auditStatus = auditResult.transStatus;
      if (state.auditStatus === 'Failure') {
        state.failureReason = auditResult.transStatusPayload.errCode;
      }
      /* istanbul ignore next */
      const auditedItems = {} as Record<string, boolean>;
      auditResult.transStatusPayload.itemAuditResult.items.forEach(i => {
        auditedItems[i.itemUpc] = i.itemFoundInReceipt;
        state.scannedItems.forEach(item => {
          if (i.itemFoundInReceipt) {
            if (item.upc === i.itemUpc) {
              item.state = 'valid';
            }
          } else {
            if (item.upc === i.itemUpc) {
              item.state = 'error';
              state.errorCount++;
              state.onReceipt = false;
            }
          }
        });
      });
      break;
    case 'enter-upc':
      break;
    case 'error-type':
      state.errorType = action.value;
      break;
    case 'receipt-lookup-failure':
      state.showSnackbar = true;
      break;
    case 'fix-errors':
      let index = 0;
      let errorFound = false;
      state.scannedItems.forEach(i => {
        if (i.state === 'error' && !errorFound) {
          state.itemErrored = index;
          state.fixingErrorCount++;
          errorFound = true;
        } else if (index === 2 && !errorFound) {
          state.onReceipt = true;
          state.retryAudit = false;
          state.action = 'exit-flow';
        }
        index++;
      });
      break;
    case 'enter-type':
      state.action = action.value;
      if (action.value === 'got-it') {
        if (
          state.errorType === 'send-to-register' ||
          state.errorType === 'take-item-back'
        ) {
          state.scannedItems[state.itemErrored].actionTaken =
            state.errorType === 'take-item-back'
              ? 'RECOVERED_ITEM_AT_DOOR'
              : 'SENT_CUSTOMER_TO_CHECKOUT';
        }
        state.scannedItems[state.itemErrored].state = 'failed';
        state.scannedItems[state.itemErrored].skipped = true;
        state.onReceipt = false;
        state.retryAudit = false;
        state.action = 'return-to-register';
      } else {
      }
      break;
    case 'submit-upc':
      state.alertMessage = '';
      state.upcInput = new UPC(action.value.toString()).upcLookup;
      break;
    case 'item-details':
      const itemNumber =
        state.itemErrored !== undefined
          ? !state.onReceipt
            ? state.itemErrored
            : state.scanCount
          : state.scanCount;
      const siroItem = action.value as Item;
      const scannedItem = state.scannedItems[itemNumber];

      scannedItem.title = siroItem.description;
      scannedItem.skipped = false;
      scannedItem.upc = siroItem.upc || '';
      scannedItem.scanned = true;
      if (
        !state.onReceipt &&
        state.scannedItems[itemNumber].state === 'error'
      ) {
        state.retryAudit = true;
        state.scannedItems[itemNumber].state = 'pending';
      }
      state.scanCount++;
      break;
    case 'item-skip':
      const currentItem = state.scannedItems[action.value];
      currentItem.skipped = true;
      currentItem.scanned = false;
      state.scanCount++;
      state.action = 'item-details';
      break;
    case 'dismiss-bottom-sheet':
      /* istanbul ignore next */
      state.action = state.action === 'submit-upc' ? 'item-details' : undefined;
      /* istanbul ignore next */
      state.alertMessage = '';
      break;
    case 'display-items-bottom-sheet':
      break;
    case 'produce-not-supported':
    case 'qr-not-supported':
    case 'siro-issue':
    case 'toggle-snackbar':
      state.showSnackbar = !state.showSnackbar;
      break;
    case 'set-alert-message':
      state.alertMessage = 'Please scan a new item.';
      state.action = 'item-details';
      break;
  }

  if (state.scanCount === state.scannedItems.length || state.retryAudit) {
    state.scanCount = 0;
    state.retryAudit = false;
    state.action = 'audit-validation';
  }
  return { ...state };
};

export const ItemScan: FC = (): JSX.Element => {
  const errorState = useErrorState();
  const { loading, setLoading } = useLoading();
  const { signOut } = useSSOLogin();
  const scanner = useScanner();
  const navigation = useContext(NavigationContext);
  const route = useRoute();
  const params = (route.params || {}) as Record<string, any>;
  const auditResponse = params.response as AuditResponse<AuditLookupResponse>;
  const receipt = auditResponse.transStatusPayload.receiptData[0];
  const [state, dispatch] = useReducer(reducer, initialState());

  useEffect(() => {
    if (state.onReceipt && scanner.barcodeType === 'receipt_barcode') return;
    if (scanner.value && state.upcInput && scanner.value === state.upcInput)
      return;
    if (
      scanner.barcodeType === 'receipt_barcode' &&
      scanner.value &&
      scanner.valid
    ) {
      dispatch({
        type: 'add-receipt',
        value: new TCNumber(scanner.value).encoded
      });
    } else if (
      scanner.value &&
      scanner.valid &&
      scanner.barcodeType === 'item_barcode'
    ) {
      dispatch({ type: 'submit-upc', value: scanner.value });
    } else if (scanner.value && scanner.barcodeType === 'qr_code') {
      dispatch({ type: 'qr-not-supported' });
    } else if (
      scanner.value &&
      scanner.barcodeType === 'produce_not_supported'
    ) {
      dispatch({ type: 'produce-not-supported' });
    } else if (
      scanner.value &&
      (!scanner.valid || scanner.barcodeType !== 'receipt_barcode')
    ) {
      dispatch({ type: 'receipt-not-valid' });
    }
  }, [
    scanner.value,
    scanner.valid,
    scanner.barcodeType,
    scanner.count,
    state.onReceipt,
    state.upcInput
  ]);

  useEffect(() => {
    if (state.auditStatus === 'Success') {
      dispatch({ type: 'display-items-bottom-sheet' });
      setTimeout(() => {
        dispatch({ type: 'audit-success' });
      }, 2000);
    }
  }, [state.auditStatus]);
  if (!state.receipts.length) {
    state.receipts.push({
      tcNumber: receipt.tcNumber,
      receiptAuditStatus: receipt.receiptAuditStatus,
      receiptPreviouslyAudited: receipt.receiptPreviouslyAudited,
      receiptPreviousAuditDateTimeUtc: receipt.receiptPreviousAuditDateTimeUtc
    });
  }
  const getItemStatus = (): AuditMetricsItem[] => {
    const data: AuditMetricsItem[] = [];
    state.scannedItems.forEach(i => {
      if (i.skipped === false) {
        data.push({
          itemUpc: i.upc || '',
          itemFoundInReceipt: i.state === 'error' ? false : true,
          postAuditActionTaken: i.actionTaken
        });
      }
    });

    return data;
  };

  const audit = useAsync(async () => {
    setLoading(true);
    try {
      const res = await AUDIT_SERVICE.validateReceipt({
        tcNumbers: state.receipts.map(x => x.tcNumber),
        scannedItemUpcs: state.scannedItems
          .filter(x => !x.skipped)
          .map(x => x.upc || ''),
        storeId: STORE_SERVICE.value
      });
      setLoading(false);
      LOGGER.debug({ message: 'this is the response', res });
      dispatch({ type: 'audit-details', value: res });
    } catch (error) {
      setLoading(false);
      LOGGER.error(error as any);
    }
  });

  const auditStatus = useAsync(async () => {
    try {
      await AUDIT_SERVICE.receiptStatus({
        auditStatus: state.auditStatus || 'Failure',
        auditFailureReason: state.failureReason ? state.failureReason : null,
        auditDateTimeUtc: new Date(Date.now()).toISOString(),
        receiptData: state.receipts,
        scannedItemStatus: getItemStatus(),
        storeId: STORE_SERVICE.value
      });
      navigation?.reset({
        index: 0,
        routes: [{ name: Routes.ReceiptScan }]
      });
    } catch (error) {
      LOGGER.error(error as any);
    }
  });

  const lookupReceipt = useAsync(async () => {
    if (state.receiptToAdd) {
      setLoading(true);
      /* istanbul ignore next */
      const res = await AUDIT_SERVICE.findReceipt({
        tcNumber: state.receiptToAdd || '',
        storeId: STORE_SERVICE.value
      });
      setLoading(false);

      if (res.status === 401 || res.status === 403) {
        signOut();
        return;
      }

      if (res.status === 404) {
        dispatch({ type: 'receipt-not-found' });
        return;
      }
      if (res.transStatus === 'Failure') {
        dispatch({ type: 'receipt-lookup-failure' });
      } else if (res.transStatus === 'Success') {
        dispatch({ type: 'submit-receipt', value: res });
      }
    }
  });

  const item = useAsync(async () => {
    if (!errorState) {
      const result = await ITEM_SERVICE.getItem({
        store: STORE_SERVICE.value,
        upc: state.upcInput || ''
      });

      if (result.status > 299 || result.status < 200) {
        LOGGER.info(
          { msg: 'UPC not found in SIRO', upc: state.upcInput },
          'SIRO_ISSUE'
        );
        dispatch({ type: 'siro-issue' });
      } else {
        dispatch({ type: 'item-details', value: result });
      }
    }
  });

  useFocusEffect(
    useCallback(() => {
      switch (state.action) {
        case 'return-to-register':
          dispatch({ type: 'fix-errors' });
          break;
        case 'fix-errors':
          dispatch({ type: 'dismiss-bottom-sheet' });
          setLoading(false);
          break;
        case 'submit-upc':
          if (!loading && !errorState) {
            dispatch({ type: 'dismiss-bottom-sheet' });
            if (state.scannedItems.some(i => i.upc === state.upcInput)) {
              dispatch({ type: 'set-alert-message' });
              return;
            }
            setLoading(true);
            item.execute();
          }
          break;
        case 'siro-issue':
        case 'item-details':
          setLoading(false);
          break;
        case 'add-receipt':
          if (
            !errorState &&
            !receiptAlreadyScanned(state.receipts, state.receiptToAdd) &&
            lookupReceipt.status !== 'pending'
          ) {
            lookupReceipt.execute();
          }
          break;
        case 'audit-validation':
          if (!errorState) {
            /* istanbul ignore next */
            audit.execute();
            dispatch({ type: 'dismiss-bottom-sheet' });
          }
          break;
        /* istanbul ignore next */
        case 'audit-success':
          state.errorType = undefined;
          break;
        case 'exit-flow':
          dispatch({ type: 'display-items-bottom-sheet' });
          setTimeout(() => {
            dispatch({ type: 'audit-success' });
          }, 2000);
          break;
        /* istanbul ignore next */
        case 'audit-details':
          setLoading(false);
          if (state.onReceipt) {
            dispatch({ type: 'display-items-bottom-sheet' });
            setTimeout(() => {
              dispatch({ type: 'audit-success' });
            }, 2000);
          } else {
            dispatch({ type: 'fix-errors' });
          }
          break;
      }
    }, [
      setLoading,
      loading,
      audit,
      item,
      dispatch,
      lookupReceipt,
      errorState,
      state
    ])
  );

  const bottomSheetTitle = (): string => {
    if (
      state.action !== 'item-details' &&
      state.action !== 'enter-upc' &&
      state.action !== 'enter-receipt' &&
      state.action !== 'display-items-bottom-sheet'
    ) {
      return '';
    }

    switch (state.action) {
      case 'item-details':
        return `Items scanned (${state.scanCount} of 3)`;
      case 'display-items-bottom-sheet':
        return `Items scanned`;
      case 'enter-upc':
        return 'Enter UPC';
      case 'enter-receipt':
        return 'Enter TC#';
    }
  };

  return (
    <ErrorProvider>
      {state.onReceipt ? (
        <>
          <View
            testID="item-check-content-container"
            style={styles.contentContainer}
          >
            <Title testID="scan-item">Scan 3 items</Title>
            <Body
              weight="light"
              testID="scan-item-barcode"
              style={styles.scanBarcodeText}
            >
              Let the customer know you will be doing a quick check of their
              items.
            </Body>
            <View style={styles.typeUpc}>
              <LinkButton
                testID="type-upc-number"
                onPress={() => {
                  dispatch({ type: 'enter-upc' });
                }}
              >
                Type UPC instead
              </LinkButton>
            </View>
          </View>
          <Image
            accessibilityIgnoresInvertColors={true}
            style={styles.itemScanImage}
            testID="item-scan-image"
            source={ItemScanImage}
          />
        </>
      ) : (
        <NotOnReceipt
          errorAmount={state.errorCount}
          ofErrorCount={state.fixingErrorCount}
          upc={state.scannedItems[state.itemErrored].upc || ''}
          title={state.scannedItems[state.itemErrored].title || ''}
          onContinue={(input: string) => {
            dispatch({ type: 'error-type', value: input });
          }}
        />
      )}

      <BottomSheet
        visible={
          !!state.action &&
          state.action !== 'submit-upc' &&
          state.action !== 'dismiss-bottom-sheet' &&
          state.action !== 'produce-not-supported' &&
          state.action !== 'qr-not-supported' &&
          state.action !== 'receipt-not-valid' &&
          state.action !== 'audit-validation' &&
          state.action !== 'toggle-snackbar' &&
          state.action !== 'siro-issue' &&
          state.action !== 'receipt-scan' &&
          state.action !== 'set-alert-message' &&
          state.action !== 'fix-errors' &&
          state.action !== 'receipt-lookup-failure' &&
          state.action !== 'receipt-not-found' &&
          !loading
        }
        title={bottomSheetTitle()}
        dismissable={
          state.action !== 'audit-success' &&
          state.action !== 'audit-validation'
        }
        resizable={false}
        avoidKeyboard={true}
        onDismiss={() => {
          /* istanbul ignore next */
          if (state.action === 'audit-success') {
            auditStatus.execute();
          } else {
            dispatch({ type: 'dismiss-bottom-sheet' });
          }
        }}
      >
        {!!state.alertMessage && (
          <MessageError>{state.alertMessage}</MessageError>
        )}
        {state.action === 'audit-success' && (
          <GoodToGoBottomSheet
            onAction={type => {
              /* istanbul ignore next */
              if (type === 'done') {
                auditStatus.execute();
              }
            }}
          />
        )}
        {state.action === 'error-type' && (
          <ErrorPathBottomSheet
            upc={state.scannedItems[state.itemErrored].upc}
            title={state.scannedItems[state.itemErrored].title}
            onAction={(action: string) => {
              if (action === 'go-back') {
                dispatch({ type: 'dismiss-bottom-sheet' });
              }
              dispatch({ type: 'enter-type', value: action });
            }}
            typeOfError={state.errorType as ErrorType}
          />
        )}
        {state.action === 'enter-upc' && (
          <UpcForm
            onUpc={(input: string) => {
              dispatch({ type: 'submit-upc', value: input });
            }}
          />
        )}
        {state.action === 'enter-receipt' && (
          <ReceiptForm
            onReceipt={(input: string) => {
              scanner.mock({ value: input, type: 'LABEL-TYPE-CODE39' });
              //dispatch({ type: 'add-receipt', value: input });
            }}
          />
        )}
        {(state.action === 'item-details' ||
          state.action === 'audit-details' ||
          state.action === 'display-items-bottom-sheet') && (
          <ItemScanBottomSheet
            onSkip={(idx: number) =>
              dispatch({ type: 'item-skip', value: idx })
            }
            item={state.scannedItems}
            alert={!!state.alertMessage}
          />
        )}
        {/* istanbul ignore next */}
        {state.action === 'receipt-scan' && (
          /* istanbul ignore next */
          <AddReceiptBottomSheet
            onAction={(type: string) => {
              /* istanbul ignore next */
              switch (type) {
                case 'add-to-current-receipt':
                  dispatch({ type: 'dismiss-bottom-sheet' });
                  break;
                /* istanbul ignore next */
                case 'start-new-receipt':
                  dispatch({ type: 'dismiss-bottom-sheet' });
                  break;
              }
            }}
          />
        )}
      </BottomSheet>
      <ReceiptAuditSnackbar>Receipt scanned successfully.</ReceiptAuditSnackbar>
      {state.showSnackbar && !!snackbarMessage(state) && (
        <ReceiptAuditSnackbar
          onDismiss={() => {
            dispatch({ type: 'toggle-snackbar' });
          }}
        >
          {snackbarMessage(state) || ''}
        </ReceiptAuditSnackbar>
      )}
    </ErrorProvider>
  );
};
