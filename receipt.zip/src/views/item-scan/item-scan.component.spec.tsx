import React from 'react';
import { Text } from 'react-native';
import { ItemScan } from './item-scan.component';
import {
  fireEvent,
  render,
  RenderAPI,
  waitFor,
  waitForElementToBeRemoved
} from '@testing-library/react-native';
import { NavigationContainer, ParamListBase } from '@react-navigation/native';
import { Routes } from '../../routes';
import {
  createDrawerNavigator,
  DrawerNavigationProp
} from '@react-navigation/drawer';
import { LoadingPanel } from '../loading-panel/loading-panel.component';

const enterUpc = async (
  app: RenderAPI,
  upc = '2654',
  current = 1,
  total = 3
): Promise<void> => {
  const upcNumberButton = app.getByTestId('type-upc-number');

  fireEvent.press(upcNumberButton);

  await waitFor(() => expect(app.queryByText(/Enter UPC/)).toBeTruthy());

  const upcNumberInput = app.getByTestId('barcode-number-input');
  fireEvent.changeText(upcNumberInput, upc);

  fireEvent(upcNumberInput, 'submitEditing');

  await waitForElementToBeRemoved(() => app.queryByText(/Enter UPC/));

  const matchString = `Items scanned (${current} of ${total})`;
  if (current !== total) {
    await waitFor(() =>
      expect(app.queryByText(matchString, { exact: false })).toBeTruthy()
    );
  }
};

const skipUpc = async (app: RenderAPI, index: number): Promise<void> => {
  await waitFor(() =>
    expect(app.queryByTestId(`on-skip-${index}`)).toBeTruthy()
  );

  const skipButton = app.getByTestId(`on-skip-${index}`);

  fireEvent.press(skipButton);

  await waitFor(() => expect(app.queryAllByText(/Skipped/)).toBeTruthy());
};

describe.skip('Item Scan Screen', () => {
  let app!: RenderAPI;
  let nav: DrawerNavigationProp<ParamListBase, string> | undefined;

  beforeEach(() => {
    const Drawer = createDrawerNavigator();
    app = render(
      <NavigationContainer>
        <LoadingPanel>
          <Drawer.Navigator
            screenOptions={{
              header: navProps => {
                nav = navProps.navigation;
                return <Text>Mock</Text>;
              }
            }}
          >
            <Drawer.Screen
              name={Routes.ItemScan}
              component={ItemScan}
              options={{ title: 'Receipt Check' }}
            />
            <Drawer.Screen
              name={Routes.ReceiptScan}
              options={{ title: 'Mock' }}
              component={() => <Text>Mock</Text>}
            />
          </Drawer.Navigator>
        </LoadingPanel>
      </NavigationContainer>
    );
  });

  afterEach(() => {
    nav = undefined;
  });

  it('should display UI elements', async () => {
    await waitFor(() => expect(nav).toBeTruthy());
    expect(app.queryByText(/Scan 3 items/)).toBeTruthy();

    expect(
      app.queryByText(
        /Let the customer know you will be doing a quick check of their items./
      )
    ).toBeTruthy();

    expect(app.queryByText(/Type UPC instead/)).toBeTruthy();
  });

  it('should display & validate upc number bottom sheet', async () => {
    await waitFor(() => expect(nav).toBeTruthy());
    const upcNumberButton = app.getByTestId('type-upc-number');

    fireEvent.press(upcNumberButton);

    await waitFor(() =>
      expect(app.queryByTestId('barcode-number-input')).toBeTruthy()
    );

    expect(app.queryByText(/Enter UPC/)).toBeTruthy();

    const upcNumberInput = app.getByTestId('barcode-number-input');

    fireEvent.changeText(upcNumberInput, '081225903481');

    fireEvent(upcNumberInput, 'submitEditing');

    await waitFor(() => expect(app.queryByText(/Items scanned/)).toBeTruthy());
  });

  it('should allow skipping of scanned items', async () => {
    await waitFor(() => expect(nav).toBeTruthy());
    const upcNumberButton = app.getByTestId('type-upc-number');

    fireEvent.press(upcNumberButton);

    await waitFor(() => expect(app.queryByText(/Enter UPC/)).toBeTruthy());

    const upcNumberInput = app.getByTestId('barcode-number-input');

    fireEvent.changeText(upcNumberInput, '081225903481');

    fireEvent(upcNumberInput, 'submitEditing');

    await skipUpc(app, 1);
  });

  it.skip('should validate when all items have been scanned manually', async () => {
    await waitFor(() => expect(nav).toBeTruthy());

    await enterUpc(app, '081225903481', 1, 3);
    await enterUpc(app, '081225903481', 2, 3);
    await enterUpc(app, '081225903481', 3, 3);

    await waitFor(
      () => expect(app.queryByText(/Customer is good to go!/)).toBeTruthy(),
      { timeout: 4000 }
    );

    fireEvent.press(app.getByTestId('done-button'));

    await waitFor(() => expect(nav?.getState().key === Routes.ReceiptScan));
  });

  it.skip('should validate with less than 3 items in cart', async () => {
    await waitFor(() => expect(nav).toBeTruthy());

    await enterUpc(app, '081225903481', 1, 3);
    await skipUpc(app, 1);
    await skipUpc(app, 2);
    await waitFor(
      () => expect(app.queryByText(/Customer is good to go!/)).toBeTruthy(),
      { timeout: 3000 }
    );

    fireEvent.press(app.getByTestId('done-button'));
    await waitFor(() => expect(nav?.getState().key === Routes.ReceiptScan));
  });
});
