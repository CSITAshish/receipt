import {
  Subheader,
  Divider,
  LinkButton,
  Subheader2,
  Display2,
  ChevronLeftIcon
} from '@walmart/gtp-shared-components';
import { TransparentIconButton } from '@walmart/gtp-shared-components/dist/buttons';
import React, { FC } from 'react';
import { StyleSheet, View, Image } from 'react-native';
import ScanImage from '../../assets/images/receipt-scan.png';
import { WidePrimaryButton } from '../../components/wide-button/wide-button.component';
import { ErrorType } from '../../utils/error-type';

interface Props {
  onAction?: (
    action: 'got-it' | 'go-back' | 'enter-receipt' | 'enter-upc'
  ) => void;
  typeOfError: ErrorType;
  title?: string;
  upc?: string;
  canGoBack?: boolean;
}

const style = StyleSheet.create({
  errorContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    width: '100%'
  },
  item: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    alignSelf: 'stretch'
  },
  itemText: {
    marginTop: 16,
    marginLeft: 16,
    flexDirection: 'column'
  },
  gotItButton: {
    marginTop: 16,
    alignItems: 'stretch'
  },
  subHeading: {
    marginTop: 16,
    textAlign: 'left'
  },
  divider: {
    paddingTop: 16,
    paddingBottom: 0,
    paddingHorizontal: 0
  },
  typeUPC: {
    marginTop: 24,
    alignSelf: 'flex-start'
  },
  display: {
    marginTop: 16,
    marginBottom: 16,
    textAlign: 'center',
    width: '100%'
  },
  scanImageContaner: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginTop: 32
  },
  scanImage: {
    height: 272,
    width: 360
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    flex: 1,
    marginVertical: 4
  },
  bullet: {
    width: 16
  },
  bulletText: {
    flex: 1
  },
  backButtonContainer: {
    display: 'flex',
    flexDirection: 'row',
    alignSelf: 'flex-start'
  }
});

const bullet = (text: string): JSX.Element => {
  return (
    <View style={style.row}>
      <View style={style.bullet}>
        <Subheader>{'\u2022' + ' '}</Subheader>
      </View>
      <View style={style.bulletText}>
        <Subheader>{text}</Subheader>
      </View>
    </View>
  );
};

export const errorType = (type: ErrorType): any => {
  switch (type) {
    case 'send-to-service-desk':
      return (
        <>
          <Display2 style={style.display}>
            Please send the customer to the Customer Service Desk
          </Display2>
          {bullet('Explain that the receipt couldn’t be verified')}
          {bullet('Send them to a register to buy their items')}
          {bullet('Check their receipt again when they exit')}
        </>
      );
      break;
    case 'rescan-item':
      return (
        <>
          <Display2 style={style.display}>Re-scan the item</Display2>
          {bullet(
            'Tell them that you are going to try to scan that item again'
          )}
        </>
      );
    case 'scan-another-receipt':
      return (
        <>
          <Display2 style={style.display}>
            Scan the other receipt barcode
          </Display2>

          {bullet('Explain that the item wasn’t on the receipt')}
          {bullet('Ask if they have another receipt')}
          {bullet('Scan the other receipt')}
        </>
      );
    case 'send-to-register':
      return (
        <>
          <Display2 style={style.display}>Send customer to a register</Display2>
          {bullet('Explain that the item wasn’t on the receipt')}
          {bullet('Send them to a register to buy the item')}
          {bullet('Check their receipts again when they exit')}
        </>
      );
    case 'take-item-back':
      return (
        <>
          <Display2 style={style.display}>Take back the item</Display2>
          {bullet('Explain that the item wasn’t on the receipt')}
          {bullet(
            'Tell them if they don’t want to purchase the item, they can leave it with you and exit'
          )}
          {bullet(
            'Message the front end team lead or coach that an item needs to be retrieved'
          )}
        </>
      );
    case 'unknown':
      break;
  }
};

export const ErrorPathBottomSheet: FC<Props> = (props: Props): JSX.Element => {
  const itemInfo = (title?: string, upc?: string): JSX.Element => {
    return props.typeOfError !== 'scan-another-receipt' ? (
      <>
        <Divider style={style.divider} color="#E3E4E5" />
        <View style={style.errorContainer}>
          <View style={style.item}>
            <View style={style.itemText}>
              {!!title && <Subheader2>{props.title}</Subheader2>}
              {!!upc && <Subheader>{props.upc}</Subheader>}
            </View>
          </View>
        </View>
        <Divider style={style.divider} color="#E3E4E5" />
      </>
    ) : (
      <View style={style.scanImageContaner}>
        <Image
          accessibilityIgnoresInvertColors={true}
          testID="scan-image"
          style={style.scanImage}
          source={ScanImage}
        />
      </View>
    );
  };

  return (
    <>
      <View style={style.errorContainer} testID="error-path-bottom-sheet">
        {props.canGoBack && (
          <View style={style.backButtonContainer}>
            <TransparentIconButton
              icon={<ChevronLeftIcon size={24} />}
              onPress={() => props.onAction && props.onAction('go-back')}
            />
          </View>
        )}
        {errorType(props.typeOfError)}
        {props.typeOfError === 'rescan-item' && (
          <LinkButton
            testID="type-upc-number"
            style={style.typeUPC}
            onPress={() => props.onAction && props.onAction('enter-upc')}
          >
            Type UPC instead
          </LinkButton>
        )}
        {props.typeOfError === 'scan-another-receipt' && (
          <LinkButton
            testID="type-upc-number"
            style={style.typeUPC}
            onPress={() => props.onAction && props.onAction('enter-receipt')}
          >
            Type receipt number instead
          </LinkButton>
        )}
      </View>
      {itemInfo(props.title, props.upc)}
      <View style={style.errorContainer}>
        {props.typeOfError !== 'scan-another-receipt' &&
          props.typeOfError !== 'rescan-item' && (
            <WidePrimaryButton
              testID="got-it-button"
              block={true}
              style={style.gotItButton}
              size="medium"
              onPress={() => props.onAction && props.onAction('got-it')}
            >
              Got it
            </WidePrimaryButton>
          )}
      </View>
    </>
  );
};
