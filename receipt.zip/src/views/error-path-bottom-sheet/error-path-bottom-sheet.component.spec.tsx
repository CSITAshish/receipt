import React from 'react';
import 'react-native';

import { fireEvent, render } from '@testing-library/react-native';
import { ErrorPathBottomSheet } from './error-path-bottom-sheet.component';

describe('Sign out bottom sheet', () => {
  it('should render rescan-item', () => {
    const app = render(
      <ErrorPathBottomSheet
        typeOfError={'rescan-item'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );
    expect(app).toBeTruthy();
    expect(app.getByText('Re-scan the item')).toBeTruthy();
    expect(
      app.getByText(
        'Tell them that you are going to try to scan that item again'
      )
    ).toBeTruthy();
  });
  it('should render scan-another-receipt', () => {
    const app = render(
      <ErrorPathBottomSheet
        typeOfError={'scan-another-receipt'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );
    expect(app).toBeTruthy();
    expect(app.getByText('Scan the other receipt barcode')).toBeTruthy();
    expect(
      app.getByText('Explain that the item wasn’t on the receipt')
    ).toBeTruthy();
    expect(app.getByText('Ask if they have another receipt')).toBeTruthy();
    expect(app.getByText('Scan the other receipt')).toBeTruthy();
  });
  it('should render send-to-register', () => {
    const app = render(
      <ErrorPathBottomSheet
        typeOfError={'send-to-register'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );
    expect(app).toBeTruthy();
    expect(app.getByText('Send customer to a register')).toBeTruthy();
    expect(
      app.getByText('Explain that the item wasn’t on the receipt')
    ).toBeTruthy();
    expect(
      app.getByText('Send them to a register to buy the item')
    ).toBeTruthy();
    expect(
      app.getByText('Check their receipts again when they exit')
    ).toBeTruthy();
  });
  it('should render take-item-back', () => {
    const app = render(
      <ErrorPathBottomSheet
        typeOfError={'take-item-back'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );
    expect(app).toBeTruthy();
    expect(app.getByText('Take back the item')).toBeTruthy();
    expect(
      app.getByText('Explain that the item wasn’t on the receipt')
    ).toBeTruthy();
    expect(
      app.getByText(
        'Tell them if they don’t want to purchase the item, they can leave it with you and exit'
      )
    ).toBeTruthy();
    expect(
      app.getByText(
        'Message the front end team lead or coach that an item needs to be retrieved'
      )
    ).toBeTruthy();
  });
  it('should render nothing', () => {
    const app = render(
      <ErrorPathBottomSheet
        typeOfError={'unknown'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );
    expect(app).toBeTruthy();
  });
  it('should fire got it button when got it is pressed', () => {
    const onAction = jest.fn();
    const app = render(
      <ErrorPathBottomSheet
        onAction={onAction}
        typeOfError={'send-to-register'}
        itemName={'This Item is good'}
        upc={'123456789'}
      />
    );

    const gotItButton = app.getByTestId('got-it-button');

    fireEvent.press(gotItButton);

    expect(onAction).toHaveBeenCalledTimes(1);
    expect(onAction).toHaveBeenCalledWith('got-it');
  });
});
