import { Display, Subheader } from '@walmart/gtp-shared-components';
import React, { FC } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import DoubleCheckImage from '../../assets/images/receipt-illustration.png';
import { WidePrimaryButton } from '../../components/wide-button/wide-button.component';

interface Props {
  onDismiss: (val: boolean) => void;
}

const styles = StyleSheet.create({
  contentContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  doubleCheckImage: {
    marginTop: 8,
    marginBottom: 20,
    width: 128,
    height: 141,
    justifyContent: 'center'
  },
  checkText: {
    color: '#002D58',
    paddingTop: 16,
    paddingHorizontal: 16,
    textAlign: 'center'
  },
  continueButton: {
    marginTop: 16,
    alignItems: 'stretch'
  },
  display: {
    marginTop: 8,
    textAlign: 'center'
  }
});
export const DoubleCheckReceiptSheet: FC<Props> = (
  props: Props
): JSX.Element => {
  return (
    <View style={styles.contentContainer}>
      <Image
        accessibilityIgnoresInvertColors={true}
        testID="double-check-image"
        style={styles.doubleCheckImage}
        source={DoubleCheckImage}
      />
      <Display style={styles.display}>Double check the receipt</Display>
      <Subheader style={styles.checkText}>
        Check the receipt to make sure everything in the bag looks right.
      </Subheader>
      <WidePrimaryButton
        size="medium"
        block={true}
        testID="double-check-continue-button"
        style={styles.continueButton}
        onPress={() => props.onDismiss(false)}
      >
        Continue
      </WidePrimaryButton>
    </View>
  );
};
