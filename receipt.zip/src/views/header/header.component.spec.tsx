import 'react-native';
import React from 'react';

import { Header } from './header.component';

import { render, fireEvent } from '@testing-library/react-native';

let onMenuPress: jest.Mock<any, any>;

describe('Header', () => {
  beforeAll(() => {
    onMenuPress = jest.fn();
  });

  afterEach(() => {
    onMenuPress.mockReset();
  });

  it('should show left chevron when can go back', () => {
    const header = render(
      <Header
        title={'Test'}
        goBack={true}
        menuPress={onMenuPress}
        signedIn={true}
      />
    );

    expect(header.getByTestId('back-button-icon')).toBeTruthy();
  });

  it('should show drawer menu when cannot go back', () => {
    const header = render(
      <Header
        title={'Test'}
        goBack={false}
        menuPress={onMenuPress}
        signedIn={true}
      />
    );

    expect(header.getByTestId('drawer-menu-button')).toBeTruthy();
  });

  it('should call onMenuPress once', () => {
    const header = render(
      <Header title={'Test'} menuPress={onMenuPress} signedIn={true} />
    );

    fireEvent.press(header.getByTestId('drawer-menu-button'));

    expect(onMenuPress).toHaveBeenCalledTimes(1);
  });
});
