import {
  ChevronLeftIcon,
  IconButton,
  MenuIcon,
  Title
} from '@walmart/gtp-shared-components';
import colors from '@walmart/gtp-shared-components/dist/theme/colors.json';
import React, { FC } from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  title: string;
  goBack?: boolean;
  menuPress: () => void;
  signedIn: boolean;
}

export const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.blue[100],
    display: 'flex',
    flexDirection: 'row',
    height: 72,
    width: '100%'
  },
  headerButtonContainer: {
    justifyContent: 'center'
  },
  headerButton: {
    marginLeft: 8
  },
  headerTitleContainer: {
    justifyContent: 'center',
    flexDirection: 'column',
    marginLeft: 8
  },
  headerTitle: {
    justifyContent: 'center',
    flexDirection: 'column',
    marginLeft: 8,
    color: colors.white
  }
});

export const Header: FC<Props> = (
  props: Props = { title: 'default', menuPress: () => {}, signedIn: false }
): JSX.Element => {
  return (
    <View style={styles.header}>
      <View style={styles.headerButtonContainer}>
        <IconButton
          accessibilityLabel="drawer-menu"
          style={styles.headerButton}
          onPress={() => props.signedIn && props.menuPress()}
          testID={props.goBack ? 'back-button-icon' : 'drawer-menu-button'}
          icon={
            props.goBack ? (
              <ChevronLeftIcon size={24} />
            ) : (
              <MenuIcon size={24} />
            )
          }
        />
      </View>
      <View style={styles.headerTitleContainer}>
        <Title style={styles.headerTitle}>{props.title}</Title>
      </View>
    </View>
  );
};
