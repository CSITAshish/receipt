export const Routes = {
  ReceiptScan: 'Receipt Scan',
  ItemScan: 'Item Scan',
  SignIn: 'Sign in',
  NotOnReceipt: 'Not On Receipt',
  AuditFailure: 'Audit Failure',
  TransactionDetails: 'Transaction Details',
  ReceiptCheckFailure: 'ReceiptCheckFailure'
};
