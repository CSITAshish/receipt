import { ENVIRONMENT } from './services/environment';
import { STORE_SERVICE } from './services/store/store.service';
import { USER_SERVICE } from './services/user/user.service';
import { LogAppender } from './utils/logger/log.appender';
import { LogEvent } from './utils/logger/log.event';

export class AppAppender implements LogAppender {
  append(log: LogEvent): LogEvent {
    const data = {
      ...log,
      store: STORE_SERVICE.value,
      version: ENVIRONMENT.version,
      env: ENVIRONMENT.envName
    } as LogEvent;

    if (USER_SERVICE.user?.userId) {
      data.associateId = `${USER_SERVICE.user.userId.slice(0, -2)}**`;
    }

    return data;
  }
}
