import { AllsparkLogger } from './allspark.logger';
import { ENVIRONMENT } from './services/environment';
import { AppAppender, LogEvent, Logger } from './utils/logger';

export const LOGGER = Logger.create(opt => {
  const builder = opt
    .addAppender(new AppAppender())
    .useConsole()
    .logLevel(__DEV__ || !ENVIRONMENT.is('prod') ? 'DEBUG' : 'INFO')
    .addTransport({
      transport(event: LogEvent) {
        if (AllsparkLogger.current) {
          let fn: (msg: string, meta: any | unknown) => void;
          switch (event.level) {
            case 'DEBUG':
              fn = AllsparkLogger.current.debug;
              break;
            case 'ERROR':
              fn = AllsparkLogger.current.error;
              break;
            case 'INFO':
              fn = AllsparkLogger.current.info;
              break;
            case 'WARN':
              fn = AllsparkLogger.current.warn;
              break;
          }

          fn(event.msg, event);
        }
      }
    });
  // eslint-disable-next-line @typescript-eslint/dot-notation
  const splunkKey = process.env['RECEIPT_AUDIT_SPLUNK_TOKEN'] || '';

  if (!__DEV__ && splunkKey) {
    builder.useSplunk(
      'https://strati-logsearch01-hf.prod.walmart.com:8088/services/collector',
      'dxo-receiptaudit-appdev',
      splunkKey
    );
  }

  return builder;
});
