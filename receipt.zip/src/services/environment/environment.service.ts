import { EnvContext } from '@walmart/core-services/Environment';
import Config from 'react-native-config';
import DeviceInfo from 'react-native-device-info';
import { LOGGER } from '../../app.logger';

export enum EnvironmentType {
  dev,
  beta,
  teflon,
  prod
}

export type EnvironmentTypeStrings = keyof typeof EnvironmentType;

export class Environment {
  private _envName?: string;

  public get envName(): EnvironmentTypeStrings {
    return (this._envName ||
      (Config.FLAVOR === ''
        ? 'prod'
        : Config.FLAVOR)) as EnvironmentTypeStrings;
  }

  public useAllspark(context: EnvContext): Environment {
    this._envName = context.deployment;
    return this;
  }

  public is(...environments: EnvironmentTypeStrings[]): boolean {
    return environments.includes(this.envName);
  }

  public get privateKey(): string {
    // eslint-disable-next-line @typescript-eslint/dot-notation
    const nonProdPrivateKey = process.env['NONPROD_APP_PRIVATE_KEY'];

    // eslint-disable-next-line @typescript-eslint/dot-notation
    const prodPrivateKey = process.env['APP_PRIVATE_KEY'];

    const key = this.is('prod') ? prodPrivateKey : nonProdPrivateKey;

    if (!key) {
      LOGGER.error('Application private key not found!');
    }

    return key || '';
  }

  public get versionWithEnv(): string {
    return `${this.version} ${this.is('prod') ? '' : ' - ' + this.envName}`;
  }

  public get version(): string {
    return DeviceInfo.getVersion();
  }
}

export const ENVIRONMENT = new Environment();
