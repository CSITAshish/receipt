import { rest } from 'msw';

export const itemApiHandler = rest.get(
  'https://developer.api.stg.walmart.com/api-proxy/service/store-item/read-orchestration/v1/getStoreItem/receiptAudit',
  (req, res, ctx) => {
    return res(
      ctx.delay(500),
      ctx.status(200),
      ctx.json([
        {
          data: { getStoreItem: { gtin: 2654, basicInfo: { itemDesc: '420' } } }
        }
      ])
    );
  }
);
