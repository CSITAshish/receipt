import UPC from 'cpc-input';
import { LOGGER } from '../../app.logger';
import { ServiceRegistryApplication } from '../service-registry';

export type ItemType =
  | 'GTIN14'
  | 'GTIN_NO_CHECK_DIGIT'
  | 'CASEPACK'
  | 'UPCA'
  | 'UPCA_NO_CHECK_DIGIT'
  | 'UPCE'
  | 'UPCE_NO_CHECK_DIGIT'
  | 'WPLU'
  | 'WUPC'
  | 'CVP'
  | 'PRICE_EMBEDDED'
  | 'OTHER';

export interface ItemQuery {
  upc: string;
  store: string;
  country?: string;
  itemType?: ItemType;
}

export interface Item {
  upc?: string;
  description?: string;
}

export class ItemService extends ServiceRegistryApplication {
  constructor() {
    super('STORE-ITEM-READ');
  }

  private findItemType(input: string): ItemType {
    const upc = new UPC(input);

    if (!upc.parsed) {
      throw new Error('Upc input invalid');
    }

    const upcType = upc.upcType;
    LOGGER.debug(upcType);
    let itemType: ItemType = 'GTIN_NO_CHECK_DIGIT';

    switch (upcType) {
      case 'UPCA':
        itemType = 'UPCA';
        break;
      case 'GTIN14':
        itemType = 'GTIN14';
        break;
      case 'UPCE':
        itemType = 'UPCE';
        break;
      case 'PLU':
        itemType = 'WPLU';
        break;
      case 'UNKNOWN':
        LOGGER.error({ upc }, 'UKNOWN_UPC');
        itemType = 'OTHER';
        break;
    }

    LOGGER.debug(
      {
        msg: `Calling siro ${input} as item type ${itemType}`,
        upc: input,
        itemType
      },
      'SIRO_ITEM_TYPE'
    );

    return itemType;
  }

  public async getItem(query: ItemQuery): Promise<Item & { status: number }> {
    query.country = query.country || 'US';
    query.itemType = query.itemType || this.findItemType(query.upc);

    LOGGER.info(
      {
        siroQuery: query
      },
      super.appName,
      'SIRO_QUERY'
    );

    const response = await super.fetch(
      `${super.apiConfig.url}?q=${encodeURIComponent(
        JSON.stringify({
          g: query.upc,
          s: query.store,
          c: query.country,
          t: query.itemType
        })
      )}
    `,
      {
        retry: 3
      }
    );

    if (!response.ok) {
      return {
        status: response.status
      };
    }

    const payload = await response.json();

    LOGGER.info({ siroResponse: payload }, super.appName, 'SIRO_RESPONSE');

    if (payload[0].errors) {
      LOGGER.error(payload);
      return {
        status: 500
      };
    }

    const storeItem = payload[0]?.data?.getStoreItem;

    const result = {
      status: response.status,
      upc: storeItem.gtin,
      description: (storeItem?.basicInfo?.itemDesc || '').trim()
    };

    if (!result.description) {
      LOGGER.error(
        {
          msg: `Empty item description for ${storeItem.upc}`,
          upc: storeItem.upc,
          query
        },
        'EMPTY_ITEM_DESC'
      );
    }

    return result;
  }
}

export const ITEM_SERVICE = new ItemService();
