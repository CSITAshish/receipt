import AsyncStorage from '@react-native-community/async-storage';
import { waitFor } from '@testing-library/react-native';
import { STORE_NUMBER_KEY, StoreService } from './store.service';

describe('Store Service', () => {
  it('should only call async storage when value has changed', async () => {
    const storeService = new StoreService('5524');
    const setItemSpy = jest.spyOn(AsyncStorage, 'setItem');

    storeService.next('5524');
    storeService.next('1055');
    storeService.next('1055');

    await waitFor(() => expect(setItemSpy).toHaveBeenCalledTimes(1));
  });

  describe('with existing store number', () => {
    let storeService!: StoreService;
    beforeAll(async () => {
      await AsyncStorage.setItem(STORE_NUMBER_KEY, '1055');
      storeService = new StoreService('5524');
    });

    afterAll(async () => {
      await AsyncStorage.removeItem(STORE_NUMBER_KEY);
    });

    it('should load store from storage', async () => {
      await waitFor(() => expect(storeService.value).toBe('1055'));
    });
  });

  describe('without existing store number', () => {
    let storeService!: StoreService;

    beforeAll(() => {
      storeService = new StoreService('5524');
    });

    it('should return default store', () => {
      expect(storeService.value).toBe('5524');
    });
  });
});
