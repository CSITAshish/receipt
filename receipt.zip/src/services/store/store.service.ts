import AsyncStorage from '@react-native-community/async-storage';
import { BehaviorSubject } from 'rxjs';
import { LOGGER } from '../../app.logger';
import { ENVIRONMENT } from '../environment';

export const STORE_NUMBER_KEY = 'STORE_NUMBER';

export class StoreService extends BehaviorSubject<string> {
  constructor(store: string) {
    AsyncStorage.getItem(STORE_NUMBER_KEY)
      .then(storeVal => {
        if (storeVal) {
          LOGGER.info(
            `Update store number to ${storeVal} from storage.`,
            'ASYNC_STORAGE',
            'STORE_NUMBER'
          );
          this.next(storeVal);
        } else {
          LOGGER.info(
            `No store number was found in storage. Using default ${store}`,
            'ASYNC_STORAGE',
            'STORE_NUMBER'
          );
        }
      })
      .catch(e => {
        /* istanbul ignore next */
        LOGGER.error(e);
      });

    super(store);
  }

  public override next(value: string): void {
    if (value !== this.value) {
      LOGGER.info(
        `Store number changed from ${this.value} to ${value}. Attempting to update storage.`,
        'ASYNC_STORAGE',
        'STORE_NUMBER'
      );

      AsyncStorage.setItem(STORE_NUMBER_KEY, value)
        .then(() => {
          LOGGER.info(
            `Successfully updated store to ${value}`,
            'ASYNC_STORAGE',
            'STORE_NUMBER'
          );
        })
        .catch(e => {
          /* istanbul ignore next */
          LOGGER.error(e, 'ASYNC_STORAGE', 'STORE_NUMBER');
        });
    }
    super.next(value);
  }
}

export const STORE_SERVICE = new StoreService(
  /* istanbul ignore next */
  !__DEV__ && ENVIRONMENT.is('prod') ? '1055' : '5542'
);
