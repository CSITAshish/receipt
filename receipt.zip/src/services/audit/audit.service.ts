import { ServiceRegistryApplication } from '../service-registry';
import { USER_SERVICE } from '../user/user.service';

export type AuditErrorStatus =
  | 'SUCCESS'
  | 'RECEIPT_PREVIOUSLY_AUDITED'
  | 'PAST_AUDIT_TIME_FRAME'
  | 'STORE_MISMATCH'
  | 'SCANNED_ITEM_NOT_IN_RECEIPT';

export type TransactionStatus = 'Success' | 'Failure';

export interface AuditResponse<T extends AuditPayload> {
  transStatus: TransactionStatus;
  transStatusPayload: T;
  status: number;
}

export interface AuditItem {
  unitOfMeasure: 'EACH';
  measurementValue: number;
  upc: string;
  productName: string;
  unitPrice: {
    currencyAmount: number;
    currencyUnit: 'USD';
  };
}

export interface AuditReceipt {
  tcNumber: string;
  orderDateTimeUtc: number;
  storeId: string;
  receiptAuditStatus: AuditErrorStatus;
  receiptPreviouslyAudited: boolean;
  receiptPreviousAuditDateTimeUtc: string; //populated only only if the receipt was already audited.
  orderLineItems: AuditItem[];
}

export interface ItemAudit {
  itemUpc: string;
  itemFoundInReceipt: boolean;
}

export interface ItemAuditResult {
  auditDateTimeUtc: number;
  items: ItemAudit[];
}

export interface AuditValidationResponse extends AuditPayload {
  receiptData: Array<AuditReceipt>;
  itemAuditResult: ItemAuditResult;
  errCode: AuditErrorStatus;
}

export type AuditLookupResponse = Omit<
  AuditValidationResponse,
  'itemAuditResult'
>;

export interface AuditPayload {
  errCode: string;
  errDesc: string;
}

export interface AuditValidationRequest {
  tcNumbers: string[];
  scannedItemUpcs: string[];
  storeId: string;
  associateId?: string;
}

export interface AuditMetricsItem {
  itemUpc: string;
  itemFoundInReceipt: boolean;
  postAuditActionTaken:
    | 'SENT_CUSTOMER_TO_CHECKOUT'
    | 'RECOVERED_ITEM_AT_DOOR'
    | null;
}
export interface AuditReceiptData {
  tcNumber: string;
  receiptAuditStatus: AuditErrorStatus;
  receiptPreviouslyAudited: boolean;
  receiptPreviousAuditDateTimeUtc: string;
}

export interface AuditMetricsRequest {
  auditStatus: TransactionStatus;
  auditFailureReason: AuditErrorStatus | null;
  auditDateTimeUtc: string;
  receiptData: AuditReceiptData[];
  scannedItemStatus: AuditMetricsItem[];
  storeId: string;
}

export interface AuditLookupRequest {
  storeId: string;
  tcNumber: string;
}

export class AuditService extends ServiceRegistryApplication {
  constructor() {
    super('DXO-RECEIPT-AUDIT-SERVICE');
  }

  public async findReceipt(
    request: AuditLookupRequest
  ): Promise<AuditResponse<AuditLookupResponse>> {
    const token = await USER_SERVICE.token();
    const response = await super.fetch(
      `${super.apiConfig.url}/receipt/${request.tcNumber}?storeId=${
        request.storeId
      }`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        },
        retry: 3,
        timeout: 5000
      }
    );

    const json = await response.json();

    return {
      ...json,
      status: response.status
    } as AuditResponse<AuditLookupResponse>;
  }

  public async validateReceipt(
    request: AuditValidationRequest
  ): Promise<AuditResponse<AuditValidationResponse>> {
    const token = await USER_SERVICE.token();
    const response = await super.fetch(
      `${super.apiConfig.url}/receiptaudit/validate`,
      {
        method: 'POST',
        body: JSON.stringify(request),
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    const json = await response.json();

    return {
      ...json,
      status: response.status
    } as AuditResponse<AuditValidationResponse>;
  }

  public async receiptStatus(request: AuditMetricsRequest): Promise<number> {
    const token = await USER_SERVICE.token();
    const response = await super.fetch(
      `${super.apiConfig.url}/receiptaudit/status`,
      {
        method: 'POST',
        body: JSON.stringify(request),
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    return response.status;
  }
}

export const AUDIT_SERVICE = new AuditService();
