import { rest, RestHandler } from 'msw';
import {
  AuditErrorStatus,
  AuditLookupResponse,
  AuditResponse
} from '../audit.service';

export const receiptAuditMetricsApiHandler = rest.post(
  'https://dxo-ra-svc-01-stg.walmart.com/v1/receiptaudit/status',
  (req, res, ctx) => {
    return res(ctx.delay(500), ctx.status(200), ctx.json({}));
  }
);

export const receiptAuditValidateApiHandler = rest.post(
  'https://dxo-ra-svc-01-stg.walmart.com/v1/receiptaudit/validate',
  (req, res, ctx) => {
    return res(
      ctx.delay(500),
      ctx.status(200),
      ctx.json({
        transStatus: '<string>',
        transStatusPayload: {
          itemAuditResult: {
            auditDateTimeUtc: 1548257004000,
            items: [
              {
                itemUpc: '2654',
                itemFoundInReceipt: true
              },
              {
                itemUpc: '2654',
                itemFoundInReceipt: true
              }
            ]
          },
          receiptData: [
            {
              tcNumber: '<string>',
              orderDateTimeUtc: '<string>',
              receiptPreviouslyAudited: true,
              receiptPreviousAuditDateTimeUtc: '<string>', //populated only only if the receipt was already audited.
              orderLineItems: [
                {
                  unitOfMeasure: 'EACH',
                  measurementValue: 1,
                  upc: '2654',
                  productName: 'CORNCHEX',
                  unitPrice: {
                    currencyAmount: 3.0,
                    currencyUnit: 'USD'
                  }
                }
              ]
            }
          ],
          errCode: '<string>',
          errDesc: '<string>'
        }
      })
    );
  }
);

export const auditItemsPayload = (
  storeId: string,
  receipt: string[],
  items: string[],
  success = true,
  previouslyAudited = false,
  errorCause: AuditErrorStatus = 'SUCCESS',
  statusCode = 200
): AuditResponse<AuditLookupResponse> => {
  return {
    transStatus: success ? 'Success' : 'Failure',
    status: statusCode ? statusCode : success ? 200 : 400,
    transStatusPayload: {
      itemAuditResult: {
        auditDateTimeUtc: Date.now(),
        items: [
          {
            itemUpc: '4011',
            itemFoundInReceipt: true
          },
          {
            itemUpc: '1234',
            itemFoundInReceipt: true
          }
        ]
      },
      receiptData: [
        {
          tcNumber: receipt,
          storeId: storeId,
          orderDateTimeUtc: Date.now() - 150 * 1000,
          receiptPreviouslyAudited: previouslyAudited,
          receiptPreviousAuditDateTimeUtc: (Date.now() - 140 * 1000).toString(),
          orderLineItems: [
            {
              unitOfMeasure: 'EACH',
              measurementValue: 1,
              upc: '016000171084',
              productName: 'CORNCHEX',
              unitPrice: {
                currencyAmount: 3.0,
                currencyUnit: 'USD'
              }
            },
            {
              unitOfMeasure: 'POUND',
              measurementValue: 2.4,
              upc: '503018276038',
              productName: 'BANANAS',
              unitPrice: {
                currencyAmount: 0.52,
                currencyUnit: 'USD'
              }
            }
          ]
        }
      ],
      errCode: errorCause,
      errDesc: errorCause
    }
  } as unknown as AuditResponse<AuditLookupResponse>;
};

export const auditPayload = (
  storeId: string,
  receipt: string,
  success = true,
  previouslyAudited = false,
  errorCause: AuditErrorStatus = 'SUCCESS',
  statusCode = 200
): AuditResponse<AuditLookupResponse> => {
  return {
    transStatus: success ? 'Success' : 'Failure',
    status: statusCode ? statusCode : success ? 200 : 400,
    transStatusPayload: {
      receiptData: [
        {
          tcNumber: receipt,
          storeId,
          orderDateTimeUtc: Date.now() - 150 * 1000,
          receiptPreviouslyAudited: previouslyAudited,
          receiptPreviousAuditDateTimeUtc: (Date.now() - 140 * 1000).toString(),
          orderLineItems: [
            {
              unitOfMeasure: 'EACH',
              measurementValue: 1,
              upc: '016000171084',
              productName: 'CORNCHEX',
              unitPrice: {
                currencyAmount: 3.0,
                currencyUnit: 'USD'
              }
            },
            {
              unitOfMeasure: 'POUND',
              measurementValue: 2.4,
              upc: '503018276038',
              productName: 'BANANAS',
              unitPrice: {
                currencyAmount: 0.52,
                currencyUnit: 'USD'
              }
            }
          ]
        }
      ],
      errCode: errorCause,
      errDesc: errorCause
    }
  } as AuditResponse<AuditLookupResponse>;
};

export const receiptAuditLookupApiHandler = (
  success = true,
  previouslyAudited = false,
  errorCause: AuditErrorStatus = 'SUCCESS',
  url = 'https://dxo-ra-svc-01-stg.walmart.com/v1/receipt/',
  statusCode = 200
): RestHandler => {
  return rest.get(`${url}:receipt`, (req, res, ctx) => {
    const storeId = req.params.storeId;
    const receipt = req.params.receipt;

    return res(
      ctx.delay(500),
      ctx.status(statusCode),
      ctx.json(
        auditPayload(
          storeId as string,
          receipt as string,
          success,
          previouslyAudited,
          errorCause,
          statusCode
        )
      )
    );
  });
};
