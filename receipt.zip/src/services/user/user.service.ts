import WMSingleSignOn, { SSOUser } from 'react-native-ssmp-sso-allspark';
import DayJs from 'dayjs';
import { LOGGER } from '../../app.logger';
import jwtDecode, { JwtPayload } from 'jwt-decode';

export class UserService {
  private _user: SSOUser | undefined;

  public accessToken:
    | {
        value: string;
        expiry: number;
      }
    | undefined;

  public get user(): SSOUser | undefined {
    return this._user;
  }

  public set user(user: SSOUser | undefined) {
    this.accessToken = undefined;
    this._user = user;
  }

  public async token(): Promise<string | undefined> {
    if (!this.user) {
      LOGGER.info(
        'Requesting token when user is signed out.',
        'USER_SIGNED_OUT'
      );
      return undefined;
    }

    const tokenExpired =
      !this.accessToken ||
      DayJs(this.accessToken.expiry)
        .subtract(5, 'minutes')
        .isBefore(DayJs(Date.now()));

    LOGGER.info({
      msg: `Is token about to expire? ${tokenExpired} Does access token exist? ${!!this
        .accessToken}`,
      expTime: new Date(this.accessToken?.expiry || 0)
    });

    if (tokenExpired && this.accessToken) {
      LOGGER.info('Token has expired.', 'TOKEN_EXPIRATION');
    }

    if (tokenExpired) {
      const token = await WMSingleSignOn.getFreshAccessToken();

      const decodedToken = jwtDecode<JwtPayload>(token);
      this.accessToken = {
        value: token,
        expiry: (decodedToken.exp || 0) * 1000 || -1
      };

      LOGGER.info(
        {
          msg: 'Successfully refreshed token.',
          expTime: new Date(this.accessToken.expiry)
        },
        'TOKEN_REFRESH'
      );
    }

    return this.accessToken?.value;
  }
}

export const USER_SERVICE = new UserService();
