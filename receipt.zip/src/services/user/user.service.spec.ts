import WMSingleSignOn from 'react-native-ssmp-sso-allspark';
import { mockUser } from '../../../mocks/mock-user';
import { USER_SERVICE } from './user.service';
import DayJS from 'dayjs';

describe('User Service', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should not return token when user is signed out', async () => {
    expect(await USER_SERVICE.token()).toBeFalsy();
  });

  it('should return a token when user is defined', async () => {
    const spy = jest.spyOn(WMSingleSignOn, 'getFreshAccessToken');
    USER_SERVICE.user = mockUser('US', 'Bob the MF Builder');
    USER_SERVICE.accessToken = {
      value:
        'eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTY1MTE5OTk1NSwiaWF0IjoxNjUxMTk5OTU1fQ',
      expiry: DayJS(Date.now()).add(6, 'minutes').toDate().getTime()
    };
    expect(await USER_SERVICE.token()).toBeTruthy();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should refresh tokens 5 minutes before expiration', async () => {
    const spy = jest.spyOn(WMSingleSignOn, 'getFreshAccessToken');
    USER_SERVICE.user = mockUser('US', 'Bob the MF Builder');
    USER_SERVICE.accessToken = {
      value:
        'eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTY1MTE5OTk1NSwiaWF0IjoxNjUxMTk5OTU1fQ',
      expiry: DayJS(Date.now()).add(4, 'minutes').toDate().getTime()
    };
    expect(await USER_SERVICE.token()).toBeTruthy();
    expect(spy).toHaveBeenCalledTimes(1);
  });
});
