import { BehaviorSubject } from 'rxjs';

export type ErrorType = 'network' | 'error';

export class ErrorService extends BehaviorSubject<ErrorType | undefined> {}

export const ERROR_SERVICE = new ErrorService(undefined);
