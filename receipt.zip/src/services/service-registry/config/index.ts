import dev from './dev.json';
import beta from './beta.json';
import teflon from './teflon.json';
import prod from './prod.json';
import base from './base.json';

export const SERVICE_REGISTRY_CONFIG = {
  dev,
  beta,
  teflon,
  prod,
  base
};
