import { Crypto } from '../../utils/crypto';
import { appFetch, RequestOptions } from '../../utils/fetch';
import { SERVICE_REGISTRY_CONFIG } from './config';
import { ENVIRONMENT } from '../environment';
import { ERROR_SERVICE } from '../error/error.service';

export interface ServiceRegistryAppConfig {
  proxy?: boolean;
  url: string;
  env: string;
}

export interface ServiceRegistryConfig {
  consumerId: string;
  applications: Record<string, ServiceRegistryAppConfig>;
}

export abstract class ServiceRegistryApplication {
  private toPemFormat(str: string): string {
    let output = '';
    let flag = true;
    while (flag) {
      if (str.length > 64) {
        output += str.substring(0, 64) + '\n';
        str = str.substring(64, str.length);
      } else {
        output += str + '\n';
        flag = false;
      }
    }

    return output;
  }

  protected get appConfig(): ServiceRegistryConfig {
    let base = SERVICE_REGISTRY_CONFIG.base;
    const currentEnv = SERVICE_REGISTRY_CONFIG[ENVIRONMENT.envName] as Record<
      string,
      any
    >;

    base = {
      ...base,
      ...currentEnv,
      applications: { ...base.applications, ...currentEnv.applications }
    };

    return base;
  }

  protected get consumerId(): string {
    return this.appConfig.consumerId;
  }

  protected get apiConfig(): ServiceRegistryAppConfig {
    return this.appConfig.applications[this.appName];
  }

  protected async generateAuthSignature(
    timestamp = Date.now(),
    keyVersion = 1
  ): Promise<string> {
    const stringToEncode = `${this.consumerId}\n${timestamp}\n${keyVersion}\n`;
    const privateKey = this.toPemFormat(ENVIRONMENT.privateKey);

    return Crypto.withRsaSHA256(stringToEncode, privateKey);
  }

  constructor(public appName: string) {}

  protected async fetch(
    input: RequestInfo,
    options: RequestOptions = {}
  ): Promise<Response> {
    options.tags = options?.tags?.concat(this.appName) || [this.appName];
    options.headers = {
      ...(await this.headers()),
      ...options.headers
    };

    try {
      const resp = await appFetch(input, options);

      if (resp.status >= 500) {
        ERROR_SERVICE.next('error');
      }

      return resp;
    } catch (e) {
      ERROR_SERVICE.next('network');
      throw e;
    }
  }

  protected async headers(): Promise<Record<string, any>> {
    const timestamp = Date.now();
    const apiConfig = this.apiConfig;

    let headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'WM_CONSUMER.ID': this.consumerId,
      'WM_SVC.ENV': this.apiConfig.env,
      'WM_SVC.VERSION': '1.0.0'
    } as Record<string, any>;

    if (apiConfig.proxy) {
      headers = {
        ...headers,
        'WM_SVC.KEY_VERSION': 1,
        'WM_CONSUMER.INTIMESTAMP': timestamp,
        'WM_SEC.AUTH_SIGNATURE': await this.generateAuthSignature(timestamp)
      };
    } else {
      headers = { ...headers, 'WM_SVC.NAME': this.appName };
    }

    return Object.keys(headers)
      .sort()
      .reduce((obj, key) => {
        (obj as Record<string, any>)[key] = headers[key];
        return obj;
      }, {});
  }
}
