export * from './service-registry.application';
