import { useEffect, useState } from 'react';
import { ErrorType, ERROR_SERVICE } from '../services/error/error.service';

export function useErrorState(): ErrorType | undefined {
  const [errorType, setErrorType] = useState<ErrorType>();

  useEffect(() => {
    const sub = ERROR_SERVICE.subscribe(err => setErrorType(err));

    return () => {
      sub.unsubscribe();
    };
  }, []);

  return errorType;
}
