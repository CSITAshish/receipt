import { useEffect, useState } from 'react';
import WMSingleSignOn, {
  ssoEventEmitter,
  SSOPingFedEvents,
  SSOPingFedEventData,
  SSOEnv,
  SSOUser
} from 'react-native-ssmp-sso-allspark';
import { LOGGER } from '../app.logger';
import { ENVIRONMENT } from '../services/environment';
import { USER_SERVICE } from '../services/user/user.service';
import { useLoading } from '../views/loading-panel/loading-panel.component';

interface SSOState {
  user: SSOUser | undefined;
  signIn: () => void;
  signOut: () => void;
}

export const useSSOLogin = (): SSOState => {
  const [user, setUser] = useState<SSOUser>();
  const { setLoading } = useLoading();
  WMSingleSignOn.setEnv(ENVIRONMENT.is('prod') ? SSOEnv.PROD : SSOEnv.CERT); // supported values "CERT", "DEV", "PROD" (default)
  const appId = `com.walmart.stores.receiptaudit${
    ENVIRONMENT.is('prod') ? '' : '.' + ENVIRONMENT.envName
  }://SSOLogin`;
  WMSingleSignOn.setRedirectUri(appId);
  useEffect(() => {
    setLoading(true);
    WMSingleSignOn.getUser()
      .then(usr => {
        USER_SERVICE.user = usr;
        setUser(USER_SERVICE.user);
        setLoading(false);
      })
      .catch(err => {
        LOGGER.error({ ...err });
        setLoading(false);
      });
    const ssoEventListener = ssoEventEmitter.addListener(
      SSOPingFedEvents.name,
      (event: SSOPingFedEventData) => {
        setLoading(false);
        const usr = setEvent(event);
        setUser(usr);
        USER_SERVICE.user = usr;
      }
    );
    return () => {
      ssoEventListener.remove();
    };
  }, [user?.employeeID, setLoading]);
  return {
    user,
    signIn: () => {
      setLoading(true);
      WMSingleSignOn.signIn('MainActivity');
    },
    signOut: () => {
      setLoading(true);
      WMSingleSignOn.signOut('MainActivity', false);
    }
  };
};

export function setEvent(event: SSOPingFedEventData): SSOUser | undefined {
  const eventTypes = SSOPingFedEvents.types;
  LOGGER.info(`SSO event ${event.action} occurred`, 'SSO_EVENT');
  switch (event.action) {
    case eventTypes.authSuccess:
      return event;
    case eventTypes.userChanged:
      return undefined;
    case eventTypes.error:
      return undefined;
    case eventTypes.signedOut:
      return undefined;
    case eventTypes.clockStatusChange:
      return undefined;
  }
}
