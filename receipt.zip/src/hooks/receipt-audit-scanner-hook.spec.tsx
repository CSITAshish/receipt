import 'react-native';
import { renderHook, act } from '@testing-library/react-hooks';
import { useScanner } from './receipt-audit-scanner.hook';

describe('scanner hook', () => {
  beforeAll(() => {
    global.__DEV__ = false;
  });

  afterAll(() => {
    global.__DEV__ = true;
  });

  it('verify scan event', () => {
    const { result } = renderHook(() => useScanner(), {
      initialProps: { scanResult: { value: '', type: '' } }
    });
    expect(result.current.value).toEqual('');
    act(() => {
      result.current.barcodeType = 'item_barcode';
      result.current.value = '123';
    });
    expect(result.current.value).toEqual('123');
    expect(result.current.barcodeType).toEqual('item_barcode');
  });
});
