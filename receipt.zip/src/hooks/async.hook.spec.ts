import { renderHook } from '@testing-library/react-hooks';
import { act, waitFor } from '@testing-library/react-native';
import { useAsync } from './async.hook';
import 'react-native';

describe('Async Hook', () => {
  it('should set errors', async () => {
    const hook = renderHook(() =>
      useAsync(() => Promise.reject({ marc: 'lore' }))
    );

    act(() => {
      hook.result.current.execute();
    });

    expect(hook.result.current.status).toBe('pending');

    await waitFor(() => expect(hook.result.current.error).toBeTruthy());

    expect(hook.result.current.status).toBe('error');
  });
});
