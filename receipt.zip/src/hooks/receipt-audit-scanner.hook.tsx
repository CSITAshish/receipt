import { useEffect, useState } from 'react';
import ScannerModule from 'react-native-wm-barcode';
import { NativeEventEmitter } from 'react-native';
import { LOGGER } from '../app.logger';
import { BarcodeType, barcodeType } from '../utils/barcode/barcode';
import { TCNumber } from '@walmart/tcnumber';
import UPC from 'cpc-input';

const SCANNER_TYPE = '2D Barcode Imager';

export interface ScanResult {
  value: string;
  type: string;
}

const setupScanner = async (): Promise<void> => {
  if (__DEV__ === false) {
    const scanners = await ScannerModule.getScannerList();
    await ScannerModule.setScanner(
      scanners.find(s => s === SCANNER_TYPE) as string
    );
    await ScannerModule.startScan(0);
  }
};

const mockScan = (barcode: ScanResult): void => {
  ScannerModule.mockScan({
    barcode: barcode.value,
    type: barcode.type
  });
};

export const isValid = (result: ScanResult, type: BarcodeType): boolean => {
  if (!result.value) {
    return false;
  }

  let valid = true;
  switch (type) {
    case 'item_barcode':
      valid = new UPC(result.value).parsed;
      break;
    case 'receipt_barcode':
      try {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const tcNumber = new TCNumber(result.value);
      } catch {
        LOGGER.error({
          msg: 'Error parsing barcode',
          barcode: result.value,
          barcodeType: result.type
        });
        valid = false;
      }
      break;
    case 'unknown':
      LOGGER.info(
        {
          msg: 'Unknown barcode',
          barcodeType: result.type,
          barcode: result.value
        },
        'UKNOWN_BARCODE'
      );
      break;
  }

  return valid;
};

export const useScanner = (): {
  value: string;
  count: number; // makes sure useEffect runs when the same barcode is scanned twice
  mock: (result: ScanResult) => void;
  barcodeType: BarcodeType;
  valid: boolean;
} => {
  const [scanResult, setScanResult] = useState<ScanResult>({
    value: '',
    type: ''
  });

  const [count, setCount] = useState(0);

  useEffect(() => {
    setupScanner().catch(LOGGER.error);

    const barcodeEmitter = new NativeEventEmitter(ScannerModule);
    barcodeEmitter.addListener('scanned', scan => {
      LOGGER.info({ barocde: scan }, 'BARCODE_SCAN');
      if (scan.value === scanResult.value && scan.type === scanResult.type) {
        setCount(count + 1);
      } else {
        setCount(1);
      }
      setScanResult(scan);
    });
    return () => {
      barcodeEmitter.removeAllListeners('scanned');
    };
  }, [setScanResult, count, scanResult.type, scanResult.value]);

  const barType = scanResult.type ? barcodeType(scanResult.type) : 'unknown';

  return {
    value: scanResult.value,
    mock: mockScan,
    count,
    barcodeType: barType,
    valid: isValid(scanResult, barType)
  };
};
