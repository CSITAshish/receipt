import { useCallback, useState } from 'react';
import { LOGGER } from '../app.logger';

export type AsyncStatus = 'pending' | 'success' | 'error' | 'idle';

export interface AsyncState<TResponse> {
  execute: () => void;
  status: AsyncStatus;
  value: TResponse | undefined;
  error: any;
}

export function useAsync<TResponse>(
  asyncFunction: () => Promise<TResponse>
): AsyncState<TResponse> {
  const [status, setStatus] = useState<AsyncStatus>('idle');
  const [value, setValue] = useState<TResponse>();
  const [error, setError] = useState<Error>();
  const execute = useCallback(async () => {
    setStatus('pending');
    try {
      const response = await asyncFunction();
      setStatus('success');
      setValue(response);
    } catch (e: any) {
      LOGGER.error(e);
      setError(e);
      setStatus('error');
    }
  }, [asyncFunction]);

  return {
    execute,
    status,
    value,
    error
  };
}
