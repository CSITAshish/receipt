import 'react-native';
import { useSSOLogin, setEvent } from './sso.hook';
import { renderHook } from '@testing-library/react-hooks';
import { SSOPingFedEventData } from 'react-native-ssmp-sso-allspark';

describe('SSO Functionality', () => {
  it('should call useSSO and return user', () => {
    const result = renderHook(() => useSSOLogin());
    const { user } = result.result.current;
    expect(user).toBeTruthy();
  });
  it('setEvent authSuccess', () => {
    const event = { action: 'ssoAuthSuccess', error: {} };
    const response = setEvent(event as SSOPingFedEventData);
    expect(response !== undefined).toBeTruthy();
  });
  it('setEvent userChanged', () => {
    const result = renderHook(() => useSSOLogin());
    const { user } = result.result.current;
    expect(user).toBeTruthy();
  });
  it('setEvent error', () => {
    const event = { action: 'error', error: {} };
    const response = setEvent(event as SSOPingFedEventData);
    expect(response === undefined).toBeTruthy();
  });
  it('setEvent signedOut', () => {
    const event = { action: 'signedOut', error: {} };
    const response = setEvent(event as SSOPingFedEventData);
    expect(response === undefined).toBeTruthy();
  });
  it('setEvent clockStatusChange', () => {
    const event = { action: 'clockStatusChange', error: {} };
    const response = setEvent(event as SSOPingFedEventData);
    expect(response === undefined).toBeTruthy();
  });
});
