import { LoggerInstance } from '@walmart/core-services/Logger';
import { createRef } from 'react';

export const AllsparkLogger = createRef<LoggerInstance>();
