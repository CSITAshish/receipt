import 'react-native';
import React from 'react';
import { App } from './app';
import { cleanup, render } from '@testing-library/react-native';
import { mockUser } from '../mocks/mock-user';
import { EnvironmentProvider } from '@walmart/core-services/Environment';
import Env from '../container/env';
import { LoggerProvider } from '@walmart/core-services/Logger';
import { NavigationContainer } from '@react-navigation/native';

describe('App', () => {
  beforeEach(() => {
    jest.mock('./hooks/sso.hook', () => {
      return jest.fn(() => ({
        user: mockUser('US', 'Im a Dude')
      }));
    });
  });
  afterEach(() => {
    cleanup();
  });

  it('should render correctly', () => {
    expect(
      render(
        <NavigationContainer>
          <LoggerProvider
            config={{} as any}
            instance={
              {
                setConfig: jest.fn(),
                setUserInfo: jest.fn(),
                setSessionInfo: jest.fn(),
                clone: jest.fn(),
                setLogLevel: jest.fn(),
                debug: jest.fn(),
                info: jest.fn(),
                warn: jest.fn(),
                error: jest.fn()
              } as any
            }
          >
            <EnvironmentProvider env={Env}>
              <App />
            </EnvironmentProvider>
          </LoggerProvider>
        </NavigationContainer>
      )
    ).toBeTruthy();
  });
});
